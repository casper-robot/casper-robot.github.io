"""
CASPER Web Interface — Flask backend.

Three pages:
  /                Pipeline Explorer (live single-command pipeline)
  /dashboard       Results Dashboard (Experiments A/C visualization)
  /experiment-b    Experiment B Runner (simulated learning)

API endpoints serve JSON for AJAX calls from each page.
"""

from __future__ import annotations

import json
import logging
import os
import traceback
from pathlib import Path

import numpy as np
from flask import Flask, jsonify, render_template, request

logger = logging.getLogger(__name__)

RESULTS_DIR = Path(os.environ.get(
    "CASPER_RESULTS_DIR",
    str(Path(__file__).resolve().parent.parent.parent / "results"),
))


def _save_mechanistic_trace(
    trace_dir: Path,
    command: str,
    scene_context: str,
    result,
    fr3_candidates: list,
    profile_selections: dict,
    pipeline,
    cached_scene: dict,
) -> None:
    """Save full mechanistic trace for qualitative analysis.

    Produces one directory per command with all 5 artifacts the paper
    requires: interaction graph, hazard diagnosis, generated repairs,
    gate-validation rejections, and final selected candidates.
    """
    from datetime import datetime, timezone
    from casper.action_ir import render_fr3_script, CanonicalAction

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    slug = command[:30].replace(" ", "_").replace("/", "_")
    task_dir = trace_dir / f"{ts}_{slug}"
    task_dir.mkdir(parents=True, exist_ok=True)

    # 1. Input
    scene_obj = cached_scene.get("scene", None)
    input_data = {
        "command": command,
        "scene_context_length": len(scene_context),
        "scene_objects": scene_obj.object_names if scene_obj else [],
        "scene_room_type": scene_obj.room_type if scene_obj else "",
        "scene_description": scene_obj.description[:500] if scene_obj and scene_obj.description else "",
    }
    (task_dir / "00_input.json").write_text(
        json.dumps(input_data, indent=2), encoding="utf-8",
    )

    # 2. Interaction Graph
    safety_result = result.safety_result
    graph = safety_result.interaction_graph if safety_result else None
    if graph:
        graph_data = {
            "entities": [
                {"name": e.name, "type": e.entity_type, "description": e.description}
                for e in graph.entities
            ],
            "relationships": [
                {"source": r.source, "target": r.target,
                 "relation": r.relation, "description": r.description}
                for r in graph.relationships
            ],
            "entity_count": graph.entity_count(),
            "relationship_count": graph.relationship_count(),
        }
    else:
        graph_data = {"entities": [], "relationships": []}
    (task_dir / "01_interaction_graph.json").write_text(
        json.dumps(graph_data, indent=2), encoding="utf-8",
    )

    # 3. Hazard Diagnosis
    if safety_result:
        sr_dict = safety_result.to_dict()
        diagnosis_data = {
            "is_safe": sr_dict.get("is_safe"),
            "safety_margin": sr_dict.get("safety_margin"),
            "flagged_dimensions": sr_dict.get("flagged_dimensions", []),
            "dimensions": sr_dict.get("dimensions", {}),
        }
        # Add hazard diagnosis details if available
        if hasattr(result, 'original_frame') and result.original_frame:
            frame = result.original_frame
            diagnosis_data["objective_frame"] = frame.to_dict() if hasattr(frame, 'to_dict') else {}
    else:
        diagnosis_data = {"is_safe": None}
    (task_dir / "02_hazard_diagnosis.json").write_text(
        json.dumps(diagnosis_data, indent=2, default=str), encoding="utf-8",
    )

    # 4. Generated Repairs + Gate Rejections
    repair_diag = getattr(pipeline.safety, '_last_repair_diagnostics', {})
    underlying_need = getattr(pipeline.safety, '_last_underlying_need', '')

    # All generated (pre-filtering)
    all_generated = getattr(result, 'all_generated', [])
    generated_data = {
        "underlying_need": underlying_need,
        "per_operator": repair_diag.get("per_operator", []),
        "total_raw": sum(d.get("raw_count", 0) for d in repair_diag.get("per_operator", [])),
    }

    # Gate rejections
    rejected_lint = getattr(result, 'rejected_lint', [])
    rejected_screen = getattr(result, 'rejected_screen', [])
    rejected_safety = getattr(result, 'rejected_safety', [])

    gate_data = {
        "gate1_lint": {
            "rejected_count": len(rejected_lint),
            "details": [
                {"command": c.command, "strategy": c.strategy, "errors": errs}
                for c, errs in rejected_lint
            ],
        },
        "gate2_screen": {
            "rejected_count": len(rejected_screen),
            "details": [
                {
                    "command": c.command,
                    "strategy": c.strategy,
                    "resolved": sr.resolved if sr else None,
                    "flagged": [d.name for d in sr.flagged_dimensions] if sr else [],
                }
                for c, sr in rejected_screen
            ],
        },
        "gate3_safety": {
            "rejected_count": len(rejected_safety),
            "details": [
                {
                    "command": c.command,
                    "strategy": c.strategy,
                    "flagged": [d.name for d in dims],
                }
                for c, dims in rejected_safety
            ],
        },
        "prelint_rejected": repair_diag.get("prelint_rejected", []),
        "critic_rejected": repair_diag.get("critic_rejected", 0),
        "dedup_removed": repair_diag.get("dedup_removed", 0),
    }

    (task_dir / "03_generated_repairs.json").write_text(
        json.dumps(generated_data, indent=2), encoding="utf-8",
    )
    (task_dir / "04_gate_rejections.json").write_text(
        json.dumps(gate_data, indent=2), encoding="utf-8",
    )

    # 5. Final Safe Candidates + Profile Selections
    safe_data = {
        "safe_candidate_count": len(fr3_candidates),
        "candidates": [
            {
                "index": i,
                "command": c.get("command", ""),
                "strategy": c.get("strategy", ""),
                "action_plan": c.get("action_plan", []),
                "fr3_code": c.get("fr3_code", ""),
                "safety_margin": c.get("safety_margin", 0),
                "repair_posture": c.get("repair_posture", ""),
            }
            for i, c in enumerate(fr3_candidates)
        ],
        "profile_selections": {
            name: {
                "selected_repair": sel.get("selected_repair", ""),
                "selected_strategy": sel.get("selected_strategy", ""),
                "selected_index": sel.get("selected_index"),
                "score": sel.get("score"),
                "all_scores": sel.get("all_scores", []),
                "fr3_code": sel.get("fr3_code", ""),
            }
            for name, sel in profile_selections.items()
        } if profile_selections else {},
    }

    # Add feature vectors if available
    safe_candidates_obj = getattr(result, 'safe_candidates', [])
    if safe_candidates_obj:
        for i, c in enumerate(safe_candidates_obj):
            if hasattr(c, 'features') and c.features is not None:
                if i < len(safe_data["candidates"]):
                    safe_data["candidates"][i]["feature_vector"] = (
                        c.features.values.tolist()
                        if hasattr(c.features, 'values') else []
                    )

    (task_dir / "05_safe_candidates_and_preference_selection.json").write_text(
        json.dumps(safe_data, indent=2), encoding="utf-8",
    )

    # 6. Manifest
    manifest = {
        "command": command,
        "trace_files": [
            "00_input.json",
            "01_interaction_graph.json",
            "02_hazard_diagnosis.json",
            "03_generated_repairs.json",
            "04_gate_rejections.json",
            "05_safe_candidates_and_preference_selection.json",
        ],
        "summary": {
            "detected_unsafe": not safety_result.is_safe if safety_result else None,
            "total_generated": generated_data.get("total_raw", 0),
            "prelint_rejected": len(repair_diag.get("prelint_rejected", [])),
            "gate1_rejected": len(rejected_lint),
            "gate2_rejected": len(rejected_screen),
            "gate3_rejected": len(rejected_safety),
            "safe_candidates": len(fr3_candidates),
            "profiles_diverge": len(set(
                sel.get("selected_index") for sel in profile_selections.values()
            )) > 1 if profile_selections else False,
        },
    }
    (task_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8",
    )

    logger.info(f"Mechanistic trace saved to {task_dir}")


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(Path(__file__).parent / "templates"),
        static_folder=str(Path(__file__).parent / "static"),
    )
    app.config["JSON_SORT_KEYS"] = False
    app.config["POSTERIORS"] = None
    app.config["VLM_SCENE_CACHE"] = {}

    # Interface trace/session directory
    _INTERFACE_TRACES = RESULTS_DIR / "interface_traces"
    _INTERFACE_TRACES.mkdir(parents=True, exist_ok=True)
    _SESSION_LOG = RESULTS_DIR / "interface_sessions.jsonl"

    # Auto-load posteriors if available
    posteriors_candidates = [
        RESULTS_DIR / "full_run_v2" / "experiment_b" / "converged_posteriors.json",
        RESULTS_DIR / "experiment_b" / "converged_posteriors.json",
    ]
    for p in posteriors_candidates:
        if p.exists():
            try:
                from evaluation.experiments import load_posteriors
                app.config["POSTERIORS"] = load_posteriors(str(p))
                logger.info(f"Loaded posteriors from {p}")
            except Exception as e:
                logger.warning(f"Failed to load posteriors from {p}: {e}")
            break

    @app.route("/api/posteriors/load", methods=["POST"])
    def load_posteriors_api():
        data = request.json or {}
        path = data.get("path", "")
        if not path:
            return jsonify({"error": "No path provided"}), 400
        try:
            from evaluation.experiments import load_posteriors
            app.config["POSTERIORS"] = load_posteriors(path)
            profiles = list(app.config["POSTERIORS"].keys())
            return jsonify({"status": "loaded", "profiles": profiles})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/posteriors/status")
    def posteriors_status():
        posteriors = app.config.get("POSTERIORS")
        if posteriors:
            return jsonify({
                "loaded": True,
                "profiles": list(posteriors.keys()),
            })
        return jsonify({"loaded": False, "profiles": []})

    @app.route("/")
    def pipeline_page():
        return render_template("pipeline.html")

    @app.route("/dashboard")
    def dashboard_page():
        return render_template("dashboard.html")

    @app.route("/experiment-b")
    def experiment_b_page():
        return render_template("experiment_b.html")

    # Health / Status

    @app.route("/api/health")
    def health():
        return jsonify({"status": "ok", "version": "0.1.0"})

    @app.route("/api/models")
    def available_models():
        try:
            from casper.llm_providers import get_available_models
            return jsonify({"models": get_available_models()})
        except Exception:
            return jsonify({"models": []})

    @app.route("/api/scenes")
    def available_scenes():
        try:
            from casper.scene_provider import SceneProvider
            sp = SceneProvider(force_cache=True)
            return jsonify({"scenes": sp.available_scenes()})
        except Exception:
            return jsonify({"scenes": []})

    @app.route("/api/scene/<scene_id>/objects")
    def scene_objects(scene_id):
        try:
            from casper.scene_provider import SceneProvider
            sp = SceneProvider(force_cache=True)
            scene = sp.load_scene(scene_id)
            return jsonify({
                "scene_id": scene_id,
                "room_type": scene.room_type,
                "objects": [o.to_dict() for o in scene.objects],
                "object_names": scene.object_names,
                "scene_context": scene.scene_context,
            })
        except Exception as e:
            return jsonify({"error": str(e)}), 400

    # Pipeline Explorer API

    @app.route("/api/pipeline/process", methods=["POST"])
    def pipeline_process():
        data = request.json or {}
        command = data.get("command", "").strip()
        scene_context = data.get("scene_context", "")
        provider = data.get("provider", app.config.get("DEFAULT_PROVIDER", "openai"))
        model = data.get("model", app.config.get("DEFAULT_MODEL", "gpt-4o"))
        use_fr3_verbs = data.get("use_fr3_verbs", False)

        if not command:
            return jsonify({"error": "No command provided"}), 400

        try:
            from casper.llm_providers import create_llm_backend
            from casper.casper_pipeline import CasperPipeline
            from casper.action_ir import FR3_ALLOWED_VERBS, render_fr3_python

            llm = create_llm_backend(provider, model)
            repair_config = None
            repair_mode = app.config.get("REPAIR_MODE", "structured_operator")
            if repair_mode != "legacy":
                from casper.repair_operators import RepairConfig
                repair_config = RepairConfig(generation_mode="structured_operator")
            pipeline = CasperPipeline(llm=llm, repair_config=repair_config)
            allowed_verbs = FR3_ALLOWED_VERBS if use_fr3_verbs else None

            # Use cached VLM scene context if available
            cached = app.config.get("VLM_SCENE_CACHE", {})
            cached_scene_ctx = cached.get("scene_ctx")
            result = pipeline.process_command(
                command, scene_context,
                scene_ctx=cached_scene_ctx,
                allowed_verbs=allowed_verbs,
            )

            response = result.to_dict()

            # Add FR3 code for each safe candidate
            safe_candidates = getattr(result, 'safe_candidates', [])
            fr3_candidates = []
            for c in safe_candidates:
                action_plan = [
                    {"verb": a.verb, "obj": a.obj, "receptacle": a.receptacle}
                    for a in getattr(c, 'action_plan', [])
                ]
                fr3_lines = [
                    render_fr3_python(a)
                    for a in getattr(c, 'action_plan', [])
                ]
                fr3_candidates.append({
                    "command": c.command,
                    "strategy": c.strategy,
                    "action_plan": action_plan,
                    "fr3_code": "\n".join(fr3_lines),
                    "safety_margin": (
                        c.safety_result.safety_margin
                        if c.safety_result else 0.0
                    ),
                    "repair_posture": getattr(c, 'repair_posture', ''),
                })
            response["fr3_candidates"] = fr3_candidates

            # Profile-conditioned scoring if posteriors are loaded
            posteriors = app.config.get("POSTERIORS")
            if posteriors and len(safe_candidates) >= 2:
                from evaluation.baselines import CasperStrategy, CasperConfig
                strategy = CasperStrategy(CasperConfig())

                feature_vectors = [
                    c.features.values for c in safe_candidates
                ]
                safety_margins = [
                    c.safety_result.safety_margin
                    for c in safe_candidates
                    if c.safety_result
                ]

                profile_selections = {}
                for profile_name, (mu, sigma) in posteriors.items():
                    scores = [
                        strategy._score(fv, sm, mu, sigma)
                        for fv, sm in zip(feature_vectors, safety_margins)
                    ]
                    best_idx = int(np.argmax(scores))
                    profile_selections[profile_name] = {
                        "selected_index": best_idx,
                        "selected_repair": fr3_candidates[best_idx]["command"],
                        "selected_strategy": fr3_candidates[best_idx]["strategy"],
                        "fr3_code": fr3_candidates[best_idx]["fr3_code"],
                        "score": round(scores[best_idx], 4),
                        "all_scores": [round(s, 4) for s in scores],
                    }
                response["profile_selections"] = profile_selections

            # Log session to disk
            try:
                from datetime import datetime, timezone as _tz
                sr = response.get("safety_result", {})
                dim_results = sr.get("dimensions", {})
                dimension_summary = {}
                for dim_name, dim_data in dim_results.items():
                    assessments = dim_data.get("assessments", [])
                    if assessments:
                        a = assessments[0]
                        dimension_summary[dim_name] = {
                            "concern": a.get("concern", False),
                            "severity": a.get("severity", "unknown"),
                            "reasoning": a.get("reasoning", "")[:200],
                        }

                session_entry = {
                    "timestamp": datetime.now(_tz.utc).isoformat(),
                    "command": command,
                    "scene_context_length": len(scene_context),
                    "provider": provider,
                    "model": model,
                    "repair_mode": app.config.get("REPAIR_MODE", "structured_operator"),
                    "detected_unsafe": sr.get("is_safe") is False,
                    "safety_margin": sr.get("safety_margin"),
                    "flagged_dimensions": sr.get("flagged_dimensions", []),
                    "dimension_summary": dimension_summary,
                    "safe_candidates": len(fr3_candidates),
                    "profile_selections": bool(response.get("profile_selections")),
                    "fr3_candidates": [
                        {"command": c["command"], "strategy": c["strategy"]}
                        for c in fr3_candidates
                    ],
                }

                # Add repair diagnostics if available
                repair_diag = getattr(pipeline.safety, '_last_repair_diagnostics', None)
                if repair_diag:
                    session_entry["repair_diagnostics"] = repair_diag

                with open(_SESSION_LOG, "a", encoding="utf-8") as f:
                    f.write(json.dumps(session_entry) + "\n")

                # Save full mechanistic trace for qualitative analysis
                _save_mechanistic_trace(
                    trace_dir=_INTERFACE_TRACES,
                    command=command,
                    scene_context=scene_context,
                    result=result,
                    fr3_candidates=fr3_candidates,
                    profile_selections=response.get("profile_selections", {}),
                    pipeline=pipeline,
                    cached_scene=cached,
                )
            except Exception:
                pass

            return jsonify(response)
        except Exception as e:
            logger.error(f"Pipeline error: {e}", exc_info=True)
            return jsonify({
                "error": str(e),
                "traceback": traceback.format_exc(),
            }), 500

    @app.route("/api/pipeline/download-scripts", methods=["POST"])
    def download_scripts():
        """Package all FR3 scripts from the last run as a downloadable ZIP."""
        import io
        import zipfile
        from flask import send_file
        from casper.action_ir import render_fr3_script, CanonicalAction

        data = request.json or {}
        command = data.get("command", "unknown")
        fr3_candidates = data.get("fr3_candidates", [])
        profile_selections = data.get("profile_selections", {})

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            # All safe candidates
            for i, cand in enumerate(fr3_candidates):
                actions = [
                    CanonicalAction(
                        verb=s.get("verb", ""),
                        obj=s.get("obj", ""),
                        receptacle=s.get("receptacle", ""),
                    )
                    for s in cand.get("action_plan", [])
                ]
                script = render_fr3_script(actions, metadata={
                    "command": command,
                    "repair": cand.get("command", ""),
                    "strategy": cand.get("strategy", ""),
                })
                fname = f"candidate_{i+1}_{cand.get('strategy', 'unknown')}.txt"
                zf.writestr(f"all_candidates/{fname}", script)

            # Per-profile top-1 selections
            for profile_name, sel in profile_selections.items():
                code = sel.get("fr3_code", "")
                if code:
                    safe_name = profile_name.replace(" ", "_").replace("-", "_")
                    script = (
                        f'#!/usr/bin/env python3\n'
                        f'"""FR3 script — {profile_name}\n'
                        f'Command: {command}\n'
                        f'Repair: {sel.get("selected_repair", "")}\n'
                        f'Strategy: {sel.get("selected_strategy", "")}\n'
                        f'Score: {sel.get("score", "")}\n'
                        f'"""\n\n'
                        f'from franka_interface import FrankaRobot\n\n'
                        f'robot = FrankaRobot()\n'
                        f'robot.connect()\n\n'
                        f'{code}\n\n'
                        f'robot.disconnect()\n'
                    )
                    zf.writestr(f"profile_selections/{safe_name}.txt", script)

            # Summary manifest
            summary = {
                "command": command,
                "total_safe_candidates": len(fr3_candidates),
                "profiles": {
                    name: {
                        "selected": sel.get("selected_repair", ""),
                        "strategy": sel.get("selected_strategy", ""),
                        "score": sel.get("score", ""),
                    }
                    for name, sel in profile_selections.items()
                },
            }
            zf.writestr("manifest.json", json.dumps(summary, indent=2))

        buf.seek(0)
        slug = command[:30].replace(" ", "_").replace("/", "_")
        return send_file(
            buf,
            mimetype="application/zip",
            as_attachment=True,
            download_name=f"casper_fr3_{slug}.zip",
        )

    @app.route("/api/vlm/detect", methods=["POST"])
    def vlm_detect():
        data = request.json or {}
        image_b64 = data.get("image", "")
        provider = data.get("provider", app.config.get("DEFAULT_PROVIDER", "openai"))
        model = data.get("model", app.config.get("DEFAULT_MODEL", "gpt-4o"))
        context_hint = data.get("context_hint", "")

        if not image_b64:
            return jsonify({"error": "No image provided"}), 400

        try:
            from casper.llm_providers import create_llm_backend
            from casper.vlm_scene import perceive_scene
            from evaluation.scene_adapters import VLMCasperAdapter

            llm = create_llm_backend(provider, model)
            scene = perceive_scene(llm, image_b64, context_hint=context_hint)

            # Cache the scene and adapted context for reuse
            adapter = VLMCasperAdapter()
            scene_ctx = adapter.adapt(scene)
            app.config["VLM_SCENE_CACHE"] = {
                "scene": scene,
                "scene_ctx": scene_ctx,
                "scene_context": scene.scene_context,
            }
            logger.info(
                f"VLM scene cached: {len(scene.objects)} objects, "
                f"{len(scene_ctx.relations)} relations"
            )

            return jsonify({
                "room_type": scene.room_type,
                "objects": [o.to_dict() for o in scene.objects],
                "object_names": scene.object_names,
                "scene_context": scene.scene_context,
                "description": scene.description,
                "relations": scene_ctx.relations,
            })
        except Exception as e:
            logger.error(f"VLM error: {e}", exc_info=True)
            return jsonify({"error": str(e)}), 500

    @app.route("/api/vlm/update-objects", methods=["POST"])
    def vlm_update_objects():
        """Update the cached VLM scene after the user edits the object list."""
        data = request.json or {}
        objects_raw = data.get("objects", [])
        room_type = data.get("room_type", "Room")
        description = data.get("description", "")

        try:
            from casper.scene_provider import Scene, SceneObject, _categorize_object
            from evaluation.scene_adapters import VLMCasperAdapter

            scene_objects = []
            for o in objects_raw:
                name = o.get("name", "")
                cat = o.get("category", _categorize_object(name))
                props = o.get("properties", {})
                scene_objects.append(SceneObject(name=name, category=cat, properties=props))

            scene = Scene(
                scene_id="vlm_edited",
                room_type=room_type,
                objects=scene_objects,
                source="vlm",
                description=description,
            )

            adapter = VLMCasperAdapter()
            scene_ctx = adapter.adapt(scene)
            app.config["VLM_SCENE_CACHE"] = {
                "scene": scene,
                "scene_ctx": scene_ctx,
                "scene_context": scene.scene_context,
            }
            logger.info(f"VLM scene updated: {len(scene.objects)} objects")

            return jsonify({"ok": True, "object_count": len(scene.objects)})
        except Exception as e:
            logger.error(f"VLM update error: {e}", exc_info=True)
            return jsonify({"error": str(e)}), 500

    # Dashboard API (Experiments A & C results)

    @app.route("/api/dashboard/experiment-a")
    def dashboard_experiment_a():
        results_path = Path(RESULTS_DIR) / "experiment_a"
        if not results_path.exists():
            return jsonify({"error": "No Experiment A results found", "path": str(results_path)}), 404

        try:
            results = _load_jsonl(results_path / "results.jsonl")
            confusion = _compute_confusion_matrix(results)
            by_category = _compute_by_category(results)
            return jsonify({
                "total_tasks": len(results),
                "confusion_matrix": confusion,
                "by_category": by_category,
                "tasks": results[:200],
            })
        except Exception as e:
            logger.error(f"Dashboard A error: {e}", exc_info=True)
            return jsonify({"error": str(e)}), 500

    @app.route("/api/dashboard/experiment-a/task/<task_id>")
    def dashboard_task_detail(task_id):
        results_path = Path(RESULTS_DIR) / "experiment_a"
        result = {"task_id": task_id}

        jsonl_path = results_path / "results.jsonl"
        if jsonl_path.exists():
            with open(jsonl_path, encoding="utf-8") as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        if entry.get("task_id") == task_id:
                            result["checkpoint"] = entry
                            break
                    except json.JSONDecodeError:
                        continue

        trace_path = results_path / "traces" / task_id
        if trace_path.exists():
            for trace_file in sorted(trace_path.glob("*.json")):
                result[trace_file.stem] = json.loads(
                    trace_file.read_text(encoding="utf-8")
                )

        return jsonify(result)

    @app.route("/api/dashboard/experiment-c")
    def dashboard_experiment_c():
        results_path = Path(RESULTS_DIR) / "experiment_c"
        if not results_path.exists():
            return jsonify({"error": "No Experiment C results found"}), 404
        try:
            data = json.loads(
                (results_path / "transfer_results.json").read_text(encoding="utf-8")
            )
            return jsonify(data)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # Experiment B API

    @app.route("/api/experiment-b/profiles")
    def exp_b_profiles():
        try:
            from evaluation.simulated_user import ALL_PROFILES
            profiles = [
                {"name": p.name, "theta": list(p.theta_true), "beta": p.default_beta}
                for p in ALL_PROFILES
            ]
            return jsonify({"profiles": profiles})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/experiment-b/run", methods=["POST"])
    def exp_b_run():
        data = request.json or {}
        profile_name = data.get("profile", "Conservative Parent")
        strategy_name = data.get("strategy", "CASPER")
        n_trials = min(data.get("n_trials", 5), 50)
        t_max = min(data.get("t_max", 30), 100)

        try:
            from evaluation.simulated_user import (
                SimulatedUserFactory, ALL_PROFILES,
            )
            from evaluation.experiments import (
                ExperimentConfig, run_trial_cached,
            )
            from evaluation.metrics import generate_test_pairs

            profile = next(
                (p for p in ALL_PROFILES if p.name == profile_name),
                ALL_PROFILES[0],
            )
            strategy = _make_strategy(strategy_name)

            config = ExperimentConfig(n_trials=n_trials, T_max=t_max)

            from evaluation.candidate_cache import CandidateCache
            cache_path = RESULTS_DIR / "full_run_v2" / "candidate_cache.json"
            if not cache_path.exists():
                return jsonify({"error": "Pre-computed candidate cache not found. Run the benchmark first."}), 404
            cache = CandidateCache.load(str(cache_path))
            factory = SimulatedUserFactory(seed=config.seed)
            seed_seq = np.random.SeedSequence(config.seed)

            all_results = []
            for trial_id in range(n_trials):
                rng = np.random.default_rng(seed_seq.spawn(1)[0])
                user = factory.create(profile)

                learnable = cache.get_learnable_scenarios()
                feature_lists = [s.feature_vectors for s in learnable if len(s.feature_vectors) >= 2]

                test_pairs = generate_test_pairs(
                    feature_lists, user,
                    n_pairs=config.n_test_pairs, rng=rng,
                ) if feature_lists else []

                result = run_trial_cached(
                    user=user, strategy=strategy, cache=cache,
                    config=config, test_pairs=test_pairs,
                    rng=rng, trial_id=trial_id,
                )
                trial_dict = result.to_dict()
                trial_dict["regret_trajectory"] = result.tracker.get_metric_trajectory("cumulative_regret")
                trial_dict["contraction_trajectory"] = result.tracker.get_metric_trajectory("sigma_trace")
                trial_dict["accuracy_trajectory"] = result.tracker.get_metric_trajectory("prediction_accuracy")
                all_results.append(trial_dict)

            return jsonify({"trials": all_results})

        except Exception as e:
            logger.error(f"Experiment B error: {e}", exc_info=True)
            return jsonify({
                "error": str(e),
                "traceback": traceback.format_exc(),
            }), 500

    @app.route("/api/experiment-b/load")
    def exp_b_load():
        results_path = Path(RESULTS_DIR) / "experiment_b"
        if not results_path.exists():
            return jsonify({"error": "No Experiment B results found"}), 404
        try:
            all_data = {}
            for f in sorted(results_path.glob("*.json")):
                all_data[f.stem] = json.loads(f.read_text(encoding="utf-8"))
            return jsonify(all_data)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # Helpers

    def _load_jsonl(path: Path) -> list[dict]:
        results = []
        if path.exists():
            with open(path, encoding="utf-8") as f:
                for line in f:
                    try:
                        results.append(json.loads(line.strip()))
                    except json.JSONDecodeError:
                        continue
        return results

    def _compute_confusion_matrix(results: list[dict]) -> dict:
        tp = fp = tn = fn = 0
        for r in results:
            gt_unsafe = not r.get("ground_truth_safe", True)
            detected = r.get("pipeline_detected_unsafe", False) or r.get("detected_unsafe", False)
            if gt_unsafe and detected:
                tp += 1
            elif gt_unsafe and not detected:
                fn += 1
            elif not gt_unsafe and detected:
                fp += 1
            else:
                tn += 1
        total = tp + fp + tn + fn
        return {
            "tp": tp, "fp": fp, "tn": tn, "fn": fn, "total": total,
            "detection_rate": tp / max(tp + fn, 1),
            "false_positive_rate": fp / max(fp + tn, 1),
            "false_negative_rate": fn / max(tp + fn, 1),
            "true_negative_rate": tn / max(fp + tn, 1),
            "accuracy": (tp + tn) / max(total, 1),
        }

    def _compute_by_category(results: list[dict]) -> dict:
        categories: dict[str, list[dict]] = {}
        for r in results:
            cat = r.get("hazard_category", "unknown")
            categories.setdefault(cat, []).append(r)
        by_cat = {}
        for cat, items in sorted(categories.items()):
            by_cat[cat] = _compute_confusion_matrix(items)
            by_cat[cat]["n_tasks"] = len(items)
        return by_cat

    def _make_strategy(name: str):
        from evaluation.baselines import (
            CasperStrategy, CasperConfig,
            ThompsonSamplingStrategy, GreedyBanditStrategy,
            RandomBanditStrategy, SafetyMaxMarginStrategy,
        )
        strategies = {
            "CASPER": lambda: CasperStrategy(CasperConfig()),
            "Thompson": ThompsonSamplingStrategy,
            "Greedy": GreedyBanditStrategy,
            "Random": RandomBanditStrategy,
            "Safety Max-Margin": SafetyMaxMarginStrategy,
        }
        factory = strategies.get(name, strategies["CASPER"])
        return factory()

    return app


def main():
    logging.basicConfig(level=logging.INFO)
    app = create_app()
    port = int(os.environ.get("CASPER_PORT", 5000))
    print(f"\n  CASPER Interface running at http://localhost:{port}\n")
    print(f"  Pages:")
    print(f"    Pipeline Explorer:    http://localhost:{port}/")
    print(f"    Results Dashboard:    http://localhost:{port}/dashboard")
    print(f"    Experiment B Runner:  http://localhost:{port}/experiment-b\n")
    app.run(host="0.0.0.0", port=port, debug=False)


if __name__ == "__main__":
    main()
