(function () {
    "use strict";

    var regretChart = null;
    var contractionChart = null;
    var profilesCache = null;

    document.addEventListener("DOMContentLoaded", init);

    function init() {
        loadProfiles();
        document.getElementById("runBtn").addEventListener("click", runExperiment);
        document.getElementById("loadBtn").addEventListener("click", loadSaved);
        document.getElementById("profileSelect").addEventListener("change", showProfileDetail);
    }

    function loadProfiles() {
        fetch("/api/experiment-b/profiles")
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.error) {
                    document.getElementById("profileSelect").innerHTML =
                        '<option>Error loading profiles</option>';
                    return;
                }
                profilesCache = data.profiles || [];
                var select = document.getElementById("profileSelect");
                select.innerHTML = profilesCache.map(function (p) {
                    return '<option value="' + p.name + '">' + p.name + '</option>';
                }).join("");
                if (profilesCache.length > 0) showProfileDetail();
            })
            .catch(function () {
                document.getElementById("profileSelect").innerHTML =
                    '<option>Could not load profiles</option>';
            });
    }

    function showProfileDetail() {
        if (!profilesCache) return;
        var name = document.getElementById("profileSelect").value;
        var p = profilesCache.find(function (pr) { return pr.name === name; });
        if (!p) return;
        var el = document.getElementById("profileDetail");
        el.innerHTML =
            '<div style="font-size:0.85rem;">' +
            '<p><strong>' + escapeHtml(p.name) + '</strong></p>' +
            '<p style="color:var(--text-muted); margin-top:0.3rem;">Beta (temperature): ' + p.beta.toFixed(2) + '</p>' +
            '<div style="margin-top:0.5rem;">' +
            '<label>True Theta (10D)</label>' +
            '<div class="feature-grid">' +
            p.theta.map(function (v, i) {
                return '<div class="feature-cell">' +
                    '<span class="feat-name">&theta;' + (i + 1) + '</span>' +
                    v.toFixed(2) + '</div>';
            }).join("") +
            '</div></div></div>';
    }

    function runExperiment() {
        var profile = document.getElementById("profileSelect").value;
        var strategy = document.getElementById("strategySelect").value;
        var nTrials = parseInt(document.getElementById("nTrials").value) || 5;
        var tMax = parseInt(document.getElementById("tMax").value) || 30;

        document.getElementById("expBEmpty").style.display = "none";
        document.getElementById("expBResults").style.display = "block";
        var loading = document.getElementById("expBLoading");
        loading.classList.add("active");

        var btn = document.getElementById("runBtn");
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner"></span> Running...';

        fetch("/api/experiment-b/run", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                profile: profile,
                strategy: strategy,
                n_trials: nTrials,
                t_max: tMax
            })
        })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (data.error) {
                alert("Error: " + data.error);
                document.getElementById("expBEmpty").style.display = "block";
                document.getElementById("expBResults").style.display = "none";
                return;
            }
            renderResults(data.trials || []);
        })
        .catch(function (e) { alert("Run failed: " + e); })
        .finally(function () {
            loading.classList.remove("active");
            btn.disabled = false;
            btn.textContent = "Run Experiment";
        });
    }

    function loadSaved() {
        var status = document.getElementById("loadStatus");
        status.textContent = "Loading...";
        fetch("/api/experiment-b/load")
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.error) {
                    status.textContent = "No saved results found.";
                    return;
                }
                status.textContent = "Loaded " + Object.keys(data).length + " result file(s).";
                var allTrials = [];
                Object.keys(data).forEach(function (key) {
                    var d = data[key];
                    if (d.trials) allTrials = allTrials.concat(d.trials);
                    else if (Array.isArray(d)) allTrials = allTrials.concat(d);
                });
                if (allTrials.length > 0) {
                    document.getElementById("expBEmpty").style.display = "none";
                    document.getElementById("expBResults").style.display = "block";
                    renderResults(allTrials);
                } else {
                    status.textContent = "No trial data found in saved results.";
                }
            })
            .catch(function () { status.textContent = "Failed to load."; });
    }

    function renderResults(trials) {
        if (!trials.length) return;

        var regrets = [];
        var contractions = [];
        var finalRegrets = [];
        var accuracies = [];
        var finalContractions = [];

        trials.forEach(function (trial, idx) {
            var regretTraj = trial.regret_trajectory || [];
            var contrTraj = trial.contraction_trajectory || [];

            if (regretTraj.length > 0) {
                regrets.push({
                    label: "Trial " + (idx + 1),
                    data: regretTraj,
                    borderWidth: 1.5,
                    fill: false,
                    tension: 0.1
                });
                finalRegrets.push(regretTraj[regretTraj.length - 1]);
            } else if (trial.cumulative_regret != null) {
                finalRegrets.push(trial.cumulative_regret);
            }

            if (contrTraj.length > 0) {
                contractions.push({
                    label: "Trial " + (idx + 1),
                    data: contrTraj,
                    borderWidth: 1.5,
                    fill: false,
                    tension: 0.1
                });
                finalContractions.push(contrTraj[contrTraj.length - 1]);
            } else if (trial.final_sigma_trace != null) {
                finalContractions.push(trial.final_sigma_trace);
            }

            if (trial.final_prediction_accuracy != null) {
                accuracies.push(trial.final_prediction_accuracy);
            }
        });

        if (regretChart) regretChart.destroy();
        if (regrets.length > 0) {
            var maxLen = Math.max.apply(null, regrets.map(function (r) { return r.data.length; }));
            var labels = Array.from({ length: maxLen }, function (_, i) { return i + 1; });
            var ctx = document.getElementById("regretChart").getContext("2d");
            regretChart = new Chart(ctx, {
                type: "line",
                data: { labels: labels, datasets: regrets },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: { title: { display: true, text: "Interaction" } },
                        y: { title: { display: true, text: "Cumulative Regret" }, beginAtZero: true }
                    },
                    plugins: { legend: { display: trials.length <= 10 } }
                }
            });
        }

        if (contractionChart) contractionChart.destroy();
        if (contractions.length > 0) {
            var maxLen2 = Math.max.apply(null, contractions.map(function (c) { return c.data.length; }));
            var labels2 = Array.from({ length: maxLen2 }, function (_, i) { return i + 1; });
            var ctx2 = document.getElementById("contractionChart").getContext("2d");
            contractionChart = new Chart(ctx2, {
                type: "line",
                data: { labels: labels2, datasets: contractions },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: { title: { display: true, text: "Interaction" } },
                        y: { title: { display: true, text: "Posterior Trace (tr Σ)" }, beginAtZero: true }
                    },
                    plugins: { legend: { display: trials.length <= 10 } }
                }
            });
        }

        var avgRegret = finalRegrets.length > 0 ?
            (finalRegrets.reduce(function (a, b) { return a + b; }, 0) / finalRegrets.length).toFixed(2) : "--";
        var avgAcc = accuracies.length > 0 ?
            ((accuracies.reduce(function (a, b) { return a + b; }, 0) / accuracies.length) * 100).toFixed(1) + "%" : "--";
        var avgContr = finalContractions.length > 0 ?
            (finalContractions.reduce(function (a, b) { return a + b; }, 0) / finalContractions.length).toFixed(3) : "--";

        document.getElementById("bRegret").textContent = avgRegret;
        document.getElementById("bAccuracy").textContent = avgAcc;
        document.getElementById("bContraction").textContent = avgContr;

        document.getElementById("trialTable").innerHTML = trials.map(function (trial, idx) {
            var regretTraj = trial.regret_trajectory || [];
            var contrTraj = trial.contraction_trajectory || [];
            var finalR = regretTraj.length > 0 ? regretTraj[regretTraj.length - 1].toFixed(2) :
                (trial.cumulative_regret != null ? trial.cumulative_regret.toFixed(2) : "--");
            var acc = trial.final_prediction_accuracy != null ?
                (trial.final_prediction_accuracy * 100).toFixed(1) + "%" : "--";
            var contr = contrTraj.length > 0 ? contrTraj[contrTraj.length - 1].toFixed(3) :
                (trial.final_sigma_trace != null ? trial.final_sigma_trace.toFixed(3) : "--");
            var steps = trial.n_steps || regretTraj.length || "--";
            return '<tr><td>' + (idx + 1) + '</td>' +
                '<td>' + finalR + '</td>' +
                '<td>' + acc + '</td>' +
                '<td>' + contr + '</td>' +
                '<td>' + steps + '</td></tr>';
        }).join("");
    }

    function escapeHtml(str) {
        var div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }
})();
