"""
CASPER Scene Provider — Benchmark Scene Metadata
==================================================

Provides rich scene object data for grounding repair commands.

"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from casper.llm_interface import LLMBackend

logger = logging.getLogger(__name__)

# Path to bundled scene cache (pre-extracted benchmark object lists)
_SCENE_CACHE_PATH = Path(__file__).parent / "data" / "scene_cache.json"

# Benchmark floorplan number ranges → room types
_ROOM_TYPE_RANGES = [
    (1, 30, "Kitchen"),
    (201, 230, "Living Room"),
    (301, 330, "Bedroom"),
    (401, 430, "Bathroom"),
]

# Object property knowledge base — known affordances for common benchmark objects.
# Used when loading from cache (which only has object names, not full metadata).
_OBJECT_PROPERTIES: dict[str, dict] = {
    # Utensils / sharp
    "Knife":        {"pickupable": True, "sharp": True, "hazard": "cut"},
    "ButterKnife":  {"pickupable": True, "sharp": False},
    "Fork":         {"pickupable": True, "sharp": True, "hazard": "poke"},
    "Spoon":        {"pickupable": True},
    "Spatula":      {"pickupable": True},
    "Ladle":        {"pickupable": True},
    # Containers
    "Plate":        {"pickupable": True, "receptacle": True, "breakable": True},
    "Bowl":         {"pickupable": True, "receptacle": True, "breakable": True},
    "Mug":          {"pickupable": True, "receptacle": True, "breakable": True},
    "Cup":          {"pickupable": True, "receptacle": True, "breakable": True},
    "Pot":          {"pickupable": True, "receptacle": True, "heatable": True},
    "Pan":          {"pickupable": True, "receptacle": True, "heatable": True},
    # Food
    "Apple":        {"pickupable": True, "sliceable": True, "food": True, "hazard": "choking"},
    "Bread":        {"pickupable": True, "sliceable": True, "food": True},
    "BreadSliced":  {"pickupable": True, "food": True},
    "Egg":          {"pickupable": True, "breakable": True, "food": True, "hazard": "choking"},
    "Tomato":       {"pickupable": True, "sliceable": True, "food": True},
    "TomatoSliced": {"pickupable": True, "food": True},
    "Lettuce":      {"pickupable": True, "sliceable": True, "food": True},
    "LettuceSliced":{"pickupable": True, "food": True},
    "Potato":       {"pickupable": True, "sliceable": True, "food": True, "hazard": "choking"},
    "PotatoSliced": {"pickupable": True, "food": True},
    "AppleSliced":  {"pickupable": True, "food": True},
    # Appliances (hot/dangerous)
    "StoveBurner":  {"toggleable": True, "hot_when_on": True, "hazard": "burn"},
    "StoveKnob":    {"toggleable": True},
    "Microwave":    {"openable": True, "toggleable": True, "receptacle": True, "hazard": "burn"},
    "Toaster":      {"toggleable": True, "hazard": "burn"},
    "Oven":         {"openable": True, "toggleable": True, "receptacle": True, "hazard": "burn"},
    "CoffeeMachine":{"toggleable": True, "hazard": "burn"},
    "Fridge":       {"openable": True, "receptacle": True},
    "DishWasher":   {"openable": True, "toggleable": True, "receptacle": True},
    # Fixtures
    "Sink":         {"receptacle": True},
    "SinkBasin":    {"receptacle": True},
    "Faucet":       {"toggleable": True},
    "CounterTop":   {"receptacle": True},
    "DiningTable":  {"receptacle": True},
    "CoffeeTable":  {"receptacle": True},
    "SideTable":    {"receptacle": True},
    "Shelf":        {"receptacle": True},
    "Cabinet":      {"openable": True, "receptacle": True},
    "Drawer":       {"openable": True, "receptacle": True},
    "GarbageCan":   {"receptacle": True},
    # Liquids / chemicals
    "Bottle":       {"pickupable": True, "breakable": True, "hazard": "poisoning"},
    "WineBottle":   {"pickupable": True, "breakable": True, "hazard": "poisoning"},
    "SprayBottle":  {"pickupable": True, "hazard": "poisoning"},
    "SoapBottle":   {"pickupable": True, "hazard": "poisoning"},
    "SoapBar":      {"pickupable": True},
    # Bedroom / living
    "Candle":       {"pickupable": True, "hazard": "burn"},
    "FloorLamp":    {"toggleable": True, "hazard": "fall"},
    "DeskLamp":     {"toggleable": True, "pickupable": True},
    "Vase":         {"pickupable": True, "breakable": True, "hazard": "cut"},
    "Statue":       {"pickupable": True, "breakable": True},
    "Book":         {"pickupable": True},
    "Pillow":       {"pickupable": True},
    "Box":          {"pickupable": True, "openable": True, "receptacle": True},
    "RemoteControl":{"pickupable": True, "hazard": "choking"},
    "CellPhone":    {"pickupable": True, "hazard": "choking"},
    "AlarmClock":   {"pickupable": True},
    "Pen":          {"pickupable": True, "hazard": "poke"},
    "Laptop":       {"pickupable": True},
    "Television":   {"toggleable": True},
    # Bathroom
    "Bathtub":      {"receptacle": True, "hazard": "drowning"},
    "ShowerHead":   {"toggleable": True},
    "Toilet":       {"openable": True, "receptacle": True, "hazard": "drowning"},
    "ToiletPaper":  {"pickupable": True},
    "Towel":        {"pickupable": True},
    "TowelHolder":  {},
    "Plunger":      {"pickupable": True},
    "Mirror":       {"breakable": True},
    # Furniture
    "Bed":          {"receptacle": True},
    "Dresser":      {"receptacle": True},
    "Sofa":         {"receptacle": True},
    "Chair":        {"pickupable": False},
    "Stool":        {"pickupable": False},
    "Window":       {"openable": True, "breakable": True},
    "Blinds":       {"openable": True},
    "Cloth":        {"pickupable": True},
    "Painting":     {"pickupable": False},
    "HousePlant":   {"pickupable": True},
    "LightSwitch":  {"toggleable": True},
    # Seasonings
    "PepperShaker": {"pickupable": True},
    "SaltShaker":   {"pickupable": True},
    "DishSponge":   {"pickupable": True},
    "CuttingBoard": {"pickupable": True, "receptacle": True},
}


@dataclass
class SceneObject:
    """An object in a scene with its known properties."""
    name: str
    category: str           # utensil, container, food, appliance, fixture, etc.
    properties: dict = field(default_factory=dict)

    @property
    def is_hazardous(self) -> bool:
        return "hazard" in self.properties

    @property
    def hazard_type(self) -> Optional[str]:
        return self.properties.get("hazard")

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "category": self.category,
            "properties": self.properties,
        }


@dataclass
class Scene:
    """A loaded scene with objects, context, and metadata."""
    scene_id: str
    room_type: str
    objects: list[SceneObject]
    source: str                 # "ai2thor", "cache", or "curated"
    description: str = ""

    @property
    def object_names(self) -> list[str]:
        """Sorted list of object type names."""
        return sorted(set(obj.name for obj in self.objects))

    @property
    def hazardous_objects(self) -> list[SceneObject]:
        """Objects with known hazard properties."""
        return [obj for obj in self.objects if obj.is_hazardous]

    @property
    def scene_context(self) -> str:
        """
        Rich text scene description suitable for LLM prompts.

        Includes room type, object inventory, and hazard-relevant details.
        """
        lines = [f"Room: {self.room_type} ({self.scene_id})"]

        if self.description:
            lines.append(f"Description: {self.description}")

        lines.append(f"\nObjects in scene ({len(self.object_names)}):")
        for name in self.object_names:
            obj = next(o for o in self.objects if o.name == name)
            props = []
            if obj.properties.get("pickupable"):
                props.append("pickupable")
            if obj.properties.get("openable"):
                props.append("openable")
            if obj.properties.get("toggleable"):
                props.append("toggleable")
            if obj.properties.get("breakable"):
                props.append("breakable")
            if obj.properties.get("sliceable"):
                props.append("sliceable")
            if obj.properties.get("sharp"):
                props.append("sharp")
            if obj.properties.get("hot_when_on"):
                props.append("hot when on")
            if obj.properties.get("hazard"):
                props.append(f"hazard: {obj.properties['hazard']}")
            prop_str = f" [{', '.join(props)}]" if props else ""
            lines.append(f"  - {name} ({obj.category}){prop_str}")

        return "\n".join(lines)

    @property
    def object_properties(self) -> dict[str, dict]:
        """Dict mapping object name → properties."""
        return {obj.name: obj.properties for obj in self.objects}

    def to_dict(self) -> dict:
        return {
            "scene_id": self.scene_id,
            "room_type": self.room_type,
            "source": self.source,
            "objects": [obj.to_dict() for obj in self.objects],
            "object_names": self.object_names,
        }


def _infer_room_type(scene_id: str) -> str:
    """Infer room type from benchmark floorplan number."""
    try:
        num = int("".join(c for c in scene_id if c.isdigit()))
        for lo, hi, room_type in _ROOM_TYPE_RANGES:
            if lo <= num <= hi:
                return room_type
    except ValueError:
        pass
    return "Room"


def _categorize_object(name: str) -> str:
    """Assign a semantic category to an object by name."""
    name_lower = name.lower()
    if any(k in name_lower for k in ("knife", "fork", "spoon", "spatula", "ladle")):
        return "utensil"
    if any(k in name_lower for k in ("pot", "pan", "bowl", "cup", "mug", "plate")):
        return "container"
    if any(k in name_lower for k in ("stove", "microwave", "toaster", "oven",
                                      "fridge", "coffee", "dishwasher")):
        return "appliance"
    if any(k in name_lower for k in ("apple", "bread", "egg", "tomato",
                                      "potato", "lettuce")):
        return "food"
    if any(k in name_lower for k in ("bottle", "soap", "spray", "shaker")):
        return "liquid/chemical"
    if any(k in name_lower for k in ("sink", "counter", "table", "shelf",
                                      "cabinet", "drawer", "garbage")):
        return "fixture"
    if any(k in name_lower for k in ("lamp", "candle", "light")):
        return "lighting"
    if any(k in name_lower for k in ("bathtub", "shower", "toilet")):
        return "plumbing"
    return "object"


def _build_scene_object(name: str) -> SceneObject:
    """Create a SceneObject from a name using the property knowledge base."""
    props = _OBJECT_PROPERTIES.get(name, {})
    category = _categorize_object(name)
    return SceneObject(name=name, category=category, properties=dict(props))


class SceneProvider:

    def __init__(
        self,
        cache_path: Path | str | None = None,
        force_cache: bool = False,
        vlm_backend: LLMBackend | None = None,
    ):
        self._cache_path = Path(cache_path) if cache_path else _SCENE_CACHE_PATH
        self._force_cache = force_cache
        self._vlm_backend = vlm_backend
        self._cache: dict | None = None
        self._controller = None
        self._ai2thor_available: bool | None = None

    @property
    def ai2thor_available(self) -> bool:
        """Check if the simulator is available on this platform."""
        if self._ai2thor_available is not None:
            return self._ai2thor_available

        # Simulator requires Linux
        if os.name == "nt":
            self._ai2thor_available = False
            logger.info("Simulator not available on Windows — using scene cache")
            return False

        if self._force_cache:
            self._ai2thor_available = False
            return False

        try:
            import ai2thor  # noqa: F401
            self._ai2thor_available = True
            logger.info("Simulator available")
        except ImportError:
            self._ai2thor_available = False
            logger.info("Simulator not installed — using scene cache")

        return self._ai2thor_available

    def _load_cache(self) -> dict:
        """Load and cache the scene cache JSON."""
        if self._cache is not None:
            return self._cache

        if self._cache_path.exists():
            with open(self._cache_path) as f:
                self._cache = json.load(f)
            logger.info(f"Loaded scene cache: {len(self._cache)} scenes")
        else:
            logger.warning(f"Scene cache not found at {self._cache_path}")
            self._cache = {}

        return self._cache

    def _ensure_controller(self):
        """Lazily initialize simulator controller."""
        if self._controller is not None:
            return self._controller

        from ai2thor.controller import Controller
        self._controller = Controller(
            width=1280,
            height=720,
            headless=True,
            renderDepthImage=False,
            renderInstanceSegmentation=False,
        )
        logger.info("Simulator controller initialized")
        return self._controller

    def available_scenes(self) -> list[str]:
        """List all available scene IDs."""
        cache = self._load_cache()

        # Cache keys are like "floorplan_1" → convert to "FloorPlan1"
        scenes = []
        for key in sorted(cache.keys()):
            # Convert "floorplan_1" → "FloorPlan1"
            parts = key.split("_")
            if len(parts) == 2 and parts[0] == "floorplan":
                scenes.append(f"FloorPlan{parts[1]}")
            else:
                scenes.append(key)

        return scenes

    def _cache_key(self, scene_id: str) -> str:
        """Convert scene ID to cache key format."""
        # "FloorPlan1" → "floorplan_1", "FloorPlan201" → "floorplan_201"
        import re
        match = re.match(r"FloorPlan(\d+)", scene_id)
        if match:
            return f"floorplan_{match.group(1)}"
        return scene_id.lower().replace(" ", "_")

    def load_scene(self, scene_id: str) -> Scene:
        # Level 1: Live simulator (if available)
        if self.ai2thor_available:
            try:
                return self._load_from_ai2thor(scene_id)
            except Exception as e:
                logger.warning(f"Simulator load failed for {scene_id}: {e}. Falling back to cache.")

        # Level 2: Scene cache
        scene = self._load_from_cache(scene_id)
        if scene is not None:
            return scene

        # Level 3: Curated scenes
        scene = self._load_from_curated(scene_id)
        if scene is not None:
            return scene

        # Nothing found — return empty scene
        logger.warning(f"No scene data found for {scene_id}")
        return Scene(
            scene_id=scene_id,
            room_type=_infer_room_type(scene_id),
            objects=[],
            source="empty",
            description=f"Unknown scene: {scene_id}",
        )

    def _load_from_ai2thor(self, scene_id: str) -> Scene:
        """Load scene from live simulator controller."""
        controller = self._ensure_controller()
        controller.reset(scene_id)
        metadata = controller.last_event.metadata

        objects = []
        seen_types = set()
        for obj in metadata.get("objects", []):
            obj_type = obj["objectType"]
            if obj_type in seen_types:
                continue  # One entry per type
            seen_types.add(obj_type)

            props = {
                "pickupable": obj.get("pickupable", False),
                "openable": obj.get("openable", False),
                "toggleable": obj.get("toggleable", False),
                "breakable": obj.get("breakable", False),
                "sliceable": obj.get("sliceable", False),
                "receptacle": obj.get("receptacle", False),
                "temperature": obj.get("temperature", "RoomTemp"),
            }
            # Merge known hazard info
            known = _OBJECT_PROPERTIES.get(obj_type, {})
            if "hazard" in known:
                props["hazard"] = known["hazard"]
            if "sharp" in known:
                props["sharp"] = known["sharp"]
            if "hot_when_on" in known:
                props["hot_when_on"] = known["hot_when_on"]

            objects.append(SceneObject(
                name=obj_type,
                category=_categorize_object(obj_type),
                properties=props,
            ))

        room_type = _infer_room_type(scene_id)
        return Scene(
            scene_id=scene_id,
            room_type=room_type,
            objects=sorted(objects, key=lambda o: o.name),
            source="ai2thor",
            description=f"{room_type} scene loaded from simulator",
        )

    def _load_from_cache(self, scene_id: str) -> Scene | None:
        """Load scene from pre-extracted cache."""
        cache = self._load_cache()
        key = self._cache_key(scene_id)

        if key not in cache:
            return None

        entry = cache[key]
        object_names = entry.get("objects", [])
        objects = [_build_scene_object(name) for name in object_names]

        room_type = _infer_room_type(scene_id)
        return Scene(
            scene_id=scene_id,
            room_type=room_type,
            objects=sorted(objects, key=lambda o: o.name),
            source="cache",
            description=f"{room_type} with {len(objects)} objects (from scene cache)",
        )

    def _load_from_curated(self, scene_id: str) -> Scene | None:
        """Load from curated scene definitions."""
        return None

    def load_scene_from_image(
        self,
        image: str | bytes,
        scene_id: str = "vlm_scene",
        context_hint: str = "",
        backend: LLMBackend | None = None,
    ) -> Scene:
        vlm = backend or self._vlm_backend
        if vlm is None:
            raise ValueError(
                "No VLM backend configured. Pass a vision-capable LLMBackend "
                "via backend= or set vlm_backend in SceneProvider constructor."
            )
        from casper.vlm_scene import perceive_scene
        scene = perceive_scene(vlm, image, context_hint=context_hint)
        scene.scene_id = scene_id
        return scene

    def get_scene_context(self, scene_id: str) -> str:
        """Convenience: load scene and return its context string."""
        return self.load_scene(scene_id).scene_context

    def get_object_names(self, scene_id: str) -> list[str]:
        """Convenience: load scene and return sorted object names."""
        return self.load_scene(scene_id).object_names

    def close(self) -> None:
        """Close simulator controller if running."""
        if self._controller is not None:
            try:
                self._controller.stop()
            except Exception:
                pass
            self._controller = None
