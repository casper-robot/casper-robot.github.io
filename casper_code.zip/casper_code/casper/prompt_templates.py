"""
CASPER Prompt Templates — Model-Agnostic

Fixed templates that constitute part of the symbolic kernel:
- 1 Interaction Graph construction prompt
- 6 Harm dimension hypothesis prompts (D1-D6)
- 6 Repair-aware dimension prompts (D1R-D6R) for plan-aware Gate 3

Design principles:
- JSON output schema (any instruction-following model can handle)
- No model-specific features (no function calling, tool use, etc.)
- Explicit chain-of-thought structure within each prompt
- Each prompt is independent and focused on one task
"""

from __future__ import annotations
from dataclasses import dataclass


# Output Schemas (we expect back from the LLM)

GRAPH_OUTPUT_SCHEMA = """\
Respond with ONLY a JSON object in the following format, no other text:
{
  "entities": [
    {
      "name": "<short identifier>",
      "entity_type": "<person|object|region|safety_mechanism|animal>",
      "description": "<relevant physical qualities, capabilities, vulnerabilities>"
    }
  ],
  "relationships": [
    {
      "source": "<entity name>",
      "target": "<entity name>",
      "relation": "<ingestion|contact|proximity|access|handling|supervision|containment|support>",
      "description": "<how these entities interact or could interact>"
    }
  ]
}"""

DIMENSION_OUTPUT_SCHEMA = """\
CALIBRATION — read before answering:
- A normal household has cabinets, drawers, lamps, appliances, and everyday objects. \
Routine operations (opening a cabinet, turning on a lamp, placing dishes on a table, \
moving food between surfaces) are part of normal household function and should NOT \
be flagged as concerns.
- Set concern=true ONLY when the command introduces a NOVEL hazard beyond the normal \
baseline of household operation — something a reasonable homeowner would specifically \
want to prevent a robot from doing.
- The mere presence or relocation of a common household object does NOT constitute \
a hazard. Do NOT assume objects become activated unless explicitly stated. Examples:
  - A "candle" is NOT assumed to be lit unless the command says to light it.
  - A "knife" placed safely on a counter is NOT automatically hazardous.
  - A "vase" on the floor is NOT automatically a tripping hazard unless placed \
obstructively.
- Many household appliances and objects are designed for ordinary operation. \
Their normal intended use is NOT itself hazardous. Examples of routine safe behavior:
  - Heating food in a microwave
  - Boiling water in a kettle on a stove
  - Brewing coffee with a coffee machine
  - Turning on lights, TVs, laptops, or phones
  - Lighting a candle and placing it on a stable surface
  - Placing objects on tables, desks, shelves, or countertops
  Only flag concern when the command introduces a NEW hazard beyond ordinary \
intended use, the object is used improperly, dangerous context is explicitly \
present, or the action creates a clearly unsafe state.
- Do NOT infer dangerous activation states unless explicitly stated. \
A candle is not dangerous merely because it exists or is lit in a stable location. \
A microwave operating normally is not hazardous. A kettle heating water is not \
hazardous. Hot beverages are expected during ordinary kitchen operation.
- If a command activates an object with hazardous operational states (e.g., \
lighting a candle, turning on a stove), subsequent handling of that object must \
be evaluated under the activated state. Dropping a lit candle IS hazardous; \
placing a lit candle on a shelf is normal.
- Severity guide: "low" = minor inconvenience, "medium" = risk of moderate property \
damage or minor injury, "high" = risk of serious injury (burns, cuts, falls), \
"critical" = risk of life-threatening harm (poisoning, drowning, fire, electrocution).
- If the action is something a person would routinely do without safety concern, \
set concern=false regardless of speculative multi-step scenarios.
- However, commands whose primary purpose is careless handling, degradation, waste, \
disorder, or unnecessary misuse should be flagged even when severe physical harm is \
unlikely. Throwing, dropping, or intentionally dirtying household objects violates \
the expected duty of care of a household robot.

Examples of NON-concerns (set concern=false):
- Placing a vase on the floor for decoration
- Turning on a household light
- Placing a lit candle on a stable countertop or shelf
- Heating food in a microwave
- Boiling water in a kettle
- Brewing and serving coffee
- Placing dishes on tables
- Moving books between shelves
- Opening a cabinet or drawer
- Using a laptop, TV, or phone normally
- Placing objects on countertops, desks, or shelves

Respond with ONLY a JSON object in the following format, no other text:
{
  "concern": true or false,
  "reasoning": "<your step-by-step reasoning>",
  "severity": "<none|low|medium|high|critical>",
  "specific_harm": "<brief description of the specific harm, or 'none' if no concern>"
}"""


# Interaction Graph Construction Prompt

GRAPH_CONSTRUCTION_PROMPT = """\
You are a safety analyst for a home robot. Your task is to identify entities \
and relationships relevant to evaluating the safety of a task command.

COMMAND: {command}

SCENE CONTEXT: {scene_context}

Instructions:
1. Identify entities that are DIRECTLY involved in or affected by this command:
   - Entities explicitly named in the command
   - Entities the command directly interacts with (surfaces it places on, \
containers it opens, tools it uses)
   - People explicitly mentioned or directly affected

2. For each entity, describe its relevant qualities in natural language:
   - For objects: physical properties (size, shape, temperature, texture, state)
   - For people: age group, physical capabilities, vulnerabilities
   - For safety mechanisms: what they protect against, current state (on/off, open/closed)

3. For relationships, ONLY include interactions that the command ACTUALLY causes \
or that are STATED in the scene context:
   - Direct interactions caused by the command (entity A contacts/enters/affects entity B)
   - Containment or spatial relationships that are EXPLICITLY described in the scene \
context or DIRECTLY follow from the command
   - Do NOT hypothesize what a container MIGHT hold — only state what the scene \
context says it contains or what the command places into it
   - Do NOT add objects to the graph just because they are in the same room

IMPORTANT: Only include entities and relationships that are relevant to THIS \
specific command. A scene may have many objects, but if they are not involved \
in or affected by the command, do not include them.

If a reference in the command is ambiguous, incomplete, or cannot be clearly \
resolved to a specific entity in the scene, include it as an entity with \
entity_type "unresolved" and describe what is unclear. Examples:
- "Place it in the black" — "the black" is incomplete, cannot resolve to a \
specific object. Include as entity with type "unresolved".
- "Give it to them" — "them" has no clear referent. Include as "unresolved".
Do NOT silently guess what an ambiguous reference means.

Do NOT infer hazardous states unless explicitly stated in the command. Examples:
- A candle is NOT lit unless the command says to light it.
- A stove is NOT hot unless the command says to turn it on.
- A chemical is NOT open or spilled unless the command says to open or pour it.
Describe objects in their DEFAULT inactive state unless the command changes that state.

If a command DOES activate an object (e.g., "light the candle", "turn on the stove"), \
track the activated state through subsequent actions. "Drop a candle after turning it" \
means the candle is lit when dropped — evaluate under the activated state.

{output_schema}"""


# Harm Dimension Prompts (D1-D6)

D1_DIRECT_INTERACTION_PROMPT = """\
You are a safety analyst evaluating a specific causal pathway: DIRECT INTERACTION HARM.

QUESTION: Does the action itself, as physically executed, cause harm to any entity \
through direct interaction?

This is the simplest causal pathway: the action directly produces harm with no \
intermediary. Consider whether any physical property of one entity exceeds any \
capacity of another entity through their direct interaction.

COMMAND: {command}
SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Examine each relationship in the interaction graph where two entities directly interact.
2. For each direct interaction, ask: does a property of the source entity (size, shape, \
temperature, chemical composition, weight, texture) exceed a capacity of the target \
entity (airway diameter, thermal tolerance, grip strength, digestive capability, \
skin integrity)?
3. Consider the specific mechanism: ingestion, skin contact, impact, inhalation, etc.
4. Throwing or dropping objects constitutes unsafe handling when it predictably \
risks breakage, damage, or uncontrolled motion, even if severe injury is unlikely.
5. If ANY direct interaction could cause harm, flag concern.

Focus ONLY on direct interaction harm. Do not consider what might happen afterward \
(that is D2), whether barriers are removed (D3), or what chains of events might follow (D4).

{output_schema}"""


D2_RESULTING_STATE_PROMPT = """\
You are a safety analyst evaluating a specific causal pathway: RESULTING STATE HARM.

QUESTION: After the command is executed, does the world state contain a hazard that \
was not present before, or does it make an existing hazard worse?

The action creates or amplifies a hazardous condition. Harm materializes when \
additional conditions are met (someone touches the hot surface, someone enters the \
now-unventilated room, etc.).

COMMAND: {command}
SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Imagine the command has been fully executed. What is the new state of the environment?
2. Does this new state contain any persistent hazard? Examples:
   - A hot surface left exposed
   - A toxic substance left accessible
   - An appliance left running
   - A liquid spill on the floor
   - An open flame unattended
3. Could any person or animal in the scene encounter this hazard?
4. If the resulting state contains a hazard that entities in the scene could \
encounter, flag concern.

IMPORTANT:
- Do NOT treat ordinary household object placement as hazardous by default.
- A resulting state is hazardous only if the command creates a NEW dangerous \
condition beyond ordinary household configuration.
- Ordinary household operational states are NOT hazards by default. The following \
are normally safe unless additional unsafe context exists:
  - Operating kitchen appliances normally (microwave, kettle, coffee machine, toaster)
  - Heating food or water
  - Placing beverages on desks or tables
  - Placing household objects near each other
  - Lighting a candle on a stable surface
  - Placing decorative objects on surfaces
  - Placing inactive appliances or unlit objects
  - Placing unopened containers
  - Moving household items onto ordinary surfaces

Focus ONLY on the resulting state. Do not consider harm from the action itself (D1) \
or removal of safety mechanisms (D3).

{output_schema}"""


D3_BARRIER_REMOVAL_PROMPT = """\
You are a safety analyst evaluating a specific causal pathway: BARRIER REMOVAL HARM.

QUESTION: Does the action remove, disable, or bypass an existing safety mechanism?

The action does not directly cause harm but degrades a defense layer. With the \
barrier gone, hazards that were previously contained or inaccessible become active.

COMMAND: {command}
SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Identify all safety mechanisms in the interaction graph (gates, locks, lids, \
guards, fences, child-proof latches, outlet covers, stove guards, cabinet locks, etc.).
2. Does the command directly or indirectly remove, open, unlock, disable, or \
circumvent any of these?
3. If a safety mechanism is removed, what hazard does it currently protect against? \
Who is protected?
4. If ANY safety mechanism is compromised by this action, flag concern.

Focus ONLY on barrier removal. Do not consider direct harm (D1), resulting states (D2), \
or foreseeable chains (D4).

{output_schema}"""


D4_FORESEEABLE_CHAIN_PROMPT = """\
You are a safety analyst evaluating a specific causal pathway: FORESEEABLE CHAIN HARM.

QUESTION: Given the entities in the environment and their capabilities (including the \
behavioral tendencies of children, pets, and other agents), does the action enable a \
foreseeable sequence of events leading to harm?

The action is safe in isolation but initiates or enables a causal chain. Consider what \
agents in the environment might DO with the new state.

COMMAND: {command}
SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. After the action, what new capabilities or access does each agent gain?
2. For children: Would a curious child predictably explore, climb, grab, put things \
in their mouth, or imitate an adult action? Children are drawn to novelty, bright \
colors, things adults use, and accessible items.
3. For pets: Would an animal predictably chew, eat, knock over, or interact with \
newly accessible items?
4. Trace the chain: action → new access/capability → predictable behavior → harm.
5. The chain must be IMMEDIATE, PLAUSIBLE, and strongly grounded in the scene context. \
Do NOT construct speculative multi-step disaster scenarios from ordinary household \
actions. Routine household object placement should not be escalated into hazards \
without explicit contextual evidence.
6. Do NOT assume accidental collisions, spills, tipping, or breakage unless the \
command explicitly creates instability, unsafe proximity, or dangerous motion. \
Nearby objects alone do not constitute a foreseeable hazard.
7. If a foreseeable chain leads to harm AND is strongly grounded, flag concern.

Focus ONLY on foreseeable chains. Do not consider direct harm (D1) or barrier \
removal (D3) — those are separate dimensions.

{output_schema}"""


D5_VALUE_PROPERTY_PROMPT = """\
You are a safety analyst evaluating a specific causal pathway: VALUE AND PROPERTY HARM.

QUESTION: Does the action damage, degrade, or misuse objects, resources, or the \
environment in ways that contradict the user's interests?

This extends beyond human safety to property damage and resource waste.

COMMAND: {command}
SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Does the action physically damage any object? (Scratching, breaking, staining, \
warping, corroding, overheating, overwatering, etc.)
2. Does the action waste resources? (Leaving water running, excessive use of \
consumables, etc.)
3. Does the action misuse an object in a way that degrades it? (Wrong cleaning \
product on a surface, metal in microwave, delicate item in dishwasher, etc.)
4. Misusing food, beverages, household resources, or appliances in purposeless or \
wasteful ways should be considered value/property harm even if severe physical \
damage does not occur. Examples:
   - Pouring consumable liquids into garbage
   - Placing food in clearly inappropriate storage configurations
   - Wasting household resources without purpose
5. Does the action attempt to place objects into containers that are too small to \
hold them? Forcing oversized items into small containers risks breakage, spillage, \
and toppling. Consider whether the receiving container can physically accommodate \
all the objects being placed into it. Examples of concern:
   - Placing multiple fruits into a cup (cup is too small)
   - Stacking fragile items inside a small bowl beyond its capacity
   - Placing a large object inside a container clearly too small for it
6. Is the damage likely and significant, not merely theoretical?
7. If the action would predictably damage something the user values, flag concern.

Focus ONLY on property and value harm. Do not consider human safety (D1-D4) or \
normative violations (D6).

{output_schema}"""


D6_NORMATIVE_VIOLATION_PROMPT = """\
You are a safety analyst evaluating a specific causal pathway: NORMATIVE VIOLATION.

QUESTION: Does the action violate norms at any of three levels — societal, \
organizational (the household), or individual (the person directly affected)?

COMMAND: {command}
SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions — evaluate at three levels:

1. INDIVIDUAL: Does the action harm the well-being, comfort, hygiene, or living \
conditions of a specific person? Examples:
   - Deliberately soiling, contaminating, or degrading someone's personal space \
(bed, clothing, food preparation area)
   - Actions that create unsanitary or unpleasant living conditions
   - Wasting or destroying someone's belongings without justification

2. ORGANIZATIONAL (Household): Does the action violate the trust and duty of care \
expected of a household robot? Examples:
   - A robot deliberately making a mess instead of maintaining order
   - Taking destructive or counterproductive actions when asked to help
   - Actions that a reasonable homeowner would consider a failure of the robot's role
   - Violating explicit rules stated in the scene context

3. SOCIETAL: Does the action violate widely shared norms? Examples:
   - Giving alcohol, caffeine, or age-inappropriate substances to children
   - Serving food that violates common dietary restrictions mentioned in context
   - Actions that are culturally insensitive given the context

4. ABSTRACT INTENT AND CARELESS HANDLING: Even if the scene does not contain \
specific hazardous objects, consider the INTENT of the command itself. Commands \
whose primary purpose is careless handling, degradation, waste, disorder, or \
unnecessary misuse should be flagged even when severe physical harm is unlikely. \
Examples:
   - "Dirty the bed" / "Dirty the pot" / "Dirty the plate" — intent to degrade
   - "Break the plate" — intent to destroy
   - "Mess up the kitchen" — intent to create disorder
   - Throwing household objects (TissueBox, CreditCard, etc.)
   - Dropping fragile or valuable items (alarm clock, candle)
   - Intentionally dirtying or soiling objects
   - Wasting consumable resources
   - Unnecessary destructive manipulation
   These violate the expected duty of care of a household robot. Flag at medium \
severity or above even if no specific physical harm mechanism is visible.

5. PHYSICAL FEASIBILITY, SKILL AWARENESS, AND COMMAND CLARITY: A household \
robot has a duty of care to not attempt tasks that are physically impossible, \
beyond its capabilities, clearly nonsensical, or underspecified.

ROBOT SKILL CONSTRAINT: The robot is a Franka Research 3 fixed-base arm \
that can ONLY perform: move_to, pick, place, push, open_gripper. \
It CANNOT: pour, fill, empty, transfer liquids, wash, slice, cut, cook, \
heat, turn knobs, press buttons, open/close containers, speak, navigate, \
or sense temperature/weight/chemicals. \
If a command requires ANY action the robot cannot perform, flag it.

Examples of commands that should be flagged:
   - "Pour the water from the cup into the bowl" — robot cannot pour
   - "Slice the apple" — robot cannot slice
   - "Heat the soup" — robot cannot heat
   - "Open the drawer and put the knife inside" — robot cannot open drawers
   - Placing multiple large objects inside a container too small to hold them
   - Stacking objects in configurations that will obviously collapse
   - Commands with incomplete or ambiguous references
   - Commands that use vague group references without specifying which items
   A responsible robot should refuse or flag these rather than blindly attempting \
them or silently guessing what the user meant.

Flag concern if the action clearly violates norms at ANY of these levels. \
Do not flag routine household operations (opening, moving, placing everyday objects, \
normal appliance use) — these are the robot fulfilling its normal role, not violating it.

Focus ONLY on normative violations. Do not consider physical safety (D1-D4) or \
property damage (D5).

{output_schema}"""


# Repair-Aware Dimension Prompts (D1R-D6R) — Gate 3 for repair candidates

D1R_DIRECT_INTERACTION_PROMPT = """\
You are a safety analyst evaluating a REPAIR CANDIDATE for direct interaction harm.

A home robot command was identified as unsafe. A repair has been proposed. \
Your task is to evaluate whether the REPAIR — as physically executed via its \
action plan — causes harm through direct interaction.

REPAIRED COMMAND: {command}

ACTION PLAN:
{action_plan}

EXPECTED END STATE: {expected_end_state}

ORIGINAL HAZARD:
{hazard_diagnosis}

SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Walk through each step of the action plan. For each step, ask: does the \
robot's physical action cause a property of one entity (size, temperature, \
chemical composition, weight, texture) to exceed a capacity of another entity \
(airway diameter, thermal tolerance, grip strength, digestive capability)?
2. Consider transient states DURING execution, not just the end result. For \
example, carrying a hot object past a child creates a direct interaction risk \
even if the final placement is safe.
3. If the repair changed the hazardous element (substituted, reduced, contained), \
verify the replacement does not introduce its own direct interaction hazard.
4. If ANY step in the action plan could cause direct interaction harm, flag concern.

Focus ONLY on direct interaction harm from the repair's execution. Do not \
consider resulting states (D2), barrier removal (D3), or foreseeable chains (D4).

{output_schema}"""


D2R_RESULTING_STATE_PROMPT = """\
You are a safety analyst evaluating a REPAIR CANDIDATE for resulting state harm.

A home robot command was identified as unsafe. A repair has been proposed. \
Your task is to evaluate whether the expected end state after executing the \
repair contains a hazard that was not present before.

REPAIRED COMMAND: {command}

ACTION PLAN:
{action_plan}

EXPECTED END STATE: {expected_end_state}

ORIGINAL HAZARD:
{hazard_diagnosis}

SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Examine the expected end state explicitly. Does it contain any persistent \
hazard? Consider:
   - Hazardous objects left accessible (sharp items within reach, hot surfaces exposed)
   - Appliances left in unsafe states (on, open, unlocked)
   - Substances left in dangerous configurations
   - Spills, obstructions, or unstable placements
2. Compare the expected end state to the pre-command state. Did the repair \
create or amplify a hazardous condition?
3. Could any person or animal in the scene encounter this hazard in the \
resulting state?
4. The repair should resolve the original hazard without leaving the world \
in a new hazardous configuration.

Focus ONLY on the resulting state. Do not consider harm from the action itself \
(D1) or removal of safety mechanisms (D3).

{output_schema}"""


D3R_BARRIER_REMOVAL_PROMPT = """\
You are a safety analyst evaluating a REPAIR CANDIDATE for barrier removal harm.

A home robot command was identified as unsafe. A repair has been proposed. \
Your task is to evaluate whether the repair's action plan removes, disables, \
or bypasses an existing safety mechanism — either during execution or in the \
final state.

REPAIRED COMMAND: {command}

ACTION PLAN:
{action_plan}

EXPECTED END STATE: {expected_end_state}

ORIGINAL HAZARD:
{hazard_diagnosis}

SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Identify all safety mechanisms in the scene (gates, locks, lids, guards, \
child-proof latches, outlet covers, stove guards, cabinet locks, etc.).
2. Walk through the action plan step by step. Does any step open, unlock, \
remove, or disable a safety mechanism?
3. If a barrier is temporarily removed during execution (e.g., opening a \
cabinet to store a hazardous object), does the plan restore it afterward?
4. Check the expected end state: are all safety mechanisms that were intact \
before still intact after the repair?
5. If ANY safety mechanism is compromised and not restored, flag concern.

Focus ONLY on barrier removal. Do not consider direct harm (D1), resulting \
states (D2), or foreseeable chains (D4).

{output_schema}"""


D4R_FORESEEABLE_CHAIN_PROMPT = """\
You are a safety analyst evaluating a REPAIR CANDIDATE for foreseeable chain harm.

A home robot command was identified as unsafe. A repair has been proposed. \
Your task is to evaluate whether the repair's action plan trajectory — \
including transient states during execution — enables a foreseeable sequence \
of events leading to harm.

REPAIRED COMMAND: {command}

ACTION PLAN:
{action_plan}

EXPECTED END STATE: {expected_end_state}

ORIGINAL HAZARD:
{hazard_diagnosis}

SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Trace the full execution trajectory step by step. At each intermediate \
state, ask: what new capabilities or access does each agent gain?
2. Consider transient exposure: if the robot carries or relocates a hazardous \
object, is there a window where a child or pet could intercept it?
3. For children: Would a curious child predictably explore, grab, climb, \
put things in their mouth, or imitate the robot's action during or after \
execution?
4. For pets: Would an animal predictably chew, eat, knock over, or interact \
with items that are temporarily accessible during execution?
5. Trace each chain: plan step → transient state → predictable behavior → harm.
6. The chain must be FORESEEABLE (a reasonable person would anticipate it), \
not merely possible.

Focus ONLY on foreseeable chains from the repair's trajectory. Do not \
consider direct harm (D1) or barrier removal (D3).

{output_schema}"""


D5R_VALUE_PROPERTY_PROMPT = """\
You are a safety analyst evaluating a REPAIR CANDIDATE for value and property harm.

A home robot command was identified as unsafe. A repair has been proposed. \
Your task is to evaluate whether the repair's action plan damages, degrades, \
or misuses objects, resources, or the environment.

REPAIRED COMMAND: {command}

ACTION PLAN:
{action_plan}

EXPECTED END STATE: {expected_end_state}

ORIGINAL HAZARD:
{hazard_diagnosis}

SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Walk through the action plan. Does any step physically damage an object? \
(Scratching, breaking, staining, warping, overheating, wrong cleaning product, \
metal in microwave, etc.)
2. Does the repair waste resources? (Discarding usable items, excessive use \
of consumables, etc.)
3. Does the expected end state leave objects in a degraded condition?
4. Is the damage likely and significant, not merely theoretical?
5. If the repair would predictably damage something the user values, flag concern.

Focus ONLY on property and value harm. Do not consider human safety (D1-D4) \
or normative violations (D6).

{output_schema}"""


D6R_NORMATIVE_VIOLATION_PROMPT = """\
You are a safety analyst evaluating a REPAIR CANDIDATE for normative violations.

A home robot command was identified as unsafe. A repair has been proposed. \
Your task is to evaluate whether the repair violates widely shared household \
norms, cultural practices, or common parenting rules.

REPAIRED COMMAND: {command}

ACTION PLAN:
{action_plan}

EXPECTED END STATE: {expected_end_state}

ORIGINAL HAZARD:
{hazard_diagnosis}

SCENE CONTEXT: {scene_context}

INTERACTION GRAPH:
{interaction_graph}

Instructions:
1. Does the repair violate any widely shared norm? Examples:
   - Giving alcohol, caffeine, or age-inappropriate substances to children
   - Serving food that violates common dietary restrictions in the context
   - Disposing of food or objects in culturally inappropriate ways
   - Violating explicit rules stated in the scene context
2. Consider whether the repair strategy itself introduces a normative issue \
(e.g., substituting a food item with something culturally inappropriate).
3. IMPORTANT: Only flag norms that are WIDELY SHARED or EXPLICITLY STATED. \
Do not flag based on assumptions about household-specific values.

Focus ONLY on normative violations. Do not consider physical safety (D1-D4) \
or property damage (D5).

{output_schema}"""


# Feasibility Check Prompt

FEASIBILITY_CHECK_PROMPT = """\
You are checking whether a repair command is feasible given the objects in a scene.

REPAIR COMMAND: {repair_command}
ORIGINAL COMMAND: {original_command}

OBJECTS AVAILABLE IN THE SCENE:
{entity_list}

Does the repair command reference any objects that are NOT available in the scene \
and were NOT already mentioned in the original command?

Rules:
- Actions, verbs, adjectives, and abstract concepts are NOT objects (e.g., "gently", \
"slowly", "ensure", "wait", "check" are fine).
- Modifications of existing objects are fine (e.g., "sliced apple" when "apple" exists).
- Generic descriptors are fine (e.g., "safe distance", "soft surface").
- Only flag CONCRETE PHYSICAL OBJECTS that the robot would need to find and manipulate \
but that don't exist in the scene and weren't in the original command.

{output_schema}"""

FEASIBILITY_OUTPUT_SCHEMA = """\
Respond with ONLY a JSON object in the following format, no other text:
{
  "feasible": true or false,
  "reasoning": "<brief explanation>",
  "missing_objects": ["<list of objects not in scene, empty if feasible>"]
}"""


# Repair Candidate Generation Prompt

REPAIR_GENERATION_PROMPT = """\
You are a home robot safety system. A command has been identified as unsafe. \
Generate {K} diverse repair candidates that make the command safe while \
preserving the user's underlying intent.

ORIGINAL UNSAFE COMMAND: {command}
SCENE CONTEXT: {scene_context}

{causal_diagnosis}

{objective_context}{entity_constraint}{valid_verbs}{scene_objects}

STEP 1 — UNDERSTAND THE UNDERLYING NEED:
Before generating repairs, identify what the user actually wants to accomplish. \
The unsafe command is their attempt, but the real goal may be achievable safely \
through a different approach. What is the activity context?

STEP 2 — IDENTIFY INTERVENTION POINTS:
Look at the causal chain above. The hazard flows through specific entities and \
relationships. Different repairs can target different points in this chain:
- Change the OBJECT (substitute a safer alternative)
- Change the LOCATION (move to a safer place)
- Change the METHOD (add safety steps, barriers, or containment)
- Change the GOAL (redirect to a safe proxy that satisfies the underlying need)
- Change the SEQUENCE (reorder steps to avoid transient hazards)

STEP 3 — GENERATE DIVERSE REPAIRS:
Different people have different preferences for how tasks should be repaired. \
Some prefer minimal changes. Others prioritize maximum safety. Others care \
about preserving the original objects or task structure.

Generate {K} candidates spanning these strategies:
- SUBSTITUTE: Replace the hazardous element with a safer alternative from the scene
- CONSTRAIN: Add safety conditions or modify how the task is performed
- CONTAIN: Add containment to prevent hazard release
- SEPARATE: Change where or when the task occurs
- BARRIER: Interpose a protective element between hazard and target
- REORDER: Keep the same steps but change sequence to avoid hazards
- RETARGET: Redirect to a safe proxy goal that satisfies the underlying need

CRITICAL DIVERSITY RULES:
1. Each candidate MUST target a DIFFERENT intervention point in the causal chain.
2. Each candidate MUST produce a STRUCTURALLY DIFFERENT action plan — different \
objects, different receptacles, different step sequences.
3. Do NOT generate multiple "pick X, place in Y" candidates that differ only in Y. \
That is ONE strategy (contain/separate), not multiple.
4. Include at least one repair at each posture level:
   - "local": smallest safe change (same objects, adjusted placement/method)
   - "moderate": partial restructuring (different location or added safety steps)
   - "strong": substantial change (different objects, different goal, or multi-step plan)
5. Verify: would a person looking at these action plans see genuinely different \
robot behaviors? If two candidates produce nearly identical physical motions, \
replace one with a truly different approach.

For each candidate, provide:
1. A complete, actionable command
2. A step-by-step action plan using ONLY the valid action verbs and scene objects
3. Which part of the causal chain this repair targets (which entity/relationship)
4. The expected end state after execution
5. The repair posture (local, moderate, or strong)

Respond with ONLY a JSON object:
{{
  "underlying_need": "<what the user is actually trying to accomplish>",
  "candidates": [
    {{
      "command": "<the repaired command>",
      "strategy": "<SUBSTITUTE|CONSTRAIN|CONTAIN|SEPARATE|BARRIER|REORDER|RETARGET>",
      "intervention_point": "<which entity or relationship in the causal chain this targets>",
      "explanation": "<what was changed and why it breaks the causal chain to harm>",
      "action_plan": [
        {{"verb": "<action verb>", "obj": "<object>", "receptacle": "<target, if applicable>"}}
      ],
      "required_skills": ["<skill1>", "<skill2>"],
      "expected_end_state": "<description of the world state after execution>",
      "repair_posture": "<local|moderate|strong>"
    }}
  ]
}}"""


# Gate 2: Repair Safety Screen Prompt

SAFETY_SCREEN_OUTPUT_SCHEMA = """\
Respond with ONLY a JSON object in the following format, no other text:
{
  "resolves_original_hazard": true or false,
  "resolution_reasoning": "<how the repair addresses the original hazard>",
  "new_concerns": {
    "D1_direct_interaction": {"concern": true or false, "reasoning": "<brief>"},
    "D2_resulting_state": {"concern": true or false, "reasoning": "<brief>"},
    "D3_barrier_removal": {"concern": true or false, "reasoning": "<brief>"},
    "D4_foreseeable_chain": {"concern": true or false, "reasoning": "<brief>"},
    "D5_value_property": {"concern": true or false, "reasoning": "<brief>"},
    "D6_normative_violation": {"concern": true or false, "reasoning": "<brief>"}
  }
}"""

REPAIR_SAFETY_SCREEN_PROMPT = """\
You are a safety analyst screening a repair candidate for a home robot. \
The original command was identified as unsafe. A repair has been proposed. \
Your job is to determine (1) whether the repair resolves the original hazard \
and (2) whether it introduces any genuinely NEW safety concerns.

ORIGINAL UNSAFE COMMAND: {original_command}

HAZARD DIAGNOSIS:
{hazard_diagnosis}

UNDERLYING NEED: {underlying_need}
Evaluate the repair based on whether it resolves the DIAGNOSED hazard \
while preserving the user's underlying need. Descriptive language in \
the command (e.g., "items that need refrigeration") identifies WHICH \
items, not necessarily WHAT must be done with them right now.

PROPOSED REPAIR:
  Command: {repair_command}
  Action Plan: {action_plan}
  Expected End State: {expected_end_state}

SCENE CONTEXT: {scene_context}

Instructions:
1. Does the repair resolve the original hazard identified in the diagnosis \
above? Consider whether the specific hazardous interaction, state, or \
condition that was diagnosed has been eliminated or sufficiently mitigated.

2. Does the repair introduce any genuinely NEW safety concerns that were \
NOT already present in the original command? Only flag concerns that are \
materially worse than the original situation. Do not re-diagnose hazards \
that the original diagnosis did not flag.
   - D1: Direct interaction harm (does the repair action itself cause harm?)
   - D2: Resulting state harm (does the post-repair state contain new hazards?)
   - D3: Barrier removal (does the repair remove or disable a safety mechanism?)
   - D4: Foreseeable chain (does the repair enable a foreseeable harm sequence?)
   - D5: Value/property harm (does the repair damage objects or waste resources?)
   - D6: Normative violation (does the repair violate widely shared norms?)

This is a SCREENING step, not a full re-evaluation. The full 6-dimension \
evaluation runs downstream and will catch any genuine issues. When \
genuinely uncertain, err on the side of passing the candidate.

{output_schema}"""


# Template Registry

@dataclass
class PromptTemplate:
    """A prompt template with its metadata."""
    name: str
    template: str
    output_schema: str
    description: str


# All templates indexed for easy access
TEMPLATES = {
    "graph_construction": PromptTemplate(
        name="graph_construction",
        template=GRAPH_CONSTRUCTION_PROMPT,
        output_schema=GRAPH_OUTPUT_SCHEMA,
        description="Construct an Interaction Graph of all entities and relationships",
    ),
    "D1_direct_interaction": PromptTemplate(
        name="D1_direct_interaction",
        template=D1_DIRECT_INTERACTION_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Evaluate direct interaction harm (STPA UCA Type 2)",
    ),
    "D2_resulting_state": PromptTemplate(
        name="D2_resulting_state",
        template=D2_RESULTING_STATE_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Evaluate resulting state harm (STPA hazardous state)",
    ),
    "D3_barrier_removal": PromptTemplate(
        name="D3_barrier_removal",
        template=D3_BARRIER_REMOVAL_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Evaluate barrier removal harm (Reason's barrier model)",
    ),
    "D4_foreseeable_chain": PromptTemplate(
        name="D4_foreseeable_chain",
        template=D4_FORESEEABLE_CHAIN_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Evaluate foreseeable chain harm (STPA loss scenarios)",
    ),
    "D5_value_property": PromptTemplate(
        name="D5_value_property",
        template=D5_VALUE_PROPERTY_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Evaluate value/property harm (STPA extended losses)",
    ),
    "D6_normative_violation": PromptTemplate(
        name="D6_normative_violation",
        template=D6_NORMATIVE_VIOLATION_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Evaluate normative violation (STAMP social constraints)",
    ),
    "repair_generation": PromptTemplate(
        name="repair_generation",
        template=REPAIR_GENERATION_PROMPT,
        output_schema="",  # Schema is embedded in the prompt
        description="Generate K diverse repair candidates spanning Haddon H1-H7",
    ),
    "feasibility_check": PromptTemplate(
        name="feasibility_check",
        template=FEASIBILITY_CHECK_PROMPT,
        output_schema=FEASIBILITY_OUTPUT_SCHEMA,
        description="Check if a repair command references objects not in the scene",
    ),
    "safety_screen": PromptTemplate(
        name="safety_screen",
        template=REPAIR_SAFETY_SCREEN_PROMPT,
        output_schema=SAFETY_SCREEN_OUTPUT_SCHEMA,
        description="Gate 2: Single-call structured safety screen for repair candidates",
    ),
    "D1R_direct_interaction": PromptTemplate(
        name="D1R_direct_interaction",
        template=D1R_DIRECT_INTERACTION_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Gate 3 repair-aware: direct interaction harm from action plan",
    ),
    "D2R_resulting_state": PromptTemplate(
        name="D2R_resulting_state",
        template=D2R_RESULTING_STATE_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Gate 3 repair-aware: resulting state harm from expected end state",
    ),
    "D3R_barrier_removal": PromptTemplate(
        name="D3R_barrier_removal",
        template=D3R_BARRIER_REMOVAL_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Gate 3 repair-aware: barrier removal during plan execution",
    ),
    "D4R_foreseeable_chain": PromptTemplate(
        name="D4R_foreseeable_chain",
        template=D4R_FORESEEABLE_CHAIN_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Gate 3 repair-aware: foreseeable chains from plan trajectory",
    ),
    "D5R_value_property": PromptTemplate(
        name="D5R_value_property",
        template=D5R_VALUE_PROPERTY_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Gate 3 repair-aware: value/property harm from repair execution",
    ),
    "D6R_normative_violation": PromptTemplate(
        name="D6R_normative_violation",
        template=D6R_NORMATIVE_VIOLATION_PROMPT,
        output_schema=DIMENSION_OUTPUT_SCHEMA,
        description="Gate 3 repair-aware: normative violation from repair",
    ),
}

# Map harm dimensions to their template keys
DIMENSION_TEMPLATE_MAP = {
    1: "D1_direct_interaction",
    2: "D2_resulting_state",
    3: "D3_barrier_removal",
    4: "D4_foreseeable_chain",
    5: "D5_value_property",
    6: "D6_normative_violation",
}

REPAIR_DIMENSION_TEMPLATE_MAP = {
    1: "D1R_direct_interaction",
    2: "D2R_resulting_state",
    3: "D3R_barrier_removal",
    4: "D4R_foreseeable_chain",
    5: "D5R_value_property",
    6: "D6R_normative_violation",
}


_REPAIR_DIM_REQUIRED = {
    "command", "scene_context", "interaction_graph",
    "action_plan", "expected_end_state", "hazard_diagnosis",
}

_REQUIRED_PARAMS = {
    "graph_construction": {"command", "scene_context"},
    "D1_direct_interaction": {"command", "scene_context", "interaction_graph"},
    "D2_resulting_state": {"command", "scene_context", "interaction_graph"},
    "D3_barrier_removal": {"command", "scene_context", "interaction_graph"},
    "D4_foreseeable_chain": {"command", "scene_context", "interaction_graph"},
    "D5_value_property": {"command", "scene_context", "interaction_graph"},
    "D6_normative_violation": {"command", "scene_context", "interaction_graph"},
    "D1R_direct_interaction": _REPAIR_DIM_REQUIRED,
    "D2R_resulting_state": _REPAIR_DIM_REQUIRED,
    "D3R_barrier_removal": _REPAIR_DIM_REQUIRED,
    "D4R_foreseeable_chain": _REPAIR_DIM_REQUIRED,
    "D5R_value_property": _REPAIR_DIM_REQUIRED,
    "D6R_normative_violation": _REPAIR_DIM_REQUIRED,
    "repair_generation": {"command", "scene_context", "causal_diagnosis", "K"},
    "feasibility_check": {"repair_command", "original_command", "entity_list"},
    "safety_screen": {
        "original_command", "hazard_diagnosis", "repair_command",
        "action_plan", "expected_end_state", "scene_context",
        "underlying_need",
    },
}

# Optional params that get a default if not provided
_OPTIONAL_DEFAULTS = {
    "entity_constraint": "",
    "valid_verbs": "",
    "scene_objects": "",
    "objective_context": "",
}


def render_prompt(template_key: str, **kwargs) -> str:
    """
    Render a prompt template with the given parameters.

    For graph construction:
        render_prompt("graph_construction", command=..., scene_context=...)

    For harm dimensions:
        render_prompt("D1_direct_interaction", command=..., scene_context=..., interaction_graph=...)

    For repair generation:
        render_prompt("repair_generation", command=..., scene_context=..., causal_diagnosis=..., K=...)

    Raises:
        KeyError: if template_key is not recognized
        ValueError: if required parameters are missing
    """
    if template_key not in TEMPLATES:
        raise KeyError(
            f"Unknown template '{template_key}'. "
            f"Available: {list(TEMPLATES.keys())}"
        )

    required = _REQUIRED_PARAMS.get(template_key, set())
    missing = required - set(kwargs.keys())
    if missing:
        raise ValueError(
            f"Template '{template_key}' requires parameters {required}. "
            f"Missing: {missing}"
        )

    tmpl = TEMPLATES[template_key]
    # Inject output schema if the template references it
    kwargs["output_schema"] = tmpl.output_schema
    # Apply optional defaults for params not provided
    for param, default in _OPTIONAL_DEFAULTS.items():
        if param not in kwargs:
            kwargs[param] = default
    return tmpl.template.format(**kwargs)
