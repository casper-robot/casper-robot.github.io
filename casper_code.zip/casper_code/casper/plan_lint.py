"""
Gate 1: Plan Lint — Deterministic Repair Validation.

Validates repair action plans against the scene and robot capabilities.
Rejects structurally impossible repairs: nonexistent objects, invalid
verbs, violated holding constraints.

This is the canonical feasibility authority. Zero LLM calls.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from casper.safety_pipeline import RepairCandidate


@dataclass
class LintResult:
    """Result of deterministic plan validation."""
    passed: bool
    errors: list[str] = field(default_factory=list)


class PlanLinter:
    """Deterministic validation of repair action plans.

    Checks CanonicalAction typed fields directly — no string parsing.
    (1) Every verb is in the robot's valid set.
    (2) Every referenced object exists in the scene (fuzzy matching).
    (3) Every referenced receptacle exists in the scene (fuzzy matching).
    (4) Holding constraints are satisfied (pick before put, no double-hold).
    """

    def __init__(self, valid_actions: set[str], scene_objects: set[str]):
        self.valid_actions = {v.lower() for v in valid_actions}
        # Add verb aliases
        _aliases = {"place": "put", "put": "place", "move_to": "find", "find": "move_to"}
        for alias, canonical in _aliases.items():
            if canonical in self.valid_actions:
                self.valid_actions.add(alias)
        self.scene_objects = {s.lower() for s in scene_objects}

    def _match_entity(self, name: str) -> bool:
        """Fuzzy entity matching: exact, substring, or prefix match."""
        name_lower = name.lower().replace(" ", "").replace("_", "")
        if name_lower in self.scene_objects:
            return True
        for scene_obj in self.scene_objects:
            clean = scene_obj.replace(" ", "").replace("_", "")
            # Substring match (banana in bananas, or bananas contains banana)
            if name_lower in clean or clean in name_lower:
                return True
        return False

    def lint(self, candidate: RepairCandidate) -> LintResult:
        if not candidate.action_plan:
            return LintResult(passed=True)

        errors: list[str] = []
        held: str | None = None

        for action in candidate.action_plan:
            if action.verb.lower() not in self.valid_actions:
                errors.append(f"Unknown verb: {action.verb}")

            if action.obj and not self._match_entity(action.obj):
                errors.append(f"Object not in scene: {action.obj}")

            if action.receptacle and not self._match_entity(action.receptacle):
                errors.append(f"Receptacle not in scene: {action.receptacle}")

            verb_lower = action.verb.lower()
            if verb_lower in ("pick", "grab"):
                if held is not None:
                    errors.append(
                        f"Already holding {held}, cannot pick {action.obj}"
                    )
                held = action.obj
            elif verb_lower in ("put", "place", "drop", "throw", "open_gripper"):
                held = None

        return LintResult(passed=len(errors) == 0, errors=errors)
