"""
CASPER Safety Kernel — Symbolic Component

All deterministic logic for the safety subsystem:
- Interaction Graph construction
- Structurally forced 6-dimension evaluation (any-flag-unsafe)
- Safety margin computation

The six independent harm dimensions are the safety mechanism:
each dimension is a different expert perspective on the command.
One LLM call per dimension, structurally forced — no dimension
can be skipped. Unsafe if ANY dimension flags a concern.

"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum


# Interaction Graph

@dataclass
class Entity:
    """An entity node in the Interaction Graph."""
    name: str
    description: str  # Natural language description of relevant qualities
    entity_type: str  # e.g., "person", "object", "region", "safety_mechanism"

    def __eq__(self, other):
        if not isinstance(other, Entity):
            return False
        return self.name.lower().strip() == other.name.lower().strip()

    def __hash__(self):
        return hash(self.name.lower().strip())


@dataclass
class Relationship:
    """A directed relationship edge in the Interaction Graph."""
    source: str       # Entity name
    target: str       # Entity name
    relation: str     # e.g., "ingestion", "contact", "proximity", "access", "supervision"
    description: str  # Natural language description of the interaction

    def __eq__(self, other):
        if not isinstance(other, Relationship):
            return False
        return (
            self.source.lower().strip() == other.source.lower().strip()
            and self.target.lower().strip() == other.target.lower().strip()
            and self.relation.lower().strip() == other.relation.lower().strip()
        )

    def __hash__(self):
        return hash((
            self.source.lower().strip(),
            self.target.lower().strip(),
            self.relation.lower().strip(),
        ))


@dataclass
class InteractionGraph:
    """
    Interaction Graph G = (N, E_G).

    Lightweight natural language structure — entity descriptions and
    relationship labels in free text. This is the LLM's structured
    understanding of the situation, not a formal typed ontology.
    """
    entities: set[Entity] = field(default_factory=set)
    relationships: set[Relationship] = field(default_factory=set)

    def add_entity(self, entity: Entity) -> None:
        self.entities.add(entity)

    def add_relationship(self, relationship: Relationship) -> None:
        self.relationships.add(relationship)

    @staticmethod
    def union(graphs: list[InteractionGraph]) -> InteractionGraph:
        """
        Conservative union of multiple independently constructed graphs.

        G* = ( ⋃_n N_n,  ⋃_n E_n )

        If any single extraction identifies an entity or relationship,
        it is included. Failure mode is over-inclusion (extra harm
        evaluation, never a missed hazard).
        """
        merged = InteractionGraph()

        # For entities with same name but different descriptions,
        # keep the longest description (most informative).
        entity_map: dict[str, Entity] = {}
        for g in graphs:
            for e in g.entities:
                key = e.name.lower().strip()
                if key not in entity_map or len(e.description) > len(entity_map[key].description):
                    entity_map[key] = e
        merged.entities = set(entity_map.values())

        # For relationships, union by (source, target, relation) key.
        # Keep longest description.
        rel_map: dict[tuple, Relationship] = {}
        for g in graphs:
            for r in g.relationships:
                key = (r.source.lower().strip(), r.target.lower().strip(), r.relation.lower().strip())
                if key not in rel_map or len(r.description) > len(rel_map[key].description):
                    rel_map[key] = r
        merged.relationships = set(rel_map.values())

        return merged

    def entity_count(self) -> int:
        return len(self.entities)

    def relationship_count(self) -> int:
        return len(self.relationships)

    def get_entity(self, name: str) -> Optional[Entity]:
        for e in self.entities:
            if e.name.lower().strip() == name.lower().strip():
                return e
        return None

    def get_relationships_for(self, entity_name: str) -> list[Relationship]:
        """Get all relationships where entity is source or target."""
        name = entity_name.lower().strip()
        return [
            r for r in self.relationships
            if r.source.lower().strip() == name or r.target.lower().strip() == name
        ]

    def to_text(self) -> str:
        """Render graph as readable text for inclusion in prompts."""
        lines = ["ENTITIES:"]
        for e in sorted(self.entities, key=lambda x: x.name):
            lines.append(f"  - {e.name} [{e.entity_type}]: {e.description}")

        lines.append("\nRELATIONSHIPS:")
        for r in sorted(self.relationships, key=lambda x: (x.source, x.target)):
            lines.append(f"  - ({r.source} → {r.target}) [{r.relation}]: {r.description}")

        return "\n".join(lines)


# Harm Dimension Assessment

class HarmDimension(Enum):
    """Six harm dimensions derived from STPA/Reason."""
    D1_DIRECT_INTERACTION = 1   # STPA UCA Type 2
    D2_RESULTING_STATE = 2      # STPA hazardous state
    D3_BARRIER_REMOVAL = 3      # Reason's barrier model
    D4_FORESEEABLE_CHAIN = 4    # STPA loss scenarios
    D5_VALUE_PROPERTY = 5       # STPA extended losses
    D6_NORMATIVE_VIOLATION = 6  # STAMP social constraints


@dataclass
class DimensionAssessment:
    """LLM assessment for one harm dimension."""
    dimension: HarmDimension
    concern: bool                # Does this dimension identify a concern?
    reasoning: str               # Natural language reasoning trace
    severity: str = "unknown"    # "none", "low", "medium", "high", "critical"
    pass_id: int = 0             # Kept for backward compatibility


SEVERITY_ORDER = {"none": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def _severity_rank(severity: str) -> int:
    return SEVERITY_ORDER.get(severity.lower().strip(), 0)


@dataclass
class DimensionResult:
    """Result for one dimension (single assessment)."""
    dimension: HarmDimension
    assessments: list[DimensionAssessment] = field(default_factory=list)

    @property
    def flagged(self) -> bool:
        """Whether this dimension flagged a concern (any severity)."""
        return any(a.concern for a in self.assessments)

    def flagged_at(self, min_severity: str = "low") -> bool:
        """Whether this dimension flagged at or above the given severity."""
        threshold = _severity_rank(min_severity)
        return any(
            a.concern and _severity_rank(a.severity) >= threshold
            for a in self.assessments
        )

    @property
    def max_severity(self) -> str:
        """Highest severity among concerned assessments."""
        concerned = [a for a in self.assessments if a.concern]
        if not concerned:
            return "none"
        return max(concerned, key=lambda a: _severity_rank(a.severity)).severity

    @property
    def flag_count(self) -> int:
        return sum(1 for a in self.assessments if a.concern)

    @property
    def total_passes(self) -> int:
        return len(self.assessments)

    def is_flagged(self, k: int = 1) -> bool:
        """Backward-compatible: dimension flagged if any assessment has concern."""
        return self.flagged


# Safety Configuration & Aggregation

@dataclass
class SafetyConfig:
    min_severity: str = "medium"

    @staticmethod
    def fast() -> "SafetyConfig":
        """Backward-compatible: returns default config (already fast)."""
        return SafetyConfig()


@dataclass
class SafetyResult:
    """Complete safety evaluation result for a command."""
    command: str
    is_safe: bool
    safety_margin: float                          # SM ∈ [0, 1] for safe; 0 for unsafe
    dimension_results: dict[HarmDimension, DimensionResult] = field(default_factory=dict)
    interaction_graph: Optional[InteractionGraph] = None
    flagged_dimensions: list[HarmDimension] = field(default_factory=list)

    def summary(self) -> str:
        """Human-readable summary."""
        status = "SAFE" if self.is_safe else "UNSAFE"
        lines = [
            f"Safety Result: {status}",
            f"Command: {self.command}",
            f"Safety Margin: {self.safety_margin:.3f}" if self.is_safe else "Safety Margin: N/A (unsafe)",
        ]
        if self.flagged_dimensions:
            lines.append(f"Flagged Dimensions: {[d.name for d in self.flagged_dimensions]}")

        for dim in HarmDimension:
            if dim in self.dimension_results:
                dr = self.dimension_results[dim]
                flag_str = "FLAGGED" if dr.flagged else "clear"
                lines.append(f"  {dim.name}: {flag_str}")
        return "\n".join(lines)

    def hazard_summary(self) -> str:
        if self.is_safe:
            return "No hazards identified."

        lines = []
        for dim in self.flagged_dimensions:
            dr = self.dimension_results.get(dim)
            if dr is None:
                continue
            reasons = [
                a.reasoning for a in dr.assessments
                if a.concern and a.reasoning
            ]
            severity = max(
                (a.severity for a in dr.assessments if a.concern),
                key=lambda s: {"none": 0, "low": 1, "medium": 2,
                               "high": 3, "critical": 4, "unknown": 2}.get(s, 0),
                default="unknown",
            )
            representative = reasons[0] if reasons else "Concern flagged."
            lines.append(f"- {dim.name} (severity: {severity}): {representative}")

        return "\n".join(lines) if lines else "Hazards identified but no details available."

    def to_dict(self) -> dict:
        """Serialize to dictionary for logging and offline analysis."""
        dim_data = {}
        for dim, dr in self.dimension_results.items():
            dim_data[dim.name] = {
                "flagged": dr.flagged,
                "assessments": [
                    {
                        "concern": a.concern,
                        "severity": a.severity,
                        "reasoning": a.reasoning,
                    }
                    for a in dr.assessments
                ],
            }

        result = {
            "command": self.command,
            "is_safe": self.is_safe,
            "safety_margin": self.safety_margin,
            "flagged_dimensions": [d.name for d in self.flagged_dimensions],
            "dimensions": dim_data,
        }

        if self.interaction_graph:
            result["interaction_graph"] = {
                "entity_count": self.interaction_graph.entity_count(),
                "relationship_count": self.interaction_graph.relationship_count(),
                "entities": [
                    {"name": e.name, "type": e.entity_type, "description": e.description}
                    for e in sorted(self.interaction_graph.entities, key=lambda x: x.name)
                ],
                "relationships": [
                    {"source": r.source, "target": r.target,
                     "relation": r.relation, "description": r.description}
                    for r in sorted(self.interaction_graph.relationships,
                                    key=lambda x: (x.source, x.target))
                ],
            }

        return result


@dataclass
class HazardDiagnosis:
    hazardous_entities: set[str]
    hazardous_relationships: list[dict]
    flagged_dimensions: list[HarmDimension]
    dimension_reasoning: dict[HarmDimension, str]
    hazard_summary: str
    interaction_graph: InteractionGraph
    # Repair guidance (populated by derive_repair_guidance)
    preserve_slots: list[str] = field(default_factory=list)
    editable_slots: list[str] = field(default_factory=list)
    candidate_intervention_points: list[str] = field(default_factory=list)

    def to_prompt_context(self) -> str:
        """Render diagnosis as text for inclusion in repair/screen prompts."""
        lines = ["HAZARD DIAGNOSIS:"]
        lines.append(f"Flagged dimensions: {[d.name for d in self.flagged_dimensions]}")
        for dim, reasoning in self.dimension_reasoning.items():
            lines.append(f"  {dim.name}: {reasoning}")
        if self.hazardous_entities:
            lines.append(f"Hazardous entities: {', '.join(sorted(self.hazardous_entities))}")
        if self.hazardous_relationships:
            for rel in self.hazardous_relationships:
                lines.append(
                    f"  {rel['source']} --[{rel['relation']}]--> {rel['target']}: "
                    f"{rel.get('description', '')}"
                )
        if self.preserve_slots:
            lines.append(f"Preserve slots: {', '.join(self.preserve_slots)}")
        if self.editable_slots:
            lines.append(f"Editable slots: {', '.join(self.editable_slots)}")
        if self.candidate_intervention_points:
            lines.append(f"Intervention points: {', '.join(self.candidate_intervention_points)}")
        return '\n'.join(lines)


def derive_repair_guidance(
    diagnosis: HazardDiagnosis,
    task_frame,
) -> HazardDiagnosis:
    hazard_entity_lower = {e.lower() for e in diagnosis.hazardous_entities}
    task_objects_lower = {o.lower() for o in task_frame.objects}

    # Default: preserve the action
    diagnosis.preserve_slots = ["action"]

    # Determine editable slots based on hazard-task overlap
    editable = []
    if hazard_entity_lower & task_objects_lower:
        editable.append("objects")
    if task_frame.target_locations:
        editable.append("target_locations")
    if task_frame.recipient:
        editable.append("recipient")
    editable.append("constraints")
    editable.append("manner")
    diagnosis.editable_slots = editable

    # Intervention points: specific entities/relations that can be modified
    points = []
    for entity in sorted(diagnosis.hazardous_entities):
        if entity.lower() in task_objects_lower:
            points.append(f"object:{entity}")
    for rel in diagnosis.hazardous_relationships:
        points.append(
            f"relation:{rel['source']}->{rel['target']}({rel['relation']})"
        )
    diagnosis.candidate_intervention_points = points

    return diagnosis


class SafetyKernel:

    def __init__(self, config: SafetyConfig | None = None):
        self.config = config or SafetyConfig()

    def aggregate_graphs(self, graphs: list[InteractionGraph]) -> InteractionGraph:
        """Union independently constructed graphs into G*."""
        if not graphs:
            raise ValueError("Cannot aggregate empty graph list")
        return InteractionGraph.union(graphs)

    def aggregate_dimension(
        self,
        assessments: list[DimensionAssessment],
    ) -> DimensionResult:
        """Wrap assessment(s) for a single dimension."""
        if not assessments:
            raise ValueError("Cannot aggregate empty assessment list")

        dimension = assessments[0].dimension
        if not all(a.dimension == dimension for a in assessments):
            raise ValueError("All assessments must be for the same dimension")

        return DimensionResult(dimension=dimension, assessments=assessments)

    def evaluate_safety(
        self,
        command: str,
        dimension_results: dict[HarmDimension, DimensionResult],
        interaction_graph: InteractionGraph | None = None,
    ) -> SafetyResult:
        # Verify all six dimensions are present (structural completeness)
        missing = set(HarmDimension) - set(dimension_results.keys())
        if missing:
            raise ValueError(
                f"Structural completeness violation: missing dimensions {[d.name for d in missing]}. "
                f"All six dimensions must be evaluated."
            )

        flagged: list[HarmDimension] = []
        for dim in HarmDimension:
            dr = dimension_results[dim]
            if dr.flagged_at(self.config.min_severity):
                flagged.append(dim)

        is_safe = len(flagged) == 0
        n_flagged = len(flagged)
        safety_margin = 1.0 - (n_flagged / len(HarmDimension)) if is_safe else 0.0

        return SafetyResult(
            command=command,
            is_safe=is_safe,
            safety_margin=safety_margin,
            dimension_results=dimension_results,
            interaction_graph=interaction_graph,
            flagged_dimensions=flagged,
        )
