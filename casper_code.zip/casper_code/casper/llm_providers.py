"""
CASPER Multi-Provider LLM Backends
====================================

LLM backend implementations for multiple providers:
- OpenAI (GPT-4o, GPT-4-turbo, GPT-5.x)
- Anthropic (Claude Sonnet 4.6, Claude 3.5)
- Google Gemini (Gemini 2.5 Pro, Gemini 2.0 Flash)

Each backend implements the LLMBackend.generate() interface.
Use create_llm_backend() factory to instantiate by provider name.

Provides the LLM integration layer for CASPER's safety and repair pipelines.
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Optional

# Auto-load .env from project root
try:
    from dotenv import load_dotenv
    _env_path = Path(__file__).resolve().parent.parent / ".env"
    if _env_path.exists():
        load_dotenv(_env_path)
except ImportError:
    pass

from casper.llm_interface import LLMBackend

logger = logging.getLogger(__name__)


def _to_base64(image: str | bytes) -> str:
    """Convert image input to a base64 string. Accepts base64 str or raw bytes."""
    if isinstance(image, str):
        return image
    import base64
    return base64.b64encode(image).decode("ascii")


# Model Registry

MODEL_REGISTRY: dict[str, dict] = {
    # OpenAI
    "gpt-4o": {"provider": "openai", "display": "GPT-4o"},
    "gpt-4o-mini": {"provider": "openai", "display": "GPT-4o Mini"},
    "gpt-4-turbo": {"provider": "openai", "display": "GPT-4 Turbo"},
    "gpt-4.1": {"provider": "openai", "display": "GPT-4.1"},
    "gpt-4.1-mini": {"provider": "openai", "display": "GPT-4.1 Mini"},
    "gpt-4.1-nano": {"provider": "openai", "display": "GPT-4.1 Nano"},
    # Anthropic
    "claude-sonnet-4-6": {"provider": "anthropic", "display": "Claude Sonnet 4.6"},
    "claude-3-5-sonnet-20241022": {"provider": "anthropic", "display": "Claude 3.5 Sonnet"},
    "claude-haiku-4-5-20251001": {"provider": "anthropic", "display": "Claude Haiku 4.5"},
    # Google Gemini
    "gemini-2.5-pro": {"provider": "google", "display": "Gemini 2.5 Pro"},
    "gemini-2.5-flash": {"provider": "google", "display": "Gemini 2.5 Flash"},
    "gemini-2.0-flash": {"provider": "google", "display": "Gemini 2.0 Flash"},
}

PROVIDER_ENV_VARS = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "google": "GOOGLE_API_KEY",
}


def check_available_providers() -> dict[str, bool]:
    """Check which providers have API keys configured."""
    available = {}
    for provider, env_var in PROVIDER_ENV_VARS.items():
        if env_var is not None:
            available[provider] = bool(os.environ.get(env_var))
    return available


def get_available_models() -> list[dict]:
    """Return models filtered to those with available providers."""
    providers = check_available_providers()
    models = []
    for model_id, info in MODEL_REGISTRY.items():
        if providers.get(info["provider"], False):
            models.append({
                "id": model_id,
                "provider": info["provider"],
                "display": info["display"],
            })
    return models


# Retry Utility

def _call_with_retry(
    api_call,
    max_retries: int = 3,
    retryable_exceptions: tuple = (Exception,),
) -> str:
    """Call an API function with exponential backoff retry."""
    for attempt in range(max_retries):
        try:
            return api_call()
        except retryable_exceptions as e:
            if attempt < max_retries - 1:
                wait = 2 ** attempt
                logger.warning(
                    f"API call failed (attempt {attempt + 1}/{max_retries}), "
                    f"retrying in {wait}s: {e}"
                )
                time.sleep(wait)
            else:
                raise


# OpenAI Backend

class OpenAIBackend(LLMBackend):
    """OpenAI GPT models (GPT-4o, GPT-4-turbo, GPT-5.x)."""

    def __init__(self, model: str = "gpt-4o", api_key: Optional[str] = None):
        self._model = model
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self._client = None

    def _ensure_client(self):
        if self._client is None:
            from openai import OpenAI
            self._client = OpenAI(api_key=self._api_key)

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def supports_vision(self) -> bool:
        return any(tag in self._model for tag in ("4o", "4.1", "4-turbo", "gpt-5"))

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        self._ensure_client()

        def _call():
            response = self._client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                max_tokens=2000,
            )
            return response.choices[0].message.content

        try:
            from openai import RateLimitError, APITimeoutError, APIConnectionError
            retryable = (RateLimitError, APITimeoutError, APIConnectionError)
        except ImportError:
            retryable = (Exception,)

        return _call_with_retry(_call, retryable_exceptions=retryable)

    def generate_with_image(
        self, prompt: str, image: str | bytes, temperature: float = 0.7,
    ) -> str:
        self._ensure_client()
        image_b64 = _to_base64(image)

        def _call():
            response = self._client.chat.completions.create(
                model=self._model,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {
                            "url": f"data:image/jpeg;base64,{image_b64}",
                        }},
                    ],
                }],
                temperature=temperature,
                max_tokens=4000,
            )
            return response.choices[0].message.content

        try:
            from openai import RateLimitError, APITimeoutError, APIConnectionError
            retryable = (RateLimitError, APITimeoutError, APIConnectionError)
        except ImportError:
            retryable = (Exception,)

        return _call_with_retry(_call, retryable_exceptions=retryable)


# Anthropic Backend

class AnthropicBackend(LLMBackend):
    """Anthropic Claude models (Claude Sonnet 4.6, Claude 3.5)."""

    def __init__(self, model: str = "claude-sonnet-4-6", api_key: Optional[str] = None):
        self._model = model
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self._client = None

    def _ensure_client(self):
        if self._client is None:
            from anthropic import Anthropic
            self._client = Anthropic(api_key=self._api_key)

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def supports_vision(self) -> bool:
        return True

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        self._ensure_client()

        def _call():
            response = self._client.messages.create(
                model=self._model,
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
            )
            return response.content[0].text

        try:
            from anthropic import RateLimitError, APITimeoutError, APIConnectionError
            retryable = (RateLimitError, APITimeoutError, APIConnectionError)
        except ImportError:
            retryable = (Exception,)

        return _call_with_retry(_call, retryable_exceptions=retryable)

    def generate_with_image(
        self, prompt: str, image: str | bytes, temperature: float = 0.7,
    ) -> str:
        self._ensure_client()
        image_b64 = _to_base64(image)

        def _call():
            response = self._client.messages.create(
                model=self._model,
                max_tokens=4000,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "image", "source": {
                            "type": "base64",
                            "media_type": "image/jpeg",
                            "data": image_b64,
                        }},
                        {"type": "text", "text": prompt},
                    ],
                }],
                temperature=temperature,
            )
            return response.content[0].text

        try:
            from anthropic import RateLimitError, APITimeoutError, APIConnectionError
            retryable = (RateLimitError, APITimeoutError, APIConnectionError)
        except ImportError:
            retryable = (Exception,)

        return _call_with_retry(_call, retryable_exceptions=retryable)


# Google Gemini Backend

class GeminiBackend(LLMBackend):
    """Google Gemini models (Gemini 2.5 Pro, 2.0 Flash)."""

    def __init__(self, model: str = "gemini-2.5-pro", api_key: Optional[str] = None):
        self._model = model
        self._api_key = api_key or os.environ.get("GOOGLE_API_KEY")
        self._client = None

    def _ensure_client(self):
        if self._client is None:
            import google.generativeai as genai
            genai.configure(api_key=self._api_key)
            self._client = genai.GenerativeModel(self._model)

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def supports_vision(self) -> bool:
        return True

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        self._ensure_client()

        def _call():
            response = self._client.generate_content(
                prompt,
                generation_config={"temperature": temperature, "max_output_tokens": 2000},
            )
            return response.text

        return _call_with_retry(_call)

    def generate_with_image(
        self, prompt: str, image: str | bytes, temperature: float = 0.7,
    ) -> str:
        self._ensure_client()
        import base64
        from PIL import Image
        import io

        if isinstance(image, str):
            image_bytes = base64.b64decode(image)
        else:
            image_bytes = image
        pil_image = Image.open(io.BytesIO(image_bytes))

        def _call():
            response = self._client.generate_content(
                [prompt, pil_image],
                generation_config={"temperature": temperature, "max_output_tokens": 4000},
            )
            return response.text

        return _call_with_retry(_call)



# Factory

_PROVIDER_CLASSES = {
    "openai": OpenAIBackend,
    "anthropic": AnthropicBackend,
    "google": GeminiBackend,
}


def create_llm_backend(
    provider: str,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    **kwargs,
) -> LLMBackend:
    # If provider is actually a model ID, resolve it
    if provider in MODEL_REGISTRY:
        model = model or provider
        provider = MODEL_REGISTRY[provider]["provider"]

    provider = provider.lower()
    if provider not in _PROVIDER_CLASSES:
        raise ValueError(
            f"Unknown provider '{provider}'. "
            f"Available: {list(_PROVIDER_CLASSES.keys())}"
        )

    cls = _PROVIDER_CLASSES[provider]
    init_kwargs = {**kwargs}
    if model:
        init_kwargs["model"] = model
    if api_key:
        init_kwargs["api_key"] = api_key

    return cls(**init_kwargs)
