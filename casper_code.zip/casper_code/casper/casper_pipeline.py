"""
CASPER Full Pipeline — Algorithm 1

Wires together:
- Safety pipeline (Steps 1-3): command → safe/unsafe + safety margin
- Feasibility filter: repair grounding against scene entities
- Feature extraction: (original, repair) → φ ∈ ℝ¹⁰
- Preference model: scoring, selection, update
- Repair generation: Haddon H1-H7 candidates

End-to-end flow:
  1. User issues command c
  2. Safety pipeline evaluates c → SafetyResult
  3. If safe: execute c directly
  4. If unsafe: generate K repair candidates
  5. Three-gate waterfall: lint → screen → full eval
  6. Extract features φ for each safe candidate
  7. Determine selection mode (pairwise vs soft autonomy)
  8. Present candidate(s) to user profiles
  9. Receive feedback → update posterior
  10. Execute selected repair

"""

from __future__ import annotations
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import numpy as np

from casper.safety_kernel import SafetyConfig, SafetyResult
from casper.safety_pipeline import SafetyPipeline, RepairCandidate
from casper.feature_extraction import DeterministicFeatureExtractor, StrategyFeatures, FEATURE_DIM
from casper.plan_lint import PlanLinter
from casper.action_ir import CanonicalAction, VALID_ACTION_VERBS
from casper.preference_model import (
    PreferenceConfig,
    PreferenceModel,
    SelectionMode,
)
from casper.llm_interface import LLMBackend
from casper.object_normalizer import ObjectNormalizer
from casper.objective_frame import (
    ObjectiveFrame,
    build_objective_frame,
    derive_repaired_frame,
    is_intent_preserving,
    compute_adjusted_score,
    GAMMA,
    DELTA,
)

logger = logging.getLogger(__name__)


# Pipeline Result Types

class CommandOutcome(Enum):
    SAFE_EXECUTE = "safe_execute"                     # Command was safe, execute directly
    REPAIR_PAIRWISE = "repair_pairwise"               # Active learning: present pair for choice
    REPAIR_SOFT_AUTONOMOUS = "repair_soft_autonomous"  # Confident: recommend top, show alternative
    REPAIR_AUTONOMOUS = "repair_autonomous"            # Legacy hard autonomy
    REPAIR_NO_SAFE = "repair_no_safe"                 # Unsafe, but no safe repairs found
    ERROR = "error"


@dataclass
class ScoredCandidate:
    """A repair candidate with features, scores, and safety result."""
    command: str
    strategy: str                # Haddon H1-H7
    explanation: str
    features: StrategyFeatures
    safety_result: SafetyResult
    score: float = 0.0
    info_gain: float = 0.0
    recommended: bool = False    # True if this is the system's recommendation
    action_plan: list[CanonicalAction] = field(default_factory=list)
    repaired_frame: ObjectiveFrame | None = None
    intent_preserving: bool = False
    repair_posture: str = ""
    adjusted_score: float = 0.0

    @property
    def safety_margin(self) -> float:
        return self.safety_result.safety_margin

    def to_dict(self) -> dict:
        d = {
            "command": self.command,
            "strategy": self.strategy,
            "explanation": self.explanation,
            "features": self.features.to_dict(),
            "score": self.score,
            "adjusted_score": self.adjusted_score,
            "info_gain": self.info_gain,
            "safety_margin": self.safety_margin,
            "is_safe": self.safety_result.is_safe,
            "recommended": self.recommended,
            "intent_preserving": self.intent_preserving,
            "repair_posture": self.repair_posture,
        }
        if self.action_plan:
            d["action_plan"] = [a.to_dict() for a in self.action_plan]
        if self.repaired_frame:
            d["repaired_frame"] = self.repaired_frame.to_dict()
        return d


@dataclass
class PipelineResult:
    """Result of processing a command through the full pipeline."""
    original_command: str
    scene_context: str
    outcome: CommandOutcome
    safety_result: SafetyResult               # Safety eval of original command

    # Populated when outcome involves repair
    safe_candidates: list[ScoredCandidate] = field(default_factory=list)
    selection_mode: SelectionMode | None = None

    # Populated for autonomous selection
    selected_candidate: ScoredCandidate | None = None

    # Populated for pairwise selection
    pair: tuple[ScoredCandidate, ScoredCandidate] | None = None

    # Diagnostics
    total_candidates_generated: int = 0
    total_candidates_safe: int = 0
    error_message: str | None = None

    # Objective frame
    original_frame: ObjectiveFrame | None = None
    has_intent_preserving_candidate: bool = False

    # Waterfall audit trail
    all_generated: list = field(default_factory=list)
    rejected_lint: list = field(default_factory=list)
    rejected_screen: list = field(default_factory=list)
    rejected_safety: list = field(default_factory=list)
    latency: dict = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            f"Command: {self.original_command}",
            f"Outcome: {self.outcome.value}",
        ]
        if self.outcome == CommandOutcome.SAFE_EXECUTE:
            lines.append(f"Safety margin: {self.safety_result.safety_margin:.3f}")
        elif self.outcome == CommandOutcome.REPAIR_AUTONOMOUS:
            lines.append(f"Selected: {self.selected_candidate.command}")
            lines.append(f"Score: {self.selected_candidate.score:.3f}")
            lines.append(f"Safety margin: {self.selected_candidate.safety_margin:.3f}")
        elif self.outcome == CommandOutcome.REPAIR_SOFT_AUTONOMOUS:
            lines.append(f"Recommended: {self.pair[0].command} (score={self.pair[0].score:.3f})")
            lines.append(f"Alternative: {self.pair[1].command} (score={self.pair[1].score:.3f})")
            lines.append("Will execute recommendation after timeout unless overridden.")
        elif self.outcome == CommandOutcome.REPAIR_PAIRWISE:
            lines.append(f"Option A: {self.pair[0].command}")
            lines.append(f"Option B: {self.pair[1].command}")
        elif self.outcome == CommandOutcome.REPAIR_NO_SAFE:
            lines.append(f"Candidates generated: {self.total_candidates_generated}")
            lines.append("None passed safety evaluation.")
        elif self.outcome == CommandOutcome.ERROR:
            lines.append(f"Error: {self.error_message}")
        lines.append(
            f"Candidates: {self.total_candidates_safe}/{self.total_candidates_generated} safe"
        )
        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Serialize for logging and offline analysis."""
        result = {
            "original_command": self.original_command,
            "scene_context": self.scene_context,
            "outcome": self.outcome.value,
            "safety_result": self.safety_result.to_dict(),
            "total_candidates_generated": self.total_candidates_generated,
            "total_candidates_safe": self.total_candidates_safe,
        }
        if self.selection_mode:
            result["selection_mode"] = self.selection_mode.value
        if self.safe_candidates:
            result["safe_candidates"] = [c.to_dict() for c in self.safe_candidates]
        if self.selected_candidate:
            result["selected_candidate"] = self.selected_candidate.to_dict()
        if self.pair:
            result["pair"] = [self.pair[0].to_dict(), self.pair[1].to_dict()]
        if self.error_message:
            result["error_message"] = self.error_message
        if self.latency:
            result["latency"] = self.latency
        if self.rejected_lint:
            result["rejected_lint"] = len(self.rejected_lint)
        if self.rejected_screen:
            result["rejected_screen"] = len(self.rejected_screen)
        if self.rejected_safety:
            result["rejected_safety"] = len(self.rejected_safety)
        if self.original_frame:
            result["original_frame"] = self.original_frame.to_dict()
        result["has_intent_preserving_candidate"] = self.has_intent_preserving_candidate
        return result


# Full Pipeline

class CasperPipeline:

    def __init__(
        self,
        llm: LLMBackend,
        safety_config: SafetyConfig | None = None,
        preference_config: PreferenceConfig | None = None,
        K: int = 7,
        state_path: str | Path | None = None,
        repair_config=None,
    ):
        self.llm = llm
        self.safety_config = safety_config or SafetyConfig()
        self.preference_config = preference_config or PreferenceConfig()
        self.K = K

        # Subsystems
        self.safety = SafetyPipeline(llm, self.safety_config, repair_config=repair_config)
        self.features = DeterministicFeatureExtractor(llm)
        self.preference = PreferenceModel(self.preference_config)

        # Persistence
        self._state_path = Path(state_path) if state_path else None
        if self._state_path:
            self.preference.load(self._state_path)

        # Interaction log
        self.interaction_log: list[dict] = []
        self.recorder = None

    def process_command(
        self,
        command: str,
        scene_context: str,
        scene_ctx: object | None = None,
        allowed_verbs: set[str] | None = None,
    ) -> PipelineResult:
        try:
            return self._process_command_inner(
                command, scene_context, scene_ctx,
                allowed_verbs=allowed_verbs,
            )
        except Exception as e:
            logger.error(f"Pipeline error for '{command}': {e}", exc_info=True)
            # Return a minimal ERROR result with a synthetic unsafe SafetyResult
            return PipelineResult(
                original_command=command,
                scene_context=scene_context,
                outcome=CommandOutcome.ERROR,
                safety_result=SafetyResult(
                    command=command,
                    is_safe=False,
                    safety_margin=0.0,
                ),
                error_message=str(e),
            )

    def _process_command_inner(
        self,
        command: str,
        scene_context: str,
        scene_ctx: object | None = None,
        allowed_verbs: set[str] | None = None,
    ) -> PipelineResult:
        """Three-gate waterfall: lint -> screen -> full eval."""
        latency: dict[str, float] = {}

        t0 = time.perf_counter()
        safety_result = self.safety.evaluate(command, scene_context)
        latency["safety_eval_original_ms"] = (time.perf_counter() - t0) * 1000

        if safety_result.is_safe:
            return PipelineResult(
                original_command=command,
                scene_context=scene_context,
                outcome=CommandOutcome.SAFE_EXECUTE,
                safety_result=safety_result,
                latency=latency,
            )

        # Extract entity set from interaction graph + scene context,
        # grounding through ObjectNormalizer when scene inventory is available
        entity_names: set[str] = set()
        scene_inventory: list[str] = []
        if scene_ctx is not None and hasattr(scene_ctx, 'entity_set'):
            scene_inventory = list(scene_ctx.entity_set)
            entity_names |= {e.lower() for e in scene_ctx.entity_set}

        if safety_result.interaction_graph is not None:
            graph_entities = {
                e.name.lower()
                for e in safety_result.interaction_graph.entities
            }
            if scene_inventory:
                normalizer = ObjectNormalizer(scene_inventory)
                for name in graph_entities:
                    resolved = normalizer.normalize(name)
                    entity_names.add(resolved if resolved else name)
            else:
                entity_names |= graph_entities

        # Extract hazard diagnosis once (deterministic, 0 LLM calls)
        diagnosis = self.safety.extract_diagnosis(safety_result)

        # Build original ObjectiveFrame from existing artifacts (deterministic)
        original_frame = build_objective_frame(
            command=command,
            diagnosis=diagnosis,
            interaction_graph=safety_result.interaction_graph,
        )

        # Repair generation with bundled plans (1 LLM call, no evaluation)
        t0 = time.perf_counter()
        repair_candidates = self.safety.generate_repairs(
            command=command,
            scene_context=scene_context,
            K=self.K,
            diagnosis=diagnosis,
            scene_objects=sorted(entity_names) if entity_names else None,
            evaluate=False,
            objective_frame=original_frame,
            allowed_verbs=allowed_verbs,
        )
        latency["repair_generation_ms"] = (time.perf_counter() - t0) * 1000

        all_generated = list(repair_candidates)

        if not repair_candidates:
            logger.warning("No repair candidates generated.")
            return PipelineResult(
                original_command=command,
                scene_context=scene_context,
                outcome=CommandOutcome.REPAIR_NO_SAFE,
                safety_result=safety_result,
                all_generated=all_generated,
                latency=latency,
            )

        # Pre-lint: normalize action plan object references against scene
        if scene_inventory:
            normalizer = ObjectNormalizer(scene_inventory)
            for candidate in repair_candidates:
                if candidate.action_plan:
                    for action in candidate.action_plan:
                        if action.obj:
                            resolved = normalizer.normalize(action.obj)
                            if resolved:
                                action.obj = resolved
                        if action.receptacle:
                            resolved = normalizer.normalize(action.receptacle)
                            if resolved:
                                action.receptacle = resolved

        # Gate 1: Plan lint (deterministic, 0 LLM calls)
        t0 = time.perf_counter()
        linter = PlanLinter(
            valid_actions=allowed_verbs or VALID_ACTION_VERBS,
            scene_objects=entity_names,
        )
        for candidate in repair_candidates:
            candidate.lint_result = linter.lint(candidate)
        lint_passed = [c for c in repair_candidates if c.lint_result.passed]
        rejected_lint = [
            (c, c.lint_result.errors)
            for c in repair_candidates if not c.lint_result.passed
        ]
        latency["gate1_lint_ms"] = (time.perf_counter() - t0) * 1000

        if rejected_lint:
            logger.info(
                f"Gate 1 (lint): rejected {len(rejected_lint)}/{len(repair_candidates)}"
            )
            for c, errors in rejected_lint:
                logger.info(
                    f"  LINT REJECTED [{c.strategy}] '{c.command[:60]}' — {errors}"
                )

        # Gate 2: LLM safety screen
        t0 = time.perf_counter()
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from casper.llm_providers import create_llm_backend, MODEL_REGISTRY

        model_name = self.safety.llm.model_name
        gate_provider = MODEL_REGISTRY.get(model_name, {}).get("provider", "openai")

        underlying_need = getattr(self.safety, '_last_underlying_need', '') or ''

        def _screen_one(candidate):
            worker_llm = create_llm_backend(gate_provider, model=model_name)
            from casper.safety_pipeline import SafetyPipeline
            worker_safety = SafetyPipeline(worker_llm, self.safety.config)
            candidate.screen_result = worker_safety.screen_repair(
                candidate, diagnosis, scene_context,
                original_command=command,
                underlying_need=underlying_need,
            )
            return candidate

        with ThreadPoolExecutor(max_workers=min(len(lint_passed), 10)) as pool:
            list(pool.map(_screen_one, lint_passed))

        screen_passed = [
            c for c in lint_passed
            if c.screen_result and c.screen_result.is_safe
        ]
        rejected_screen = [
            (c, c.screen_result)
            for c in lint_passed
            if c.screen_result and not c.screen_result.is_safe
        ]
        latency["gate2_screen_ms"] = (time.perf_counter() - t0) * 1000

        if rejected_screen:
            logger.info(
                f"Gate 2 (screen): rejected {len(rejected_screen)}/{len(lint_passed)}"
            )
            for c, sr in rejected_screen:
                logger.info(
                    f"  SCREEN REJECTED [{c.strategy}] '{c.command[:60]}' — "
                    f"resolved={sr.resolved}, flagged={[d.name for d in sr.flagged_dimensions]}"
                )

        # Gate 3: Plan-aware 6-dimension safety evaluation
        t0 = time.perf_counter()
        original_graph = safety_result.interaction_graph

        def _eval_one(candidate):
            worker_llm = create_llm_backend(gate_provider, model=model_name)
            worker_safety = SafetyPipeline(worker_llm, self.safety.config)
            candidate.safety_result = worker_safety.evaluate_repair(
                candidate=candidate,
                diagnosis=diagnosis,
                scene_context=scene_context,
                original_graph=original_graph,
            )
            return candidate

        if screen_passed:
            with ThreadPoolExecutor(max_workers=min(len(screen_passed), 10)) as pool:
                list(pool.map(_eval_one, screen_passed))

        safe_repairs = [c for c in screen_passed if c.is_safe]
        rejected_safety = [
            (c, c.safety_result.flagged_dimensions)
            for c in screen_passed if not c.is_safe
        ]
        latency["gate3_full_eval_ms"] = (time.perf_counter() - t0) * 1000

        if rejected_safety:
            logger.info(
                f"Gate 3 (full eval): rejected {len(rejected_safety)}/{len(screen_passed)}"
            )
            for c, dims in rejected_safety:
                logger.info(
                    f"  SAFETY REJECTED [{c.strategy}] '{c.command[:60]}' — "
                    f"flagged={[d.name for d in dims]}"
                )

        if not safe_repairs:
            logger.warning("No safe repair candidates after waterfall.")
            return PipelineResult(
                original_command=command,
                scene_context=scene_context,
                outcome=CommandOutcome.REPAIR_NO_SAFE,
                safety_result=safety_result,
                total_candidates_generated=len(all_generated),
                total_candidates_safe=0,
                original_frame=original_frame,
                all_generated=all_generated,
                rejected_lint=rejected_lint,
                rejected_screen=rejected_screen,
                rejected_safety=rejected_safety,
                latency=latency,
            )

        # Feature extraction + frame derivation + adjusted scoring
        t0 = time.perf_counter()
        scored: list[ScoredCandidate] = []
        feature_vectors: list[np.ndarray] = []
        safety_margins: list[float] = []

        for rc in safe_repairs:
            repair_entities = {
                a.obj for a in rc.action_plan if a.obj
            } | {
                a.receptacle for a in rc.action_plan if a.receptacle
            }
            feats = self.features.extract(
                original_command=command,
                repair_command=rc.command,
                scene_context=scene_context,
                safety_margin=rc.safety_result.safety_margin,
                original_entities=diagnosis.hazardous_entities,
                repair_entities=repair_entities or None,
                repair_action_plan=rc.action_plan,
            )

            pref_score = self.preference.score(
                feats.values, rc.safety_result.safety_margin,
            )
            ig = self.preference.information_gain(feats.values)

            repaired_frame = derive_repaired_frame(
                original=original_frame,
                candidate_command=rc.command,
                candidate_action_plan=rc.action_plan,
                candidate_expected_end_state=rc.expected_end_state,
                candidate_strategy=rc.strategy,
            )
            intent_flag = is_intent_preserving(original_frame, repaired_frame)

            adj_score = compute_adjusted_score(
                preference_score=pref_score,
                safety_margin=rc.safety_result.safety_margin,
                original_frame=original_frame,
                repaired_frame=repaired_frame,
            )

            sc = ScoredCandidate(
                command=rc.command,
                strategy=rc.strategy,
                explanation=rc.explanation,
                features=feats,
                safety_result=rc.safety_result,
                score=pref_score,
                info_gain=ig,
                action_plan=rc.action_plan,
                repaired_frame=repaired_frame,
                intent_preserving=intent_flag,
                repair_posture=repaired_frame.repair_posture,
                adjusted_score=adj_score,
            )
            scored.append(sc)
            feature_vectors.append(feats.values)
            safety_margins.append(rc.safety_result.safety_margin)

        latency["feature_extraction_ms"] = (time.perf_counter() - t0) * 1000

        # Task objective-preservation safeguard: ensure at least one
        # objective-preserving candidate is retained in the final set.
        has_intent_preserving = any(sc.intent_preserving for sc in scored)
        if has_intent_preserving:
            logger.info(
                f"Intent-preservation safeguard: "
                f"{sum(1 for sc in scored if sc.intent_preserving)}/{len(scored)} "
                f"candidates are intent-preserving"
            )

        # Sort by adjusted_score (incorporates anchor-preservation bias)
        scored_sorted = sorted(
            scored, key=lambda c: c.adjusted_score, reverse=True,
        )

        # Log justification when top candidate is not task objective-preserving
        # but a task objective-preserving alternative exists.
        if has_intent_preserving and scored_sorted and not scored_sorted[0].intent_preserving:
            top = scored_sorted[0]
            best_ip = next(c for c in scored_sorted if c.intent_preserving)
            logger.warning(
                f"Non-intent-preserving candidate ranked first: "
                f"'{top.command}' (adj={top.adjusted_score:.3f}, "
                f"safety={top.safety_margin:.3f}, pref={top.score:.3f}) "
                f"over intent-preserving '{best_ip.command}' "
                f"(adj={best_ip.adjusted_score:.3f}, "
                f"safety={best_ip.safety_margin:.3f}, pref={best_ip.score:.3f})"
            )

        # Determine selection mode (continuous confidence-gated)
        mode = self.preference.selection_mode(feature_vectors)

        def _build_result(outcome, pair, selected=None):
            return PipelineResult(
                original_command=command,
                scene_context=scene_context,
                outcome=outcome,
                safety_result=safety_result,
                safe_candidates=scored_sorted,
                selection_mode=mode,
                selected_candidate=selected,
                pair=pair,
                total_candidates_generated=len(all_generated),
                total_candidates_safe=len(safe_repairs),
                original_frame=original_frame,
                has_intent_preserving_candidate=has_intent_preserving,
                all_generated=all_generated,
                rejected_lint=rejected_lint,
                rejected_screen=rejected_screen,
                rejected_safety=rejected_safety,
                latency=latency,
            )

        if mode == SelectionMode.SOFT_AUTONOMOUS:
            idx_top, idx_alt = self.preference.select_top_two(
                feature_vectors, safety_margins,
            )
            recommended = scored[idx_top]
            alternative = scored[idx_alt]
            recommended.recommended = True

            logger.info(
                f"Soft autonomous: recommending '{recommended.command}' "
                f"(adj_score={recommended.adjusted_score:.3f}, "
                f"posture={recommended.repair_posture}), "
                f"alternative '{alternative.command}' "
                f"(adj_score={alternative.adjusted_score:.3f}, "
                f"posture={alternative.repair_posture})"
            )

            return _build_result(
                CommandOutcome.REPAIR_SOFT_AUTONOMOUS,
                pair=(recommended, alternative),
                selected=recommended,
            )

        else:
            idx_i, idx_j = self.preference.select_pair(
                feature_vectors, safety_margins,
            )
            pair_i = scored[idx_i]
            pair_j = scored[idx_j]

            logger.info(
                f"Pairwise selection: [{pair_i.command}] vs [{pair_j.command}]"
            )

            return _build_result(
                CommandOutcome.REPAIR_PAIRWISE,
                pair=(pair_i, pair_j),
            )

    # Feedback Processing

    def receive_soft_accept_feedback(
        self,
        recommended: ScoredCandidate,
    ) -> None:
        """
        Process non-intervention in soft autonomy mode.

        The user didn't override the recommendation — weak confirmatory signal.
        Down-weighted update to avoid compounding confirmatory bias.
        """
        self.preference.update_soft_accept(recommended.features.values)

        self.interaction_log.append({
            "t": self.preference.t - 1,
            "type": "soft_accept",
            "accepted": recommended.command,
        })

        self._auto_save()

        logger.info(
            f"Soft accept at t={self.preference.t}: '{recommended.command}' "
            f"(down-weighted update)"
        )

    def receive_override_feedback(
        self,
        recommended: ScoredCandidate,
        chosen: ScoredCandidate,
    ) -> None:
        """
        Process override in soft autonomy mode.

        The user picked the alternative over the recommendation — high-value
        signal that the posterior has drifted. Triggers re-entry into
        pairwise mode for active re-exploration.
        """
        # Standard pairwise update: user chose alternative over recommendation
        self.preference.update_pairwise(
            features_chosen=chosen.features.values,
            features_rejected=recommended.features.values,
        )

        # Trigger re-entry: boost lambda, force pairwise for next few interactions
        self.preference.trigger_override_reentry()

        self.interaction_log.append({
            "t": self.preference.t - 1,
            "type": "override",
            "recommended": recommended.command,
            "chosen": chosen.command,
        })

        self._auto_save()

        logger.info(
            f"Override at t={self.preference.t}: chose '{chosen.command}' "
            f"over recommended '{recommended.command}'. "
            f"Re-entering pairwise mode."
        )

    def receive_pairwise_feedback(
        self,
        chosen: ScoredCandidate,
        rejected: ScoredCandidate,
    ) -> None:
        """Process user's pairwise choice."""
        self.preference.update_pairwise(
            features_chosen=chosen.features.values,
            features_rejected=rejected.features.values,
        )

        self.interaction_log.append({
            "t": self.preference.t - 1,
            "type": "pairwise",
            "chosen": chosen.command,
            "rejected": rejected.command,
        })

        self._auto_save()

        logger.info(
            f"Pairwise update t={self.preference.t}: "
            f"chose '{chosen.command}' over '{rejected.command}'"
        )

    def receive_accept_feedback(self, candidate: ScoredCandidate) -> None:
        """Process user accepting a candidate."""
        self.preference.update_accept(candidate.features.values)

        self.interaction_log.append({
            "t": self.preference.t - 1,
            "type": "accept",
            "accepted": candidate.command,
        })

        self._auto_save()

    def receive_reject_feedback(self, candidate: ScoredCandidate) -> None:
        """Process user rejecting a candidate."""
        self.preference.update_reject(candidate.features.values)

        self.interaction_log.append({
            "t": self.preference.t - 1,
            "type": "reject",
            "rejected": candidate.command,
        })

        self._auto_save()

    def receive_edit_feedback(
        self,
        proposed: ScoredCandidate,
        edited_command: str,
        scene_context: str,
        original_command: str,
    ) -> SafetyResult | None:
        """
        Process user editing a proposed repair.

        Extracts features for the edited version and updates posterior
        with the feature-space difference as a preference gradient.

        Also safety-evaluates the edited command. If the edit is unsafe,
        the preference update still happens (the user's direction preference
        is valid even if the specific edit overshoots) but a warning is logged.

        Returns:
            SafetyResult for the edited command, or None if evaluation failed.
        """
        # Safety-evaluate the edited command
        edit_safety: SafetyResult | None = None
        try:
            edit_safety = self.safety.evaluate(edited_command, scene_context)
            if not edit_safety.is_safe:
                logger.warning(
                    f"User edit '{edited_command}' is UNSAFE "
                    f"(flagged: {[d.name for d in edit_safety.flagged_dimensions]}). "
                    f"Preference update applied but command should not be executed."
                )
        except Exception as e:
            logger.error(f"Safety evaluation of edit failed: {e}")

        # Extract features using edit's own safety margin if available
        edit_margin = edit_safety.safety_margin if edit_safety and edit_safety.is_safe else 0.0
        edited_features = self.features.extract(
            original_command=original_command,
            repair_command=edited_command,
            scene_context=scene_context,
            safety_margin=edit_margin,
        )

        self.preference.update_edit(
            features_proposed=proposed.features.values,
            features_edited=edited_features.values,
        )

        self.interaction_log.append({
            "t": self.preference.t - 1,
            "type": "edit",
            "proposed": proposed.command,
            "edited": edited_command,
            "edit_is_safe": edit_safety.is_safe if edit_safety else None,
        })

        self._auto_save()

        return edit_safety

    # Persistence

    def _auto_save(self) -> None:
        """Save preference model state if a state_path is configured."""
        if self._state_path:
            self.preference.save(self._state_path)

    def save_state(self, path: str | Path | None = None) -> None:
        """Explicitly save preference model state."""
        save_path = Path(path) if path else self._state_path
        if save_path:
            self.preference.save(save_path)
        else:
            logger.warning("No state path configured — state not saved")

    def load_state(self, path: str | Path | None = None) -> bool:
        """Explicitly load preference model state. Returns True if loaded."""
        load_path = Path(path) if path else self._state_path
        if load_path:
            return self.preference.load(load_path)
        logger.warning("No state path configured — state not loaded")
        return False

    # Diagnostics

    def system_state(self) -> dict:
        """Complete system state for logging/analysis."""
        posterior = self.preference.posterior_summary()
        tr_sigma = posterior["total_uncertainty"]
        tr_sigma_0 = self.preference.config.sigma_0 ** 2 * FEATURE_DIM
        confidence = 1.0 - min(1.0, tr_sigma / tr_sigma_0)

        cfg = self.preference.config
        return {
            "preference_posterior": posterior,
            "interaction_count": self.preference.t,
            "confidence": confidence,
            "effective_lambda": self.preference.effective_lambda(),
            "reentry_countdown": self.preference._reentry_countdown,
            "phase": (
                "active_learning" if confidence < cfg.phase_active_learning
                else "transitioning" if confidence < cfg.phase_soft_autonomous
                else "soft_autonomous"
            ),
            "interaction_log": self.interaction_log,
        }
