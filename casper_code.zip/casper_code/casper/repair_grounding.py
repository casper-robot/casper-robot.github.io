"""
RepairGroundingPack — Bounded scene inventory for repair generation.

Constrains repair generation to exact scene entities, locations,
receptacles, and robot skills. Prevents the LLM from inventing
objects or capabilities that don't exist in the scene.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from casper.safety_kernel import HazardDiagnosis

from casper.scene_provider import _OBJECT_PROPERTIES


@dataclass
class RepairGroundingPack:
    """Bounded inventory for grounded repair generation."""
    scene_entities: list[str] = field(default_factory=list)
    movable_objects: list[str] = field(default_factory=list)
    safe_receptacles: list[str] = field(default_factory=list)
    allowed_locations: list[str] = field(default_factory=list)
    allowed_recipients: list[str] = field(default_factory=list)
    robot_skills: list[str] = field(default_factory=list)
    forbidden_bindings: list[str] = field(default_factory=list)
    proxy_mapping: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "scene_entities": self.scene_entities,
            "movable_objects": self.movable_objects,
            "safe_receptacles": self.safe_receptacles,
            "allowed_locations": self.allowed_locations,
            "robot_skills": self.robot_skills,
            "forbidden_bindings": self.forbidden_bindings,
        }

    def to_prompt_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


def build_grounding_pack(
    scene_entities: list[str] | set[str] | None = None,
    scene_objects: list[str] | None = None,
    robot_skills: set[str] | None = None,
    diagnosis: HazardDiagnosis | None = None,
) -> RepairGroundingPack:
    """Build a RepairGroundingPack from scene and robot context.

    Deterministic — no LLM calls. Classifies objects using the
    _OBJECT_PROPERTIES knowledge base.
    """
    from casper.action_ir import VALID_ACTION_VERBS

    entities = sorted(set(scene_entities or []) | set(scene_objects or []))

    # Build case-insensitive lookup for property matching
    props_lower = {k.lower(): v for k, v in _OBJECT_PROPERTIES.items()}

    movable = []
    receptacles = []
    for name in entities:
        props = _OBJECT_PROPERTIES.get(name, props_lower.get(name.lower(), {}))
        if props.get("pickupable"):
            movable.append(name)
        if props.get("receptacle"):
            receptacles.append(name)

    # Allowed locations = receptacles + surfaces
    allowed_locations = list(receptacles)

    # Forbidden bindings: hazardous entities from diagnosis
    forbidden = []
    if diagnosis:
        for entity in sorted(diagnosis.hazardous_entities):
            forbidden.append(entity)

    skills = sorted(robot_skills or VALID_ACTION_VERBS)

    return RepairGroundingPack(
        scene_entities=entities,
        movable_objects=sorted(movable),
        safe_receptacles=sorted(receptacles),
        allowed_locations=sorted(allowed_locations),
        robot_skills=skills,
        forbidden_bindings=forbidden,
    )
