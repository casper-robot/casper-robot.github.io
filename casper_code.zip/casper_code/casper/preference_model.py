"""
CASPER Preference Model — Bayesian Preference Learning

Implements:
- Gaussian posterior over user weight vector
- Population prior for cold start
- Bradley-Terry likelihood for pairwise preferences
- Laplace approximation updates (Eqs. mu_update, sigma_update)
- Accept/reject updates against implicit baseline (Eqs. accept, reject)
- User edit updates with direct preference gradient (Eqs. edit_mu, edit_sigma)
- Three-term scoring
- Pairwise selection via PairScore (Eq. pairscore)
- Confidence-gated autonomy: soft autonomy as emergent property of
  posterior convergence, not a hard mode switch
- Persistence: save/load posterior state across sessions
"""

from __future__ import annotations
import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import numpy as np

from casper.feature_extraction import (
    FEATURE_DIM,
    FEATURE_NAMES,
    baseline_features,
)

logger = logging.getLogger(__name__)


# Configuration

@dataclass
class PreferenceConfig:
    """Hyperparameters for the preference model."""
    # Prior
    sigma_0: float = 2.0       # Prior std dev (large = high uncertainty)

    mu_0: np.ndarray = field(default=None)

    # Scoring weights
    beta: float = 0.3          # Conservative bias weight (safety margin term)
    lam: float = 0.5           # Exploration bonus weight (information gain term)

    # Autonomy
    epsilon: float = 0.1       # Autonomy threshold on max pair info gain

    alpha_soft_accept: float = 0.2   # Down-weighted update for non-intervention
    # Number of re-exploration interactions after an override
    reentry_interactions: int = 3

    # Phase thresholds (diagnostic labels based on confidence)
    phase_active_learning: float = 0.5    # confidence < this → "active_learning"
    phase_soft_autonomous: float = 0.8    # confidence ≥ this → "soft_autonomous"
    # Between the two → "transitioning"

    # Edit update
    alpha_edit: float = 0.5    # Learning rate for user edit updates

    def __post_init__(self):
        if self.mu_0 is None:
            # Population prior: mild preference for conservative, object-preserving repairs
            self.mu_0 = np.array([
                -0.3,   # φ₁: slight preference for smaller modifications
                 0.5,   # φ₂: prefer keeping the primary object
                 0.3,   # φ₃: mild preference for parameter modification
                 0.8,   # φ₄: strong preference for high safety margin
                 0.3,   # φ₅: mild preference for structural preservation
                -0.1,   # φ₆: slight preference against interaction change
                -0.2,   # φ₇: mild preference for shorter plans (less burden)
                -0.1,   # φ₈: slight preference against navigation (simpler)
                 0.0,   # φ₉: neutral on container manipulation
                -0.1,   # φ₁₀: slight preference against object set change
            ], dtype=np.float64)
        else:
            # Defensive copy: prevent external mutation from corrupting config
            self.mu_0 = np.array(self.mu_0, dtype=np.float64)

        assert len(self.mu_0) == FEATURE_DIM, (
            f"mu_0 must have {FEATURE_DIM} dimensions, got {len(self.mu_0)}"
        )
        assert self.sigma_0 > 0, f"sigma_0 must be positive, got {self.sigma_0}"
        assert self.beta >= 0, f"beta must be non-negative, got {self.beta}"
        assert self.lam >= 0, f"lam must be non-negative, got {self.lam}"
        assert self.epsilon > 0, f"epsilon must be positive, got {self.epsilon}"
        assert self.alpha_edit > 0, f"alpha_edit must be positive, got {self.alpha_edit}"


# Selection Mode

class SelectionMode(Enum):
    PAIRWISE = "pairwise"               # Active learning: present maximally informative pair
    SOFT_AUTONOMOUS = "soft_autonomous"  # Confident: present top-two, recommend #1, timeout-execute
    AUTONOMOUS = "autonomous"           # Legacy hard autonomy (not used in continuous loop)


# Preference Model

class PreferenceModel:
    """
    Bayesian preference model with Gaussian posterior.

    State:
        μ_t ∈ ℝ^d     — posterior mean (best estimate of user weights)
        Σ_t ∈ ℝ^{d×d} — posterior covariance (uncertainty about weights)

    The model maintains a complete history of updates for
    reproducibility and analysis.
    """

    def __init__(self, config: PreferenceConfig | None = None):
        self.config = config or PreferenceConfig()
        d = FEATURE_DIM

        # Initialize posterior to prior
        self.mu: np.ndarray = self.config.mu_0.copy()
        self.sigma: np.ndarray = (self.config.sigma_0 ** 2) * np.eye(d)

        # Interaction counter
        self.t: int = 0

        # History for analysis
        self.history: list[dict] = []

        # Soft autonomy state
        # Tracks how many interactions remain in re-exploration after an override
        self._reentry_countdown: int = 0

    def reset(self) -> None:
        """Reset to prior."""
        d = FEATURE_DIM
        self.mu = self.config.mu_0.copy()
        self.sigma = (self.config.sigma_0 ** 2) * np.eye(d)
        self.t = 0
        self.history = []
        self._reentry_countdown = 0

    # Sigmoid / Bradley-Terry

    @staticmethod
    def _sigmoid(x: float) -> float:
        """Logistic sigmoid σ(x) = 1 / (1 + e^{-x}), numerically stable."""
        if x >= 0:
            z = np.exp(-x)
            return 1.0 / (1.0 + z)
        else:
            z = np.exp(x)
            return z / (1.0 + z)

    def preference_probability(
        self,
        features_i: np.ndarray,
        features_j: np.ndarray,
    ) -> float:
        """
        P(c'_i ≻ c'_j | θ) = σ(μᵀ Δφ_ij)

        Probability that the model predicts user prefers candidate i over j.
        """
        delta = features_i - features_j
        return self._sigmoid(float(self.mu @ delta))

    # Posterior Updates

    def update_pairwise(
        self,
        features_chosen: np.ndarray,
        features_rejected: np.ndarray,
    ) -> None:
        delta = features_chosen - features_rejected
        self._laplace_update(delta, y=1.0)

        if self._reentry_countdown > 0:
            self._reentry_countdown -= 1

        self.history.append({
            "t": self.t,
            "type": "pairwise",
            "delta_phi": delta.tolist(),
            "mu_after": self.mu.tolist(),
        })
        self.t += 1

    def update_accept(self, features: np.ndarray) -> None:
        phi_0 = baseline_features()
        delta = features - phi_0
        self._laplace_update(delta, y=1.0)

        self.history.append({
            "t": self.t,
            "type": "accept",
            "delta_phi": delta.tolist(),
            "mu_after": self.mu.tolist(),
        })
        self.t += 1

    def update_reject(self, features: np.ndarray) -> None:
        phi_0 = baseline_features()
        delta = features - phi_0
        self._laplace_update(delta, y=0.0)

        self.history.append({
            "t": self.t,
            "type": "reject",
            "delta_phi": delta.tolist(),
            "mu_after": self.mu.tolist(),
        })
        self.t += 1

    def update_edit(
        self,
        features_proposed: np.ndarray,
        features_edited: np.ndarray,
        original_command: str = "",
    ) -> None:
        alpha = self.config.alpha_edit
        delta = features_edited - features_proposed

        # Mean update: shift toward edit direction
        self.mu = self.mu + alpha * (self.sigma @ delta)

        # Covariance update: reduce uncertainty along edit direction
        sigma_inv = np.linalg.inv(self.sigma)
        sigma_inv += alpha * np.outer(delta, delta)
        sigma_inv += self._JITTER * np.eye(FEATURE_DIM)  # Regularization
        self.sigma = np.linalg.inv(sigma_inv)
        self.sigma = 0.5 * (self.sigma + self.sigma.T)  # Enforce symmetry

        self.history.append({
            "t": self.t,
            "type": "edit",
            "delta_phi": delta.tolist(),
            "alpha_edit": alpha,
            "mu_after": self.mu.tolist(),
        })
        self.t += 1

    # Numerical stability
    _JITTER = 1e-8  # Regularization for precision matrix inversion

    def _laplace_update(self, delta: np.ndarray, y: float) -> None:
        """
        Core Laplace approximation update.

        μ_{t+1} = μ_t + Σ_t Δφ (y - σ(μᵀ Δφ))
        Σ_{t+1}⁻¹ = Σ_t⁻¹ + s(1-s) Δφ Δφᵀ

        where s = σ(μᵀ Δφ)
        """
        s = self._sigmoid(float(self.mu @ delta))

        # Mean update
        self.mu = self.mu + self.sigma @ delta * (y - s)

        # Covariance update via precision matrix with regularization
        sigma_inv = np.linalg.inv(self.sigma)
        sigma_inv += s * (1.0 - s) * np.outer(delta, delta)
        sigma_inv += self._JITTER * np.eye(FEATURE_DIM)  # Regularization
        self.sigma = np.linalg.inv(sigma_inv)
        # Enforce symmetry (floating point can introduce asymmetry)
        self.sigma = 0.5 * (self.sigma + self.sigma.T)

    # Scoring

    def effective_lambda(self) -> float:
        tr_sigma = float(np.trace(self.sigma))
        tr_sigma_0 = self.config.sigma_0 ** 2 * FEATURE_DIM
        confidence_ratio = min(1.0, tr_sigma / tr_sigma_0)

        lam_eff = self.config.lam * confidence_ratio

        # Boost during re-entry (override recovery)
        if self._reentry_countdown > 0:
            lam_eff = max(lam_eff, self.config.lam * 0.8)

        return lam_eff

    def score(self, features: np.ndarray, safety_margin: float) -> float:
        personalization = float(self.mu @ features)
        conservative_bias = self.config.beta * safety_margin
        info_gain = self.effective_lambda() * self.information_gain(features)

        return personalization + conservative_bias + info_gain

    def information_gain(self, features: np.ndarray) -> float:
        return float(features @ self.sigma @ features)

    def score_candidates(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
    ) -> list[float]:
        """Score multiple candidates. Returns scores in same order."""
        return [
            self.score(f, sm) for f, sm in zip(feature_vectors, safety_margins)
        ]

    def rank_candidates(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
    ) -> list[int]:
        """Return indices sorted by score (highest first)."""
        scores = self.score_candidates(feature_vectors, safety_margins)
        return sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)

    # Pairwise Selection

    def pair_score(
        self,
        features_i: np.ndarray,
        features_j: np.ndarray,
        safety_margin_i: float,
        safety_margin_j: float,
    ) -> float:
        delta = features_i - features_j
        disc_info = float(delta @ self.sigma @ delta)
        avg_score = 0.5 * (
            self.score(features_i, safety_margin_i)
            + self.score(features_j, safety_margin_j)
        )
        return disc_info + avg_score

    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
    ) -> tuple[int, int]:
        n = len(feature_vectors)
        if n < 2:
            raise ValueError(f"Need at least 2 candidates for pair selection, got {n}")

        best_score = -float("inf")
        best_pair = (0, 1)

        for i in range(n):
            for j in range(i + 1, n):
                ps = self.pair_score(
                    feature_vectors[i], feature_vectors[j],
                    safety_margins[i], safety_margins[j],
                )
                if ps > best_score:
                    best_score = ps
                    best_pair = (i, j)

        return best_pair

    # Autonomy Gate

    def max_pair_info_gain(self, feature_vectors: list[np.ndarray]) -> float:
        n = len(feature_vectors)
        if n < 2:
            return 0.0

        max_gain = 0.0
        for i in range(n):
            for j in range(i + 1, n):
                delta = feature_vectors[i] - feature_vectors[j]
                gain = float(delta @ self.sigma @ delta)
                max_gain = max(max_gain, gain)

        return max_gain

    def selection_mode(self, feature_vectors: list[np.ndarray]) -> SelectionMode:
        if len(feature_vectors) < 2:
            return SelectionMode.SOFT_AUTONOMOUS

        # Re-entry after override: force pairwise for a few interactions
        if self._reentry_countdown > 0:
            return SelectionMode.PAIRWISE

        max_gain = self.max_pair_info_gain(feature_vectors)

        if max_gain > self.config.epsilon:
            return SelectionMode.PAIRWISE
        else:
            return SelectionMode.SOFT_AUTONOMOUS

    def select_best(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
    ) -> int:
        if not feature_vectors:
            raise ValueError("Cannot select from empty candidate list")

        scores = self.score_candidates(feature_vectors, safety_margins)
        return int(np.argmax(scores))

    # Soft Autonomy Feedback

    def update_soft_accept(self, features: np.ndarray) -> None:
        alpha = self.config.alpha_soft_accept
        phi_0 = baseline_features()
        delta = features - phi_0

        # Same direction as accept, but scaled down
        s = self._sigmoid(float(self.mu @ delta))
        self.mu = self.mu + alpha * (self.sigma @ delta * (1.0 - s))

        # Covariance update also scaled
        sigma_inv = np.linalg.inv(self.sigma)
        sigma_inv += alpha * s * (1.0 - s) * np.outer(delta, delta)
        sigma_inv += self._JITTER * np.eye(FEATURE_DIM)
        self.sigma = np.linalg.inv(sigma_inv)
        self.sigma = 0.5 * (self.sigma + self.sigma.T)

        if self._reentry_countdown > 0:
            self._reentry_countdown -= 1

        self.history.append({
            "t": self.t,
            "type": "soft_accept",
            "delta_phi": delta.tolist(),
            "alpha": alpha,
            "mu_after": self.mu.tolist(),
        })
        self.t += 1

    def trigger_override_reentry(self) -> None:
        self._reentry_countdown = self.config.reentry_interactions
        logger.info(
            f"Override detected at t={self.t}. "
            f"Re-entering pairwise mode for {self._reentry_countdown} interactions."
        )

    def select_top_two(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
    ) -> tuple[int, int]:
        ranked = self.rank_candidates(feature_vectors, safety_margins)
        if len(ranked) < 2:
            return (ranked[0], ranked[0])
        return (ranked[0], ranked[1])

    # Persistence

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        state = {
            "mu": self.mu.tolist(),
            "sigma": self.sigma.tolist(),
            "t": self.t,
            "reentry_countdown": self._reentry_countdown,
            "history": self.history,
        }
        path.write_text(json.dumps(state, indent=2))
        logger.info(f"Saved preference model state to {path} (t={self.t})")

    def load(self, path: str | Path) -> bool:
        path = Path(path)
        if not path.exists():
            logger.info(f"No saved state at {path} — starting from prior")
            return False

        try:
            state = json.loads(path.read_text())
            mu = np.array(state["mu"], dtype=np.float64)
            sigma = np.array(state["sigma"], dtype=np.float64)

            if mu.shape != (FEATURE_DIM,) or sigma.shape != (FEATURE_DIM, FEATURE_DIM):
                logger.warning(
                    f"State dimension mismatch in {path} — starting from prior"
                )
                return False

            self.mu = mu
            self.sigma = sigma
            self.t = state.get("t", 0)
            self._reentry_countdown = state.get("reentry_countdown", 0)
            self.history = state.get("history", [])

            logger.info(
                f"Loaded preference model from {path} (t={self.t}, "
                f"tr(Σ)={np.trace(self.sigma):.3f})"
            )
            return True
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logger.warning(f"Failed to load state from {path}: {e}")
            return False

    # Diagnostics

    def posterior_summary(self) -> dict:
        """Summary of current posterior state for logging."""
        diag = np.diag(self.sigma)
        return {
            "t": self.t,
            "mu": {name: float(self.mu[i]) for i, name in enumerate(FEATURE_NAMES)},
            "sigma_diag": {name: float(diag[i]) for i, name in enumerate(FEATURE_NAMES)},
            "total_uncertainty": float(np.trace(self.sigma)),
            "effective_lambda": self.effective_lambda(),
            "reentry_countdown": self._reentry_countdown,
            "max_weight": FEATURE_NAMES[int(np.argmax(self.mu))],
            "min_weight": FEATURE_NAMES[int(np.argmin(self.mu))],
        }

    def weight_summary(self) -> str:
        """Human-readable weight summary."""
        lines = [f"Posterior at t={self.t}:"]
        diag = np.diag(self.sigma)
        for i, name in enumerate(FEATURE_NAMES):
            lines.append(f"  {name}: μ={self.mu[i]:+.3f}  σ={np.sqrt(diag[i]):.3f}")
        lines.append(f"  Total uncertainty (tr Σ): {np.trace(self.sigma):.3f}")
        return "\n".join(lines)

    def predicted_autonomy_time(self) -> float:
        return FEATURE_DIM / self.config.epsilon
