"""
CanonicalAction IR — typed action representation.

Normalizes across benchmark and robot execution dialects.
What gets generated is what gets validated is what gets executed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class CanonicalAction:
    """Typed action step. Eliminates format-mismatch bugs."""
    verb: str
    actor: str = "robot1"
    obj: Optional[str] = None
    receptacle: Optional[str] = None
    liquid_type: Optional[str] = None
    raw: str = ""
    dialect: str = ""

    def to_dict(self) -> dict:
        d = {"verb": self.verb}
        if self.obj:
            d["obj"] = self.obj
        if self.receptacle:
            d["receptacle"] = self.receptacle
        if self.liquid_type:
            d["liquid_type"] = self.liquid_type
        if self.actor != "robot1":
            d["actor"] = self.actor
        return d

    @classmethod
    def from_dict(cls, d: dict) -> CanonicalAction:
        return cls(
            verb=d["verb"],
            actor=d.get("actor", "robot1"),
            obj=d.get("obj"),
            receptacle=d.get("receptacle"),
            liquid_type=d.get("liquid_type"),
            raw=d.get("raw", ""),
            dialect=d.get("dialect", ""),
        )


MANIPULATOR_VERBS = {'pick', 'place', 'move_to', 'push', 'open_gripper'}
WORLD_VERBS = {'open', 'close'}
FR3_ALLOWED_VERBS = {'pick', 'place', 'move_to', 'push', 'open_gripper'}
VALID_ACTION_VERBS = FR3_ALLOWED_VERBS
def render_safeagentbench(action: CanonicalAction) -> str:
    """Convert a CanonicalAction to SafeAgentBench format."""
    if action.verb == 'put' and action.receptacle:
        return f"put {action.receptacle}"
    elif action.obj:
        return f"{action.verb} {action.obj}"
    else:
        return action.verb


def render_fr3_python(action: CanonicalAction) -> str:
    """Convert a CanonicalAction to FR3 robot Python code."""
    if action.verb == 'move_to':
        return f"robot.move_to('{action.obj or action.receptacle}')"
    elif action.verb == 'pick':
        return (
            f"robot.move_to('{action.obj}')\n"
            f"robot.pick('{action.obj}')"
        )
    elif action.verb in ('put', 'place'):
        return (
            f"robot.move_to('{action.receptacle}')\n"
            f"robot.place('{action.obj}', '{action.receptacle}')"
        )
    elif action.verb == 'push':
        direction = action.receptacle or 'away'
        return (
            f"robot.move_to('{action.obj}')\n"
            f"robot.push('{action.obj}', '{direction}')"
        )
    elif action.verb == 'open_gripper':
        return "robot.open_gripper()"
    return f"# NOT EXECUTABLE on FR3: {action.verb} {action.obj or ''}"


def render_fr3_script(action_plan: list[CanonicalAction], metadata: dict | None = None) -> str:
    """Render a complete FR3 Python script from an action plan.

    Includes header, robot initialization, action sequence with
    move_to navigation, and cleanup.
    """
    lines = [
        "#!/usr/bin/env python3",
    ]

    if metadata:
        lines.append('"""')
        if metadata.get("command"):
            lines.append(f"Original command: {metadata['command']}")
        if metadata.get("repair"):
            lines.append(f"Repair: {metadata['repair']}")
        if metadata.get("strategy"):
            lines.append(f"Strategy: {metadata['strategy']}")
        if metadata.get("profile"):
            lines.append(f"Profile: {metadata['profile']}")
        lines.append('"""')

    lines.extend([
        "",
        "from franka_interface import FrankaRobot",
        "",
        "robot = FrankaRobot()",
        "robot.connect()",
        "",
    ])

    for action in action_plan:
        lines.append(render_fr3_python(action))
        lines.append("")

    lines.extend([
        "robot.disconnect()",
    ])

    return "\n".join(lines)


def parse_safeagentbench(raw: str) -> CanonicalAction:
    """Parse SafeAgentBench format: 'find Egg', 'pick Egg', 'put Fridge'."""
    parts = raw.strip().split(None, 1)
    verb = parts[0].lower() if parts else raw.strip().lower()
    obj = parts[1] if len(parts) > 1 else None

    if verb in ('put', 'place') and obj:
        return CanonicalAction(
            verb='put', obj=None, receptacle=obj,
            raw=raw, dialect='safeagentbench',
        )
    return CanonicalAction(
        verb=verb, obj=obj, raw=raw, dialect='safeagentbench',
    )


def parse_action(raw: str, dialect: str = "") -> CanonicalAction:
    """Parse an action string into a CanonicalAction."""
    if dialect == 'safeagentbench' or not dialect:
        return parse_safeagentbench(raw)
    raise ValueError(f"Unknown dialect: {dialect}")
