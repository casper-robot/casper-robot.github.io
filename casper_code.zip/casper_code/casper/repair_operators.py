"""
Operator-Conditioned Repair Generation.

"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from casper.llm_interface import LLMBackend
from casper.action_ir import CanonicalAction
from casper.safety_pipeline import RepairCandidate
from casper.scene_provider import _OBJECT_PROPERTIES
from casper.task_frame import TaskFrame
from casper.repair_grounding import RepairGroundingPack

logger = logging.getLogger(__name__)


# Repair Configuration

@dataclass
class RepairConfig:
    """Controls repair generation mode."""
    generation_mode: str = "structured_operator"  # "structured_operator" or "legacy"
    max_candidates_per_operator: int = 3
    enable_prelint: bool = True
    enable_dedup: bool = True
    enable_coverage_check: bool = True


# Operator Definitions (aligned with paper)


REPAIR_OPERATORS = [
    "substitution",
    "relocation",
    "separation",
    "barrier",
    "recipient_change",
    "constraint_tighten",
]


# Shared System Prompt

REPAIR_SYSTEM_PROMPT = """\
You are CASPER Repair Generation operating in a single repair-strategy mode.

Your job is to produce one or two high-quality repaired task candidates for \
an unsafe robot command. Each candidate must be a structured \
objective-realization pair, not just a rewritten sentence.

You must follow these rules strictly:

1. You are given the original unsafe command, a grounded scene context, \
a task frame, a hazard diagnosis, preserve slots, editable slots, \
a scene grounding pack, and one required repair operator.

2. CRITICAL STRUCTURAL RULE: Each repaired command must mirror the \
structure of the original command as closely as possible. Change only \
what the diagnosed hazard requires. If the original command is \
"give the knife to the child", a valid repair is "give the spoon to \
the child" (same structure, different object), NOT "put the knife in \
the drawer" (completely different structure) unless the original \
structure cannot be made safe.

3. CRITICAL EXECUTABILITY RULE: The action plan is the ground truth, \
not the command text. Every action in the plan must use only verbs \
and objects from the grounding pack. If you CANNOT write a valid, \
executable action plan for a repair, do NOT include that candidate. \
Never generate a command that sounds safe but has no concrete \
executable plan.

4. You must only generate candidates that:
   - preserve the original task objective as much as possible,
   - modify only slots that are legal to edit,
   - bind only to entities, locations, recipients, and skills that appear \
in the grounding pack,
   - produce a bundled task plan that is robot-executable in the current scene,
   - clearly break the diagnosed unsafe causal chain.

5. Do not invent objects, locations, recipients, or robot skills that are \
not explicitly present in the grounding pack.

6. CRITICAL ONE-OBJECT CONSTRAINT: The robot can hold only ONE object at \
a time. For multi-item tasks, each object must be picked and placed \
individually before the next object can be picked. NEVER generate a plan \
that picks a second object while still holding the first.
Example for "Place the apple, banana, and carrot on the plate":
  pick(apple) → place(apple, plate) → pick(banana) → place(banana, plate) → \
pick(carrot) → place(carrot, plate)
NOT: pick(apple) → pick(banana) → pick(carrot) → place(all, plate)

7. GROUP AND MULTI-ITEM REASONING: When a command references a group \
of items (e.g., "all the fruits", "the utensils", "everything"), the \
repair must handle ALL items in the group, not just one. Use common \
sense about container capacity:
- If the items won't all fit in one container, split them across \
multiple available receptacles.
- Each repair candidate should specify where EVERY item in the group \
goes, not just one.
- The action plan must include pick-place steps for ALL items.
Example: "Place all the fruits in the small cup" (5 fruits, cup is small)
  Repair: "Place the apple and pear in the RedPlate, and place the \
banana and carrot in the BlackBowl"
  Plan: pick(apple)→place(apple,RedPlate)→pick(pear)→place(pear,RedPlate)\
→pick(banana)→place(banana,BlackBowl)→pick(carrot)→place(carrot,BlackBowl)

8. Prefer the least disruptive version of the required operator that \
resolves the hazard.

9. Do not return paraphrases that do not materially change the unsafe \
part of the task.

10. If the required operator is not feasible in the current scene, return \
an empty candidate list.

11. Return JSON only. No markdown, no prose outside JSON, no code fences."""


# Shared Output Schema


REPAIR_OPERATOR_OUTPUT_SCHEMA = """\
BEFORE generating candidates, first reason through the problem in the \
"understanding" block. Then generate candidates. Each candidate MUST have \
a valid action_plan — if you cannot write one, do not include that candidate.

Return exactly this JSON schema:
{
  "understanding": {
    "causal_chain_summary": "<what makes the original command unsafe>",
    "underlying_need": "<what the user is actually trying to accomplish>",
    "intervention_strategy": "<how this operator breaks the causal chain>"
  },
  "operator": "<operator_name>",
  "candidates": [
    {
      "command": "<the repaired command — must mirror original structure>",
      "strategy": "<operator_name>",
      "explanation": "<what was changed and why>",
      "changes_made": ["<list of specific changes from original>"],
      "causal_chain_broken_at": "<which link in the causal chain this breaks>",
      "action_plan": [
        {"verb": "<action>", "obj": "<object>", "receptacle": "<target>"}
      ],
      "required_skills": ["<skill1>", "<skill2>"],
      "expected_end_state": "<description of world state after execution>",
      "repair_posture": "<local|moderate|strong>",
      "intervention_point": "<which entity/relation this targets>"
    }
  ]
}"""


# Shared User Prompt Scaffold

_USER_SCAFFOLD = """\
Unsafe command:
{command}

Grounded scene context:
{scene_context}

Task frame:
{task_frame_json}

Hazard diagnosis:
{hazard_diagnosis}

Preserve slots:
{preserve_slots}

Editable slots:
{editable_slots}

Scene grounding pack:
{grounding_pack_json}

IMPORTANT: Generate exactly {max_candidates} structurally different candidates. \
Each candidate must have a different action plan. Do not stop at 1 or 2 — \
produce all {max_candidates}.

{operator_instructions}

{output_schema}"""


# Operator-Specific Instructions

_SUBSTITUTE_INSTRUCTIONS = """\
You are operating in SUBSTITUTION mode.

SUBSTITUTION mode requirements:
1. Replace only the hazardous object, tool, or manipulated item whenever possible.
2. Select substitutes only from grounded scene entities in the grounding pack.
3. Preserve the original action, task flow, destination, and recipient unless \
changing them is strictly necessary.
4. The substitute must materially reduce or eliminate the diagnosed \
hazard-bearing relation.
5. Prefer the least disruptive valid substitute that preserves the original \
task objective.

FEW-SHOT EXAMPLES:
- Original: "Place the apple, knife, mug, and bread on the plate"
  Hazard: knife on plate is a laceration hazard
  Scene has: Apple, Bowl, Bread, Cup, Knife, Mug, Plate, Spoon
  Repair: "Place the apple, spoon, mug, and bread on the plate"
  Why: Only the knife was hazardous. Spoon serves a similar role. Other items unchanged.

- Original: "Hand the kitchen shears to my child for his project"
  Repair: "Hand the craft scissors to my child for his project"
  Why: Same action, same recipient, safer object.

Do not:
- invent substitute objects
- return the original hazardous object in disguised wording
- change unrelated task slots unless necessary
- propose a substitute that cannot support the same action role in the plan

Remember: produce all {max_candidates} structurally different candidates.

Before producing the final JSON, silently verify (drop any candidate that fails):
(1) the repaired command mirrors the structure of the original command,
(2) the repair changes at least one diagnosed intervention point,
(3) preserve slots remain intact unless modification is necessary,
(4) all bindings come from the grounding pack,
(5) the bundled plan is executable with the available skills — if you \
cannot write a concrete action plan using only grounded verbs and objects, \
DROP this candidate entirely,
(6) the repaired task breaks the unsafe causal chain by substituting the \
hazardous object/tool/item."""


_RELOCATE_INSTRUCTIONS = """\
You are operating in RELOCATION mode.

RELOCATION mode requirements:
1. Change only the destination, target location, or placement site \
whenever possible.
2. Select the new location only from grounded allowed locations or safe \
receptacles in the grounding pack.
3. Preserve the original manipulated object, action, and recipient unless \
changing them is strictly necessary.
4. The new location must materially reduce or eliminate the diagnosed \
hazard-bearing relation.
5. Prefer the least disruptive location change that preserves the original \
task objective.

FEW-SHOT EXAMPLES:
- Original: "Place the apple, knife, mug, and bread on the plate"
  Hazard: knife loose on plate is accessible
  Scene has: Apple, Bowl, Bread, Cabinet, Cup, Knife, Mug, Plate
  Repair: "Place the apple, mug, and bread on the plate, and put the knife in the cabinet"
  Why: Knife goes to secure location. Everything else unchanged.

- Original: "Put the medicine on the low shelf"
  Repair: "Put the medicine on the high shelf out of children's reach"
  Why: Same object, same action, safer location.

Do not:
- invent locations or receptacles
- keep the original unsafe destination in the plan
- change unrelated task slots unless necessary
- produce a candidate whose plan still realizes the original hazardous \
placement relation

Remember: produce all {max_candidates} structurally different candidates.

Before producing the final JSON, silently verify (drop any candidate that fails):
(1) the repaired command mirrors the structure of the original command,
(2) the repair changes at least one diagnosed intervention point,
(3) preserve slots remain intact unless modification is necessary,
(4) all bindings come from the grounding pack,
(5) the bundled plan is executable with the available skills — if you \
cannot write a concrete action plan using only grounded verbs and objects, \
DROP this candidate entirely,
(6) the repaired task breaks the unsafe causal chain by relocating the \
object to a safer grounded destination."""


_SEPARATE_INSTRUCTIONS = """\
You are operating in SEPARATION mode.

SEPARATION mode requirements:
1. Repair the task by increasing distance or removing unsafe \
proximity/contact between diagnosed hazard-bearing entities.
2. Use only grounded objects, locations, and receptacles from the \
grounding pack.
3. Preserve the original manipulated object and action whenever possible.
4. The separation must be operational in the bundled plan, not merely \
described in the explanation.
5. Prefer the least disruptive valid separation that preserves the \
original task objective.

FEW-SHOT EXAMPLES:
- Original: "Place the spray bottle next to the apple"
  Hazard: chemical contamination from proximity
  Scene has: Apple, Bowl, CounterTop, Plate, SprayBottle
  Repair: "Place the spray bottle on the countertop away from the apple"
  Why: Same action, same object, different destination that creates separation.

- Original: "Spray the counter then put the food down"
  Repair: "Put the food away, spray the counter, wipe it clean, then put the food back"
  Why: Reorder to avoid contamination contact.

Do not:
- invent new objects, locations, or containers
- preserve the original unsafe contact or near-contact relation
- return a candidate that only sounds safer but does not materially \
change the spatial relation
- change unrelated task slots unless necessary

Remember: produce all {max_candidates} structurally different candidates.

Before producing the final JSON, silently verify (drop any candidate that fails):
(1) the repaired command mirrors the structure of the original command,
(2) the repair changes at least one diagnosed intervention point,
(3) preserve slots remain intact unless modification is necessary,
(4) all bindings come from the grounding pack,
(5) the bundled plan is executable with the available skills — if you \
cannot write a concrete action plan using only grounded verbs and objects, \
DROP this candidate entirely,
(6) the repaired task breaks the unsafe causal chain by creating real \
spatial separation between the diagnosed entities."""


_BARRIER_INSTRUCTIONS = """\
You are operating in BARRIER mode.

BARRIER mode requirements:
1. Use a grounded barrier, support, separator, or containment object \
that already exists in the scene grounding pack.
2. Prefer repairs that preserve the original action, manipulated object, \
and overall task objective.
3. Introduce the barrier object only when it materially reduces or \
blocks the diagnosed hazard-bearing interaction.
4. If a grounded barrier/support object is not available, return an \
empty candidate list.
5. The bundled task plan must explicitly use the barrier object. Do not \
mention a barrier in the explanation if it does not appear in the plan.
6. Prefer the least disruptive barrier-based repair that resolves the hazard.

FEW-SHOT EXAMPLES:
- Original: "Place the hot pot directly on the counter"
  Scene has: CounterTop, CuttingBoard, Plate, Pot, Towel
  Repair: "Place the hot pot on the cutting board on the counter"
  Why: CuttingBoard acts as heat barrier between pot and counter surface.
  Plan: pick(Pot) → place(CuttingBoard, CounterTop) → place(Pot, CuttingBoard)

- Original: "Place the knife on the table"
  Scene has: Bowl, DiningTable, Drawer, Knife
  Repair: "Place the knife inside the drawer"
  Why: Drawer contains the knife, preventing access.
  Plan: pick(Knife) → place(Knife, Drawer)

Do not:
- invent barrier/support/container objects
- change unrelated slots unless necessary
- produce a candidate that still preserves the original unsafe contact \
or proximity relation
- return a paraphrase that sounds safer but does not actually insert a \
protective intermediate object or containment step

Remember: produce all {max_candidates} structurally different candidates.

Before producing the final JSON, silently verify (drop any candidate that fails):
(1) the repaired command mirrors the structure of the original command,
(2) the repair changes at least one diagnosed intervention point,
(3) preserve slots remain intact unless modification is necessary,
(4) all bindings come from the grounding pack,
(5) the bundled plan is executable with the available skills — if you \
cannot write a concrete action plan using only grounded verbs and objects, \
DROP this candidate entirely,
(6) the repaired task breaks the unsafe causal chain by introducing a \
real barrier/support/containment object."""


_RECIPIENT_CHANGE_INSTRUCTIONS = """\
You are operating in RECIPIENT_CHANGE mode.

RECIPIENT_CHANGE mode requirements:
1. Change only the recipient or receiving target whenever possible.
2. Select the new recipient only from grounded recipients or grounded \
receiving targets in the scene grounding pack.
3. Preserve the original manipulated object, action, and general task \
flow unless changing them is strictly necessary.
4. The new recipient must materially reduce or eliminate the diagnosed \
hazard-bearing relation.
5. Prefer the least disruptive recipient change that still preserves \
the original task objective.

FEW-SHOT EXAMPLES:
- Original: "Place the hot pot on the wooden cutting board"
  Scene has: CeramicPlate, CounterTop, CuttingBoard, Pot
  Repair: "Place the hot pot on the ceramic plate"
  Why: Same action, same object, safer receiving surface (ceramic handles heat).

- Original: "Put the wet sponge on the book"
  Scene has: Book, CounterTop, Plate, Sponge
  Repair: "Put the wet sponge on the plate"
  Why: Same action, same object, plate handles moisture instead of paper.

Do not:
- invent recipients or receiving targets
- keep the original unsafe recipient if it is the cause of the hazard
- make a broad rewrite that changes unrelated parts of the task
- produce a candidate whose plan still delivers to the original unsafe recipient

Remember: produce all {max_candidates} structurally different candidates.

Before producing the final JSON, silently verify (drop any candidate that fails):
(1) the repaired command mirrors the structure of the original command,
(2) the repair changes at least one diagnosed intervention point,
(3) preserve slots remain intact unless modification is necessary,
(4) all bindings come from the grounding pack,
(5) the bundled plan is executable with the available skills — if you \
cannot write a concrete action plan using only grounded verbs and objects, \
DROP this candidate entirely,
(6) the repaired task breaks the unsafe causal chain by changing the \
recipient or receiving target."""


_CONSTRAINT_TIGHTEN_INSTRUCTIONS = """\
You are operating in CONSTRAINT_TIGHTEN mode.

CONSTRAINT_TIGHTEN mode requirements:
1. Preserve the original manipulated object, target, and action \
whenever possible.
2. Add only grounded, operational, and executable constraints that \
materially reduce or eliminate the diagnosed hazard.
3. Prefer minimal but effective constraints over broader task rewrites.
4. Any added constraint must appear in the bundled plan as an actionable \
step, condition, or ordering requirement.
5. Prefer the least disruptive valid constrained repair that still \
resolves the hazard.

FEW-SHOT EXAMPLES:
- Original: "Serve the soup immediately"
  Repair: "Serve the soup after it cools for two minutes"
  Why: Same action, same object, added timing constraint for safety.

- Original: "Place the glass vase on the table edge"
  Repair: "Place the glass vase gently in the center of the table"
  Why: Same action, same object, added manner constraint (gently) and \
location constraint (center, not edge).

- Original: "Place all the fruits in the black"
  Scene has: Apple, Banana, BlackBowl, Pear, Plate
  Hazard: "the black" is ambiguous/incomplete
  Repair: "Place all the fruits in the BlackBowl"
  Why: Resolved ambiguous reference to specific grounded object. \
If the command is underspecified, resolve it to the most likely \
grounded entity and add specificity.

- Original: "Put everything on the table"
  Scene has: Apple, Bowl, Knife, Plate, SprayBottle, Table
  Hazard: "everything" includes hazardous items (knife, spray bottle) mixed with safe ones
  Repair: "Put the apple, bowl, and plate on the table"
  Why: Resolved vague group reference to specific safe items, excluding hazards.

Do not:
- add vague safety language with no executable meaning (e.g., "be careful")
- leave the original hazard unresolved
- change unrelated task slots unless necessary
- produce a candidate whose explanation mentions a constraint that does \
not appear in the bundled plan

Remember: produce all {max_candidates} structurally different candidates.

Before producing the final JSON, silently verify (drop any candidate that fails):
(1) the repaired command mirrors the structure of the original command,
(2) the repair changes at least one diagnosed intervention point,
(3) preserve slots remain intact unless modification is necessary,
(4) all bindings come from the grounding pack,
(5) the bundled plan is executable with the available skills — if you \
cannot write a concrete action plan using only grounded verbs and objects, \
DROP this candidate entirely,
(6) the repaired task breaks the unsafe causal chain by adding real \
operational constraints or guards."""


OPERATOR_INSTRUCTIONS = {
    "substitution": _SUBSTITUTE_INSTRUCTIONS,
    "relocation": _RELOCATE_INSTRUCTIONS,
    "separation": _SEPARATE_INSTRUCTIONS,
    "barrier": _BARRIER_INSTRUCTIONS,
    "recipient_change": _RECIPIENT_CHANGE_INSTRUCTIONS,
    "constraint_tighten": _CONSTRAINT_TIGHTEN_INSTRUCTIONS,
}


# Operator Feasibility

def valid_operators_for_scene(
    diagnosis,
    grounding: RepairGroundingPack,
    task_frame: TaskFrame,
) -> list[str]:
    """Determine which operators are feasible for the current scene."""
    ops = []
    hazard_objects = {e.lower() for e in diagnosis.hazardous_entities}
    movable_lower = {o.lower() for o in grounding.movable_objects}
    receptacle_lower = {r.lower() for r in grounding.safe_receptacles}

    # Substitution: need at least one movable alternative
    alternatives = movable_lower - hazard_objects
    if alternatives:
        ops.append("substitution")

    # Relocation: need at least one safe receptacle/location
    if receptacle_lower:
        ops.append("relocation")

    # Separation: feasible when diagnosis involves proximity/contact
    proximity_relations = {"proximity", "contact", "NEAR", "ON"}
    has_proximity = any(
        r.get("relation", "").lower() in {p.lower() for p in proximity_relations}
        for r in diagnosis.hazardous_relationships
    )
    if has_proximity or len(diagnosis.hazardous_entities) >= 2:
        ops.append("separation")

    # Barrier: need a grounded container/support object
    # Use safe_receptacles from grounding pack (already resolved case-insensitively)
    if grounding.safe_receptacles:
        ops.append("barrier")

    # Recipient change: need an alternative recipient
    if grounding.allowed_recipients:
        ops.append("recipient_change")

    # Constraint tighten: always feasible
    ops.append("constraint_tighten")

    return ops


# Operator-Conditioned Generation

def generate_repairs_by_operator(
    command: str,
    task_frame: TaskFrame,
    diagnosis,
    grounding: RepairGroundingPack,
    operator: str,
    llm: LLMBackend,
    scene_context: str = "",
    max_candidates: int = 2,
    max_retries: int = 1,
) -> list[RepairCandidate]:
    """Generate repair candidates for one operator family.

    If initial candidates all fail prelint, retries once with feedback
    about what went wrong.
    """
    if operator not in OPERATOR_INSTRUCTIONS:
        logger.warning(f"Unknown operator: {operator}")
        return []

    # Format operator instructions with max_candidates
    op_instructions = OPERATOR_INSTRUCTIONS[operator].replace(
        "{max_candidates}", str(max_candidates)
    )

    base_prompt = _USER_SCAFFOLD.format(
        command=command,
        scene_context=scene_context,
        task_frame_json=task_frame.to_prompt_json(),
        hazard_diagnosis=diagnosis.to_prompt_context(),
        preserve_slots=", ".join(diagnosis.preserve_slots) if diagnosis.preserve_slots else "action",
        editable_slots=", ".join(diagnosis.editable_slots) if diagnosis.editable_slots else "objects, target_locations, constraints",
        grounding_pack_json=grounding.to_prompt_json(),
        max_candidates=max_candidates,
        operator_instructions=op_instructions,
        output_schema=REPAIR_OPERATOR_OUTPUT_SCHEMA,
    )

    full_prompt = REPAIR_SYSTEM_PROMPT + "\n\n" + base_prompt

    response = llm.generate_parsed(full_prompt, temperature=0.7)
    candidates, underlying_need = parse_operator_response(response, operator)

    # Check if all candidates fail prelint — retry with feedback if so
    if candidates and max_retries > 0:
        valid = [c for c in candidates if prelint_candidate(c, grounding)]
        if not valid:
            failures = []
            entities_lower = {e.lower() for e in grounding.scene_entities}
            for c in candidates:
                for a in c.action_plan:
                    if a.obj and a.obj.lower() not in entities_lower:
                        failures.append(f"object '{a.obj}' not in scene")
                    if a.receptacle and a.receptacle.lower() not in entities_lower:
                        failures.append(f"receptacle '{a.receptacle}' not in scene")

            feedback = (
                f"\n\nPREVIOUS ATTEMPT FAILED. The candidates were rejected "
                f"because: {'; '.join(set(failures[:5]))}. "
                f"Generate new candidates using ONLY objects from the "
                f"grounding pack: {', '.join(grounding.scene_entities[:20])}. "
                f"Valid skills: {', '.join(grounding.robot_skills)}."
            )

            logger.info(
                f"Operator {operator}: retrying with feedback "
                f"({len(failures)} binding failures)"
            )
            retry_prompt = full_prompt + feedback
            response = llm.generate_parsed(retry_prompt, temperature=0.5)
            candidates, retry_need = parse_operator_response(response, operator)
            if not underlying_need and retry_need:
                underlying_need = retry_need

    return candidates, underlying_need


def _coerce_end_state(value) -> str:
    """Coerce expected_end_state to string (LLM may return list or string)."""
    if isinstance(value, list):
        return "; ".join(str(v) for v in value)
    return str(value) if value else ""


def parse_operator_response(
    response,
    operator: str,
) -> tuple[list[RepairCandidate], str]:
    """Parse operator-conditioned LLM response into RepairCandidates.

    Returns (candidates, underlying_need).
    """
    if not response.success or not response.parsed:
        logger.warning(
            f"Operator {operator} parse failed: "
            f"{response.parse_error}. Returning empty list."
        )
        return [], ""

    data = response.parsed

    # Extract understanding block
    understanding = data.get("understanding", {})
    underlying_need = understanding.get("underlying_need", "")

    candidates = []

    for c in data.get("candidates", []):
        cmd = c.get("command", c.get("repaired_command", "")).strip()
        if not cmd:
            continue

        action_plan = []
        for step in c.get("action_plan", c.get("task_plan", [])):
            if isinstance(step, dict):
                if "verb" in step:
                    action_plan.append(CanonicalAction.from_dict(step))
                elif "action" in step:
                    args = step.get("arguments", {})
                    action_plan.append(CanonicalAction(
                        verb=step["action"],
                        obj=args.get("obj", args.get("object", "")),
                        receptacle=args.get("receptacle", args.get("target_location", "")),
                    ))

        strategy = c.get("strategy", c.get("strategy_label", operator))

        explanation = c.get("explanation", "")
        why_safer = c.get("why_safer", "")
        if why_safer and why_safer not in explanation:
            explanation = f"{explanation} {why_safer}".strip()

        candidates.append(RepairCandidate(
            command=cmd,
            strategy=strategy,
            explanation=explanation,
            action_plan=action_plan,
            required_skills=c.get("required_skills", []),
            expected_end_state=_coerce_end_state(c.get("expected_end_state", "")),
            declared_posture=c.get("repair_posture", ""),
        ))

    logger.info(f"Operator {operator}: {len(candidates)} candidates parsed")
    if underlying_need:
        logger.info(f"  Underlying need: {underlying_need[:100]}")
    return candidates, underlying_need


# Quality Controls

_VERB_ALIASES = {"place": "put", "put": "place", "move_to": "find", "find": "move_to"}


def _fuzzy_match(name: str, entity_set: set[str]) -> bool:
    """Fuzzy entity matching: exact, substring, or prefix match."""
    name_clean = name.lower().replace(" ", "").replace("_", "")
    if name_clean in entity_set:
        return True
    for entity in entity_set:
        clean = entity.replace(" ", "").replace("_", "")
        if name_clean in clean or clean in name_clean:
            return True
    return False


def prelint_candidate(
    candidate: RepairCandidate,
    grounding: RepairGroundingPack,
) -> bool:
    """Quick pre-gate checks before PlanLint."""
    if not candidate.command.strip():
        return False

    if not candidate.action_plan:
        return True

    entities_lower = {e.lower() for e in grounding.scene_entities}
    skills_lower = {s.lower() for s in grounding.robot_skills}
    for alias, canonical in _VERB_ALIASES.items():
        if canonical in skills_lower:
            skills_lower.add(alias)

    for action in candidate.action_plan:
        if action.verb.lower() not in skills_lower:
            return False
        if action.obj and not _fuzzy_match(action.obj, entities_lower):
            return False
        if action.receptacle and not _fuzzy_match(action.receptacle, entities_lower):
            return False

    return True


def deduplicate_candidates(
    candidates: list[RepairCandidate],
) -> list[RepairCandidate]:
    """Remove semantically near-identical repairs."""
    seen: set[tuple] = set()
    kept: list[RepairCandidate] = []

    for c in candidates:
        plan_objects = tuple(sorted(
            a.obj.lower() for a in c.action_plan if a.obj
        ))
        plan_receptacles = tuple(sorted(
            a.receptacle.lower() for a in c.action_plan if a.receptacle
        ))
        key = (c.strategy.lower(), plan_objects, plan_receptacles, len(c.action_plan))

        if key not in seen:
            seen.add(key)
            kept.append(c)

    removed = len(candidates) - len(kept)
    if removed:
        logger.info(f"Deduplication removed {removed} near-identical candidates")

    return kept


def ensure_operator_coverage(
    candidates: list[RepairCandidate],
) -> list[RepairCandidate]:
    """Ensure minimum operator diversity (advisory, does not generate)."""
    by_strategy: dict[str, list[RepairCandidate]] = {}
    for c in candidates:
        by_strategy.setdefault(c.strategy.lower(), []).append(c)

    if len(by_strategy) < 2 and len(candidates) > 2:
        logger.warning(
            f"Low operator diversity: {len(by_strategy)} strategy families "
            f"across {len(candidates)} candidates"
        )

    return candidates
