(function () {
    "use strict";

    var FEATURE_NAMES = [
        "φ₁ Mod", "φ₂ Pres", "φ₃ Param", "φ₄ Safe",
        "φ₅ Struct", "φ₆ Recip", "φ₇ Len",
        "φ₈ Nav", "φ₉ Cont", "φ₁₀ HObj"
    ];

    var FEATURE_KEYS = [
        "modification_degree", "object_preservation", "parameter_modification",
        "safety_margin", "structural_preservation", "recipient_interaction_change",
        "plan_length", "navigation_required", "container_manipulation",
        "handled_object_set_change"
    ];

    document.addEventListener("DOMContentLoaded", init);

    function init() {
        document.getElementById("processBtn").addEventListener("click", processCommand);
        document.getElementById("detectBtn").addEventListener("click", detectScene);
        document.getElementById("imageUpload").addEventListener("change", function () {
            document.getElementById("detectBtn").disabled = !this.files.length;
        });
        loadScenes();
    }

    function loadScenes() {
        fetch("/api/scenes")
            .then(function (r) { return r.json(); })
            .then(function (data) {
                var scenes = data.scenes || [];
                var el = document.getElementById("sceneList");
                if (scenes.length === 0) {
                    el.innerHTML = '<div class="empty-state" style="padding:1rem;">No cached scenes available.</div>';
                    return;
                }
                el.className = "";
                el.innerHTML = scenes.map(function (s) {
                    return '<div class="scenario-card" data-scene="' + s + '" style="margin-bottom:0.5rem; padding:0.6rem;">' +
                        '<div style="font-weight:600; font-size:0.85rem;">' + s + '</div>' +
                        '</div>';
                }).join("");
                el.querySelectorAll(".scenario-card").forEach(function (card) {
                    card.addEventListener("click", function () {
                        loadSceneObjects(this.dataset.scene);
                    });
                });
            })
            .catch(function () {
                document.getElementById("sceneList").innerHTML =
                    '<div class="empty-state" style="padding:1rem;">Could not load scenes.</div>';
            });
    }

    function loadSceneObjects(sceneId) {
        fetch("/api/scene/" + sceneId + "/objects")
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.scene_context) {
                    document.getElementById("sceneContext").value = data.scene_context;
                }
            })
            .catch(function (e) { console.error("Failed to load scene:", e); });
    }

    function processCommand() {
        var command = document.getElementById("commandInput").value.trim();
        if (!command) { alert("Enter a command."); return; }

        var provider = document.getElementById("provider").value;
        var model = document.getElementById("model").value;
        var sceneCtx = document.getElementById("sceneContext").value.trim();

        document.getElementById("pipelineEmpty").style.display = "none";
        document.getElementById("pipelineResults").style.display = "block";
        var loading = document.getElementById("pipelineLoading");
        loading.classList.add("active");

        var btn = document.getElementById("processBtn");
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner"></span> Processing...';

        var useFR3 = document.getElementById("useFR3").checked;

        fetch("/api/pipeline/process", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                command: command,
                scene_context: sceneCtx,
                provider: provider,
                model: model,
                use_fr3_verbs: useFR3
            })
        })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (data.error) {
                renderError(data);
            } else {
                renderPipelineResult(data);
            }
        })
        .catch(function (e) {
            renderError({ error: e.toString() });
        })
        .finally(function () {
            loading.classList.remove("active");
            btn.disabled = false;
            btn.textContent = "Process Command";
        });
    }

    function renderError(data) {
        document.getElementById("pipelineSummary").innerHTML =
            '<div class="stage stage-unsafe"><div class="stage-header">Error</div>' +
            '<p style="font-size:0.85rem;">' + escapeHtml(data.error || "Unknown error") + '</p>' +
            (data.traceback ? '<details style="margin-top:0.5rem;"><summary style="font-size:0.8rem; cursor:pointer;">Traceback</summary>' +
                '<div class="code-block" style="margin-top:0.5rem; font-size:0.75rem;">' + escapeHtml(data.traceback) + '</div></details>' : '') +
            '</div>';
        document.getElementById("pipelineStages").innerHTML = "";
        document.getElementById("candidatesCard").style.display = "none";
        document.getElementById("featureCard").style.display = "none";
        document.getElementById("actionCard").style.display = "none";
    }

    function renderPipelineResult(data) {
        var safetyResult = data.safety_result || {};
        var isSafe = safetyResult.is_safe !== false;
        var badgeCls = isSafe ? "badge-safe" : "badge-unsafe";
        var badgeText = isSafe ? "SAFE" : "UNSAFE";

        document.getElementById("pipelineSummary").innerHTML =
            '<div style="display:flex; align-items:center; gap:0.75rem; margin-bottom:1rem;">' +
            '<span class="badge ' + badgeCls + '">' + badgeText + '</span>' +
            '<span style="font-size:0.85rem; color:var(--text-muted);">' +
            'Command: <strong>' + escapeHtml(data.original_command || "") + '</strong></span></div>' +
            '<div style="font-size:0.8rem; color:var(--text-muted);">' +
            'Outcome: <strong>' + (data.outcome || "") + '</strong>' +
            (data.total_candidates_generated != null ? ' &middot; Candidates: ' + data.total_candidates_safe + '/' + data.total_candidates_generated + ' safe' : '') +
            '</div>';

        var stages = [];
        var latency = data.latency || {};

        var flaggedDims = safetyResult.flagged_dimensions || [];
        var safetyMargin = safetyResult.safety_margin;

        if (latency.gate1_lint_ms != null || data.rejected_lint != null) {
            var lintFlagged = (data.rejected_lint || 0) > 0;
            var lintCls = lintFlagged ? "stage-unsafe" : "stage-safe";
            var lintTime = latency.gate1_lint_ms != null ? ' (' + latency.gate1_lint_ms.toFixed(0) + 'ms)' : '';
            stages.push('<div class="stage ' + lintCls + '">' +
                '<div class="stage-header">Gate 1: PlanLint' + lintTime + '</div>' +
                '<div style="font-size:0.85rem;">' +
                (lintFlagged ? 'Rejected ' + data.rejected_lint + ' candidate(s)' : 'Passed') +
                '</div></div>');
        }

        if (latency.gate2_screen_ms != null || data.rejected_screen != null) {
            var screenFlagged = (data.rejected_screen || 0) > 0;
            var screenCls = screenFlagged ? "stage-unsafe" : "stage-safe";
            var screenTime = latency.gate2_screen_ms != null ? ' (' + latency.gate2_screen_ms.toFixed(0) + 'ms)' : '';
            stages.push('<div class="stage ' + screenCls + '">' +
                '<div class="stage-header">Gate 2: LLM Screen' + screenTime + '</div>' +
                '<div style="font-size:0.85rem;">' +
                (screenFlagged ? 'Rejected ' + data.rejected_screen + ' candidate(s)' : 'Passed') +
                '</div></div>');
        }

        var evalCls = !isSafe ? "stage-unsafe" : "stage-safe";
        var evalTime = latency.gate3_full_eval_ms != null ? ' (' + latency.gate3_full_eval_ms.toFixed(0) + 'ms)' : '';
        stages.push('<div class="stage ' + evalCls + '">' +
            '<div class="stage-header">Safety Evaluation' + evalTime + '</div>' +
            '<div style="font-size:0.85rem;">Safety margin: ' +
            (safetyMargin != null ? safetyMargin.toFixed(3) : '--') +
            (flaggedDims.length > 0 ? '<br>Flagged: ' + flaggedDims.join(", ") : '') +
            '</div></div>');

        // Dimension-level breakdown
        var dimResults = safetyResult.dimensions || {};
        var dimNames = Object.keys(dimResults);
        if (dimNames.length > 0) {
            var dimHtml = '<div class="stage" style="background:var(--bg-card); border:1px solid var(--border);">' +
                '<div class="stage-header">Dimension Analysis (6 dimensions)</div>';
            dimNames.forEach(function (dimName) {
                var dim = dimResults[dimName];
                var flagged = dim.flagged;
                var assessments = dim.assessments || [];
                var severity = assessments.length > 0 ? assessments[0].severity : "none";
                var reasoning = assessments.length > 0 ? assessments[0].reasoning : "";
                var concern = assessments.length > 0 ? assessments[0].concern : false;

                var dimCls = flagged ? "badge-unsafe" : "badge-safe";
                var dimLabel = flagged ? severity.toUpperCase() : "CLEAR";
                var shortName = dimName.replace("D1_", "D1 ").replace("D2_", "D2 ")
                    .replace("D3_", "D3 ").replace("D4_", "D4 ")
                    .replace("D5_", "D5 ").replace("D6_", "D6 ")
                    .replace(/_/g, " ");

                dimHtml += '<div style="margin:0.4rem 0; padding:0.4rem; border-radius:4px; ' +
                    'background:' + (flagged ? 'rgba(239,68,68,0.08)' : 'rgba(34,197,94,0.05)') + ';">' +
                    '<div style="display:flex; align-items:center; gap:0.5rem;">' +
                    '<span class="badge ' + dimCls + '" style="font-size:0.7rem;">' + dimLabel + '</span>' +
                    '<span style="font-size:0.8rem; font-weight:600;">' + escapeHtml(shortName) + '</span></div>';

                if (reasoning && concern) {
                    dimHtml += '<div style="font-size:0.75rem; color:var(--text-muted); margin-top:0.25rem; ' +
                        'max-height:3rem; overflow:hidden;">' +
                        escapeHtml(reasoning.substring(0, 200)) +
                        (reasoning.length > 200 ? '...' : '') + '</div>';
                }
                dimHtml += '</div>';
            });
            dimHtml += '</div>';
            stages.push(dimHtml);
        }

        document.getElementById("pipelineStages").innerHTML = stages.join("");

        var candidates = data.safe_candidates || [];
        var candidatesCard = document.getElementById("candidatesCard");
        if (candidates.length > 0) {
            candidatesCard.style.display = "block";
            document.getElementById("candidatesList").innerHTML = candidates.map(function (c) {
                var recBadge = c.recommended ? ' <span class="badge badge-success">recommended</span>' : '';
                return '<div class="repair-card' + (c.recommended ? ' selected' : '') + '">' +
                    '<div class="repair-command">' + escapeHtml(c.command || "") + recBadge + '</div>' +
                    '<div class="repair-meta">' +
                    '<span>' + (c.strategy || '') + '</span>' +
                    '<span>Score: ' + (c.score != null ? c.score.toFixed(3) : '--') + '</span>' +
                    '<span>Margin: ' + (c.safety_margin != null ? c.safety_margin.toFixed(2) : '--') + '</span>' +
                    '<span>IG: ' + (c.info_gain != null ? c.info_gain.toFixed(3) : '--') + '</span>' +
                    '</div>' +
                    '<div style="font-size:0.8rem; color:var(--text-muted); margin-top:0.3rem;">' +
                    escapeHtml(c.explanation || '') + '</div></div>';
            }).join("");
        } else {
            candidatesCard.style.display = "none";
        }

        var selected = data.selected_candidate;
        var featureCard = document.getElementById("featureCard");
        if (selected && selected.features) {
            var featDict = selected.features;
            var featValues = FEATURE_KEYS.map(function (k) { return featDict[k] || 0; });
            featureCard.style.display = "block";
            document.getElementById("featureDisplay").innerHTML =
                '<div class="feature-grid">' + featValues.map(function (v, i) {
                    return '<div class="feature-cell"><span class="feat-name">' +
                        FEATURE_NAMES[i] + '</span>' + v.toFixed(2) + '</div>';
                }).join("") + '</div>' +
                '<div style="margin-top:1rem;">' + featValues.map(function (v, i) {
                    var pct = Math.abs(v) * 100;
                    var cls = v >= 0 ? "safe" : "flagged";
                    return '<div class="dimension-bar">' +
                        '<span class="dim-label">' + FEATURE_NAMES[i] + '</span>' +
                        '<div class="bar-track"><div class="bar-fill ' + cls + '" style="width:' + pct + '%"></div></div>' +
                        '<span style="width:40px; text-align:right;">' + v.toFixed(2) + '</span></div>';
                }).join("") + '</div>';
        } else {
            featureCard.style.display = "none";
        }

        var actionPlan = selected && selected.action_plan ? selected.action_plan : null;
        var actionCard = document.getElementById("actionCard");
        if (actionPlan && Array.isArray(actionPlan) && actionPlan.length > 0) {
            actionCard.style.display = "block";
            var code = actionPlan.map(function (step, i) {
                var line = (i + 1) + ". " + step.verb + " " + (step.obj || "");
                if (step.receptacle) line += " → " + step.receptacle;
                return line;
            }).join("\n");
            document.getElementById("actionCode").textContent = code;
        } else {
            actionCard.style.display = "none";
        }

        // Profile-conditioned selections
        var profileCard = document.getElementById("profileCard");
        var fr3Card = document.getElementById("fr3Card");
        var profileSelections = data.profile_selections;
        var fr3Candidates = data.fr3_candidates || [];
        window._lastFR3Candidates = fr3Candidates;

        if (profileSelections && Object.keys(profileSelections).length > 0) {
            profileCard.style.display = "block";
            fr3Card.style.display = "block";

            var profileNames = Object.keys(profileSelections);

            // Show the full safe set with per-profile top-1 selection
            var html = '<h3 style="font-size:0.9rem; margin-bottom:0.5rem;">Validated Safe Set (' +
                fr3Candidates.length + ' candidates)</h3>';

            // Per-profile selection summary
            html += '<table><thead><tr><th>Profile</th><th>Selected Repair (Top-1)</th><th>Strategy</th><th>Score</th></tr></thead><tbody>';
            profileNames.forEach(function (name) {
                var sel = profileSelections[name];
                html += '<tr>' +
                    '<td style="font-weight:600;">' + escapeHtml(name) + '</td>' +
                    '<td>' + escapeHtml(sel.selected_repair) + '</td>' +
                    '<td><span class="badge badge-info">' + escapeHtml(sel.selected_strategy) + '</span></td>' +
                    '<td>' + sel.score + '</td></tr>';
            });
            html += '</tbody></table>';

            // Diversity indicator
            var uniqueRepairs = new Set(profileNames.map(function (n) { return profileSelections[n].selected_index; }));
            var diversityPct = ((uniqueRepairs.size / profileNames.length) * 100).toFixed(0);
            html += '<div style="margin-top:0.75rem; font-size:0.85rem;">' +
                '<strong>Diversity:</strong> ' + uniqueRepairs.size + '/' + profileNames.length +
                ' profiles selected different repairs (' + diversityPct + '% diversity)</div>';

            // Full candidate pool with all profile rankings
            if (fr3Candidates.length > 0 && profileNames.length > 0) {
                var firstProfile = profileNames[0];
                var allScores = profileSelections[firstProfile].all_scores || [];
                if (allScores.length === fr3Candidates.length) {

                    // Compute per-profile rankings
                    var profileRankings = {};
                    profileNames.forEach(function (name) {
                        var scores = profileSelections[name].all_scores || [];
                        var indexed = scores.map(function (s, i) { return { score: s, idx: i }; });
                        indexed.sort(function (a, b) { return b.score - a.score; });
                        var ranks = new Array(scores.length);
                        indexed.forEach(function (item, rank) { ranks[item.idx] = rank + 1; });
                        profileRankings[name] = ranks;
                    });

                    html += '<div style="margin-top:1rem;">';
                    html += '<h3 style="font-size:0.9rem; margin-bottom:0.5rem;">Full Safe Set Ranking (' +
                        fr3Candidates.length + ' candidates × ' + profileNames.length + ' profiles)</h3>';
                    html += '<div style="overflow-x:auto;">';
                    html += '<table style="font-size:0.75rem;"><thead><tr><th>#</th><th>Repair Command</th><th>Strategy</th>';
                    profileNames.forEach(function (name) {
                        var shortName = name.replace('Conservative ', 'Cons. ').replace('Structure-', 'Struct-').replace('Anti-', 'Anti-');
                        html += '<th style="writing-mode:vertical-lr; text-orientation:mixed; max-width:30px;">' +
                            escapeHtml(shortName) + '</th>';
                    });
                    html += '</tr></thead><tbody>';

                    // Sort candidates by first profile's score for readability
                    var sortedIndices = [];
                    for (var si = 0; si < fr3Candidates.length; si++) sortedIndices.push(si);
                    var firstScores = profileSelections[profileNames[0]].all_scores || [];
                    sortedIndices.sort(function (a, b) { return (firstScores[b] || 0) - (firstScores[a] || 0); });

                    sortedIndices.forEach(function (ci) {
                        html += '<tr>';
                        html += '<td>' + (ci + 1) + '</td>';
                        html += '<td style="max-width:350px; word-wrap:break-word; white-space:normal;">' +
                            escapeHtml(fr3Candidates[ci].command) + '</td>';
                        html += '<td><span class="badge badge-info" style="font-size:0.65rem;">' +
                            escapeHtml(fr3Candidates[ci].strategy) + '</span></td>';
                        profileNames.forEach(function (name) {
                            var rank = profileRankings[name][ci];
                            var pSelected = profileSelections[name].selected_index;
                            var isTop = (ci === pSelected);
                            var bgColor = isTop ? 'rgba(59,130,246,0.15)' :
                                (rank <= 3 ? 'rgba(34,197,94,0.08)' : 'transparent');
                            html += '<td style="text-align:center; background:' + bgColor + ';' +
                                (isTop ? 'font-weight:700; color:var(--primary);' : '') + '">' +
                                '#' + rank + (isTop ? ' ★' : '') + '</td>';
                        });
                        html += '</tr>';
                    });
                    html += '</tbody></table></div></div>';
                }
            }

            document.getElementById("profileSelections").innerHTML = html;

            // FR3 code selector
            var selectEl = document.getElementById("fr3ProfileSelect");
            selectEl.innerHTML = profileNames.map(function (name) {
                return '<option value="' + escapeHtml(name) + '">' + escapeHtml(name) + '</option>';
            }).join("");

            window._profileSelections = profileSelections;
            selectEl.addEventListener("change", updateFR3Code);
            updateFR3Code();
        } else {
            profileCard.style.display = "none";
            fr3Card.style.display = "none";
        }
    }

    function updateFR3Code() {
        var selectEl = document.getElementById("fr3ProfileSelect");
        var profile = selectEl.value;
        var sel = window._profileSelections && window._profileSelections[profile];
        if (sel && sel.fr3_code) {
            var fullScript = '#!/usr/bin/env python3\n' +
                '"""FR3 script - ' + profile + '"""\n\n' +
                'from franka_interface import FrankaRobot\n\n' +
                'robot = FrankaRobot()\nrobot.connect()\n\n' +
                sel.fr3_code + '\n\n' +
                'robot.disconnect()\n';
            document.getElementById("fr3Code").textContent = fullScript;
        } else {
            document.getElementById("fr3Code").textContent = "# No FR3 code available for this profile";
        }
    }

    function detectScene() {
        var input = document.getElementById("imageUpload");
        if (!input.files.length) return;

        var btn = document.getElementById("detectBtn");
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner"></span> Detecting...';

        var reader = new FileReader();
        reader.onload = function (e) {
            var b64 = e.target.result.split(",")[1];
            var provider = document.getElementById("provider").value;
            var model = document.getElementById("model").value;
            var hint = document.getElementById("vlmHint").value.trim();

            fetch("/api/vlm/detect", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    image: b64,
                    provider: provider,
                    model: model,
                    context_hint: hint
                })
            })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.error) {
                    alert("VLM Error: " + data.error);
                    return;
                }
                renderVLMResult(data);
            })
            .catch(function (e) { alert("Detection failed: " + e); })
            .finally(function () {
                btn.disabled = false;
                btn.textContent = "Detect Objects";
            });
        };
        reader.readAsDataURL(input.files[0]);
    }

    function renderVLMResult(data) {
        var el = document.getElementById("vlmResult");
        el.style.display = "block";

        window._vlmRoomType = data.room_type || "unknown";
        window._vlmDescription = data.description || "";
        window._vlmObjects = (data.objects || []).slice();

        if (data.scene_context) {
            document.getElementById("sceneContext").value = data.scene_context;
        }

        rebuildVLMTable();
    }

    function rebuildVLMTable() {
        var objects = window._vlmObjects || [];
        var html = '<div style="font-size:0.85rem; margin-bottom:0.5rem;">' +
            'Room: <strong>' + escapeHtml(window._vlmRoomType) + '</strong> &middot; ' +
            objects.length + ' objects</div>' +
            '<table><thead><tr><th>Object</th><th>Hazard</th><th>Location</th><th></th></tr></thead><tbody>' +
            objects.map(function (o, idx) {
                var name = o.name || o.object_type || "";
                var hazard = (o.properties && o.properties.hazard) || o.hazard || "none";
                if (hazard === "null" || !hazard) hazard = "none";
                var loc = o.position || o.location || "";
                var hCls = hazard !== "none" ? "badge-unsafe" : "badge-safe";
                return '<tr><td>' + escapeHtml(name) + '</td>' +
                    '<td><span class="badge ' + hCls + '">' + escapeHtml(hazard) + '</span></td>' +
                    '<td>' + escapeHtml(loc) + '</td>' +
                    '<td><button class="btn-remove-obj" data-idx="' + idx +
                    '" title="Remove from scene" style="background:none; border:none; color:#e55; cursor:pointer; font-size:1rem; padding:0 0.3rem;">&times;</button></td></tr>';
            }).join("") + '</tbody></table>';

        document.getElementById("vlmObjects").innerHTML = html;

        document.querySelectorAll(".btn-remove-obj").forEach(function (btn) {
            btn.addEventListener("click", function () {
                var idx = parseInt(this.dataset.idx, 10);
                removeVLMObject(idx);
            });
        });
    }

    function removeVLMObject(idx) {
        var objects = window._vlmObjects;
        if (!objects || idx < 0 || idx >= objects.length) return;
        objects.splice(idx, 1);
        window._vlmObjects = objects;

        var ctx = rebuildSceneContext(window._vlmRoomType, window._vlmDescription, objects);
        document.getElementById("sceneContext").value = ctx;

        rebuildVLMTable();

        fetch("/api/vlm/update-objects", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ objects: objects, room_type: window._vlmRoomType, description: window._vlmDescription })
        }).catch(function (e) { console.error("Failed to sync edited scene:", e); });
    }

    function rebuildSceneContext(roomType, description, objects) {
        var lines = ["Room: " + roomType];
        if (description) lines.push("Description: " + description);

        var names = objects.map(function (o) { return o.name || ""; }).filter(Boolean);
        var unique = [];
        var seen = {};
        names.forEach(function (n) { if (!seen[n]) { seen[n] = true; unique.push(n); } });
        unique.sort();

        lines.push("\nObjects in scene (" + unique.length + "):");
        unique.forEach(function (name) {
            var obj = objects.find(function (o) { return o.name === name; });
            var props = obj.properties || {};
            var tags = [];
            if (props.pickupable) tags.push("pickupable");
            if (props.openable) tags.push("openable");
            if (props.toggleable) tags.push("toggleable");
            if (props.breakable) tags.push("breakable");
            if (props.sliceable) tags.push("sliceable");
            if (props.sharp) tags.push("sharp");
            if (props.hot_when_on) tags.push("hot when on");
            if (props.hazard && props.hazard !== "null") tags.push("hazard: " + props.hazard);
            var tagStr = tags.length > 0 ? " [" + tags.join(", ") + "]" : "";
            var cat = obj.category || "object";
            lines.push("  - " + name + " (" + cat + ")" + tagStr);
        });

        return lines.join("\n");
    }

    function escapeHtml(str) {
        var div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }

    window.copyActionCode = function () {
        var code = document.getElementById("actionCode").textContent;
        navigator.clipboard.writeText(code).catch(function () {});
    };

    window.copyFR3Code = function () {
        var code = document.getElementById("fr3Code").textContent;
        navigator.clipboard.writeText(code).catch(function () {});
    };

    window.downloadScripts = function () {
        var command = document.getElementById("commandInput").value.trim();
        var fr3Candidates = window._lastFR3Candidates || [];
        var profileSelections = window._profileSelections || {};

        var btn = document.getElementById("downloadScriptsBtn");
        btn.disabled = true;
        btn.textContent = "Preparing...";

        fetch("/api/pipeline/download-scripts", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                command: command,
                fr3_candidates: fr3Candidates,
                profile_selections: profileSelections,
            })
        })
        .then(function (r) { return r.blob(); })
        .then(function (blob) {
            var url = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = url;
            a.download = "casper_fr3_scripts.zip";
            a.click();
            URL.revokeObjectURL(url);
        })
        .catch(function (e) { alert("Download failed: " + e); })
        .finally(function () {
            btn.disabled = false;
            btn.textContent = "Download All FR3 Scripts (ZIP)";
        });
    };
})();
