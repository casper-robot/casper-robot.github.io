"""
CASPER Safety Pipeline

Wires together:
- LLM interface (neural component)
- Prompt templates (symbolic, fixed)
- Safety kernel (symbolic, deterministic)

Flow:
  Step 1: Build interaction graph
  Step 2: Evaluate 6 harm dimensions concurrently
  Step 3: Any-flag-unsafe aggregation → SafetyResult

"""

from __future__ import annotations
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

from casper.safety_kernel import (
    Entity,
    Relationship,
    InteractionGraph,
    HarmDimension,
    DimensionAssessment,
    DimensionResult,
    SafetyConfig,
    SafetyResult,
    SafetyKernel,
    HazardDiagnosis,
)
from casper.action_ir import CanonicalAction
from casper.prompt_templates import (
    render_prompt,
    DIMENSION_TEMPLATE_MAP,
    REPAIR_DIMENSION_TEMPLATE_MAP,
)
from casper.llm_interface import LLMBackend, LLMResponse

logger = logging.getLogger(__name__)


# Response Parsers

def parse_graph_response(response: LLMResponse) -> InteractionGraph:
    """Parse an LLM response into an InteractionGraph."""
    graph = InteractionGraph()

    if not response.success:
        logger.warning(f"Graph parse failed: {response.parse_error}. Returning empty graph.")
        return graph

    data = response.parsed

    # Parse entities
    for e in data.get("entities", []):
        graph.add_entity(Entity(
            name=e.get("name", "unknown"),
            description=e.get("description", ""),
            entity_type=e.get("entity_type", "object"),
        ))

    # Parse relationships
    for r in data.get("relationships", []):
        graph.add_relationship(Relationship(
            source=r.get("source", ""),
            target=r.get("target", ""),
            relation=r.get("relation", "unknown"),
            description=r.get("description", ""),
        ))

    return graph


def parse_dimension_response(
    response: LLMResponse,
    dimension: HarmDimension,
    pass_id: int,
) -> DimensionAssessment:
    """Parse an LLM response into a DimensionAssessment."""
    if not response.success:
        logger.warning(
            f"Dimension {dimension.name} pass {pass_id} parse failed: "
            f"{response.parse_error}. Defaulting to CONCERN (conservative)."
        )
        return DimensionAssessment(
            dimension=dimension,
            concern=True,  # Conservative default on parse failure
            reasoning=f"Parse failure — conservative default. Error: {response.parse_error}",
            severity="unknown",
            pass_id=pass_id,
        )

    data = response.parsed
    return DimensionAssessment(
        dimension=dimension,
        concern=bool(data.get("concern", True)),  # Default to concern if missing
        reasoning=data.get("reasoning", "No reasoning provided."),
        severity=data.get("severity", "unknown"),
        pass_id=pass_id,
    )


@dataclass
class ScreenResult:
    """Gate 2: Single-call structured safety screen result."""
    resolved: bool
    resolution_reasoning: str
    dimension_verdicts: dict[HarmDimension, bool] = field(default_factory=dict)
    dimension_reasoning: dict[HarmDimension, str] = field(default_factory=dict)
    is_safe: bool = False
    safety_margin: float = 0.0

    @property
    def flagged_dimensions(self) -> list[HarmDimension]:
        return [d for d, flagged in self.dimension_verdicts.items() if flagged]


@dataclass
class RepairCandidate:
    """A generated repair candidate with its metadata."""
    command: str
    strategy: str         # H1-H7
    explanation: str
    action_plan: list[CanonicalAction] = field(default_factory=list)
    required_skills: list[str] = field(default_factory=list)
    expected_end_state: str = ""
    declared_posture: str = ""  # LLM-declared repair posture (local/moderate/strong)
    safety_result: SafetyResult | None = None
    lint_result: object | None = None      # LintResult (imported at use site to avoid circular)
    screen_result: ScreenResult | None = None

    @property
    def is_safe(self) -> bool:
        return self.safety_result is not None and self.safety_result.is_safe

    @property
    def safety_margin(self) -> float:
        if self.safety_result and self.safety_result.is_safe:
            return self.safety_result.safety_margin
        return 0.0


def parse_repair_response(response: LLMResponse) -> list[RepairCandidate]:
    """Parse an LLM repair generation response into RepairCandidates.

    Handles both old format (command/strategy/explanation only) and new
    bundled format (with action_plan, required_skills, expected_end_state).
    """
    if not response.success:
        logger.warning(f"Repair parse failed: {response.parse_error}. Returning empty list.")
        return []

    data = response.parsed
    candidates = []
    for c in data.get("candidates", []):
        cmd = c.get("command", "").strip()
        if not cmd:
            continue

        action_plan: list[CanonicalAction] = []
        for step in c.get("action_plan", []):
            if isinstance(step, dict) and "verb" in step:
                action_plan.append(CanonicalAction.from_dict(step))

        candidates.append(RepairCandidate(
            command=cmd,
            strategy=c.get("strategy", "unknown"),
            explanation=c.get("explanation", ""),
            action_plan=action_plan,
            required_skills=c.get("required_skills", []),
            expected_end_state=c.get("expected_end_state", ""),
            declared_posture=c.get("repair_posture", ""),
        ))

    return candidates


_DIM_KEY_MAP = {
    "D1_direct_interaction": HarmDimension.D1_DIRECT_INTERACTION,
    "D2_resulting_state": HarmDimension.D2_RESULTING_STATE,
    "D3_barrier_removal": HarmDimension.D3_BARRIER_REMOVAL,
    "D4_foreseeable_chain": HarmDimension.D4_FORESEEABLE_CHAIN,
    "D5_value_property": HarmDimension.D5_VALUE_PROPERTY,
    "D6_normative_violation": HarmDimension.D6_NORMATIVE_VIOLATION,
}


def parse_screen_response(response: LLMResponse) -> ScreenResult:
    """Parse a Gate 2 safety screen LLM response into a ScreenResult."""
    if not response.success:
        logger.warning(
            f"Screen parse failed: {response.parse_error}. "
            f"Defaulting to unsafe (conservative)."
        )
        return ScreenResult(
            resolved=False,
            resolution_reasoning=f"Parse failure: {response.parse_error}",
            is_safe=False,
            safety_margin=0.0,
        )

    data = response.parsed
    resolved = bool(data.get("resolves_original_hazard", False))
    resolution_reasoning = data.get("resolution_reasoning", "")

    dimension_verdicts: dict[HarmDimension, bool] = {}
    dimension_reasoning: dict[HarmDimension, str] = {}

    new_concerns = data.get("new_concerns", {})
    for key, dim in _DIM_KEY_MAP.items():
        entry = new_concerns.get(key, {})
        concern = bool(entry.get("concern", False))
        dimension_verdicts[dim] = concern
        dimension_reasoning[dim] = entry.get("reasoning", "")

    any_new_concern = any(dimension_verdicts.values())
    is_safe = resolved and not any_new_concern
    safety_margin = 1.0 if is_safe else 0.0

    return ScreenResult(
        resolved=resolved,
        resolution_reasoning=resolution_reasoning,
        dimension_verdicts=dimension_verdicts,
        dimension_reasoning=dimension_reasoning,
        is_safe=is_safe,
        safety_margin=safety_margin,
    )


# Safety Pipeline

class SafetyPipeline:
    """
    Safety evaluation pipeline.

    1 graph construction + 6 dimension evaluations = 7 LLM calls.
    All 6 dimension evaluations run concurrently.
    """

    def __init__(
        self,
        llm: LLMBackend,
        config: SafetyConfig | None = None,
        repair_config=None,
    ):
        self.llm = llm
        self.config = config or SafetyConfig()
        self.repair_config = repair_config
        self.kernel = SafetyKernel(self.config)

    # Step 1: Interaction Graph Construction

    def build_interaction_graph(
        self,
        command: str,
        scene_context: str,
    ) -> InteractionGraph:
        """Build the interaction graph (1 LLM call)."""
        prompt = render_prompt(
            "graph_construction",
            command=command,
            scene_context=scene_context,
        )
        response = self.llm.generate_parsed(prompt, temperature=0.3)
        graph = parse_graph_response(response)
        logger.info(
            f"Interaction graph: "
            f"{graph.entity_count()} entities, "
            f"{graph.relationship_count()} relationships"
        )
        return graph

    def _build_repair_graph(
        self,
        repair_command: str,
        scene_context: str,
        original_graph: InteractionGraph,
    ) -> InteractionGraph:
        augmented_context = (
            f"{scene_context}\n\n"
            f"ORIGINAL COMMAND INTERACTION GRAPH (for reference — "
            f"the repair changes some of these relationships):\n"
            f"{original_graph.to_text()}"
        )
        prompt = render_prompt(
            "graph_construction",
            command=repair_command,
            scene_context=augmented_context,
        )
        response = self.llm.generate_parsed(prompt, temperature=0.3)
        graph = parse_graph_response(response)
        logger.info(
            f"Repair interaction graph: "
            f"{graph.entity_count()} entities, "
            f"{graph.relationship_count()} relationships"
        )
        return graph

    # Step 2: Harm Dimension Evaluation (Structurally Forced)

    def evaluate_dimensions(
        self,
        command: str,
        scene_context: str,
        interaction_graph: InteractionGraph,
    ) -> dict[HarmDimension, DimensionResult]:
        graph_text = interaction_graph.to_text()

        def _eval_one(dim: HarmDimension) -> DimensionAssessment:
            template_key = DIMENSION_TEMPLATE_MAP[dim.value]
            prompt = render_prompt(
                template_key,
                command=command,
                scene_context=scene_context,
                interaction_graph=graph_text,
            )
            response = self.llm.generate_parsed(prompt, temperature=0.3)
            return parse_dimension_response(response, dim, pass_id=0)

        # All 6 dimensions concurrently
        assessments: dict[HarmDimension, DimensionAssessment] = {}
        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = {pool.submit(_eval_one, dim): dim for dim in HarmDimension}
            for future in as_completed(futures):
                dim = futures[future]
                assessments[dim] = future.result()

        results = {}
        for dim in HarmDimension:
            result = self.kernel.aggregate_dimension([assessments[dim]])
            results[dim] = result
            logger.debug(
                f"{dim.name}: {'FLAGGED' if result.flagged else 'clear'}"
            )

        return results

    # Full Evaluation

    def evaluate(
        self,
        command: str,
        scene_context: str,
    ) -> SafetyResult:
        """
        Complete safety evaluation: 1 graph + 6 dimensions = 7 LLM calls.
        """
        g_star = self.build_interaction_graph(command, scene_context)

        dimension_results = self.evaluate_dimensions(
            command, scene_context, g_star
        )

        result = self.kernel.evaluate_safety(
            command=command,
            dimension_results=dimension_results,
            interaction_graph=g_star,
        )

        logger.info(
            f"Safety evaluation: {'SAFE' if result.is_safe else 'UNSAFE'} "
            f"(margin={result.safety_margin:.3f}, "
            f"flagged={[d.name for d in result.flagged_dimensions]})"
        )

        return result

    def evaluate_candidates(
        self,
        candidates: list[str],
        scene_context: str,
    ) -> list[SafetyResult]:
        """Evaluate a list of repair candidates concurrently. Returns results in order."""
        if len(candidates) <= 1:
            return [self.evaluate(c, scene_context) for c in candidates]

        results = [None] * len(candidates)
        with ThreadPoolExecutor(max_workers=min(len(candidates), 8)) as pool:
            futures = {
                pool.submit(self.evaluate, c, scene_context): i
                for i, c in enumerate(candidates)
            }
            for future in as_completed(futures):
                i = futures[future]
                results[i] = future.result()
        return results

    def filter_safe(
        self,
        candidates: list[str],
        scene_context: str,
    ) -> tuple[list[str], list[SafetyResult]]:
        results = self.evaluate_candidates(candidates, scene_context)
        safe_commands = []
        safe_results = []

        for cmd, result in zip(candidates, results):
            if result.is_safe:
                safe_commands.append(cmd)
                safe_results.append(result)

        logger.info(
            f"Filtered: {len(safe_commands)}/{len(candidates)} candidates are safe"
        )

        return safe_commands, safe_results

    # Plan-Aware Repair Evaluation (Gate 3)

    def evaluate_repair(
        self,
        candidate: RepairCandidate,
        diagnosis: HazardDiagnosis,
        scene_context: str,
        interaction_graph: InteractionGraph | None = None,
        original_graph: InteractionGraph | None = None,
    ) -> SafetyResult:
        if interaction_graph is not None:
            g_star = interaction_graph
        elif original_graph is not None:
            g_star = self._build_repair_graph(
                candidate.command, scene_context, original_graph,
            )
        else:
            g_star = self.build_interaction_graph(
                candidate.command, scene_context,
            )

        action_plan_text = "\n".join(
            f"  {i+1}. {a.verb}"
            + (f" {a.obj}" if a.obj else "")
            + (f" → {a.receptacle}" if a.receptacle else "")
            for i, a in enumerate(candidate.action_plan)
        ) if candidate.action_plan else "(no structured plan provided)"

        expected_end_state = candidate.expected_end_state or "(not specified)"
        hazard_diagnosis_text = diagnosis.to_prompt_context()
        graph_text = g_star.to_text()

        def _eval_one(dim: HarmDimension) -> DimensionAssessment:
            template_key = REPAIR_DIMENSION_TEMPLATE_MAP[dim.value]
            prompt = render_prompt(
                template_key,
                command=candidate.command,
                scene_context=scene_context,
                interaction_graph=graph_text,
                action_plan=action_plan_text,
                expected_end_state=expected_end_state,
                hazard_diagnosis=hazard_diagnosis_text,
            )
            response = self.llm.generate_parsed(prompt, temperature=0.3)
            return parse_dimension_response(response, dim, pass_id=0)

        assessments: dict[HarmDimension, DimensionAssessment] = {}
        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = {pool.submit(_eval_one, dim): dim for dim in HarmDimension}
            for future in as_completed(futures):
                dim = futures[future]
                assessments[dim] = future.result()

        results = {}
        for dim in HarmDimension:
            result = self.kernel.aggregate_dimension([assessments[dim]])
            results[dim] = result
            logger.debug(
                f"{dim.name}: {'FLAGGED' if result.flagged else 'clear'}"
            )

        safety_result = self.kernel.evaluate_safety(
            command=candidate.command,
            dimension_results=results,
            interaction_graph=g_star,
        )

        logger.info(
            f"Plan-aware Gate 3: '{candidate.command[:50]}' → "
            f"{'SAFE' if safety_result.is_safe else 'UNSAFE'} "
            f"(margin={safety_result.safety_margin:.3f}, "
            f"flagged={[d.name for d in safety_result.flagged_dimensions]})"
        )

        return safety_result

    # Hazard Diagnosis Extraction

    def extract_diagnosis(self, safety_result: SafetyResult) -> HazardDiagnosis:
        if safety_result.is_safe:
            raise ValueError("Cannot extract diagnosis from a safe result")

        graph = safety_result.interaction_graph or InteractionGraph()

        hazardous_entities: set[str] = set()
        hazardous_relationships: list[dict] = []
        dimension_reasoning: dict[HarmDimension, str] = {}

        for dim in safety_result.flagged_dimensions:
            dr = safety_result.dimension_results.get(dim)
            if dr is None:
                continue
            for a in dr.assessments:
                if a.concern and a.reasoning:
                    dimension_reasoning[dim] = a.reasoning
                    break

        for dim in safety_result.flagged_dimensions:
            dr = safety_result.dimension_results.get(dim)
            if dr is None:
                continue
            for a in dr.assessments:
                if not a.concern:
                    continue
                reasoning_lower = a.reasoning.lower()
                for entity in graph.entities:
                    if entity.name.lower() in reasoning_lower:
                        hazardous_entities.add(entity.name)

        for rel in graph.relationships:
            src_hazardous = rel.source.lower().strip() in {e.lower() for e in hazardous_entities}
            tgt_hazardous = rel.target.lower().strip() in {e.lower() for e in hazardous_entities}
            if src_hazardous or tgt_hazardous:
                hazardous_relationships.append({
                    'source': rel.source,
                    'target': rel.target,
                    'relation': rel.relation,
                    'description': rel.description,
                })

        return HazardDiagnosis(
            hazardous_entities=hazardous_entities,
            hazardous_relationships=hazardous_relationships,
            flagged_dimensions=list(safety_result.flagged_dimensions),
            dimension_reasoning=dimension_reasoning,
            hazard_summary=safety_result.hazard_summary(),
            interaction_graph=graph,
        )

    # Structured Operator-Conditioned Repair Generation

    def _generate_repairs_structured(
        self,
        command: str,
        scene_context: str,
        diagnosis: HazardDiagnosis,
        K: int = 7,
        entity_names: set[str] | None = None,
        scene_objects: list[str] | None = None,
        allowed_verbs: set[str] | None = None,
    ) -> list[RepairCandidate]:
        """Operator-conditioned repair generation (structured mode).

        Pipeline:
          1. Build TaskFrame, repair guidance, grounding pack
          2. Generate operator-conditioned LLM candidates (all 6 operators)
          3. Pre-lint → Critic → Dedup → Coverage check
        """
        from casper.task_frame import build_task_frame
        from casper.repair_grounding import build_grounding_pack
        from casper.repair_operators import (
            REPAIR_OPERATORS,
            generate_repairs_by_operator,
            prelint_candidate,
            deduplicate_candidates,
            ensure_operator_coverage,
        )
        from casper.repair_critic import critique_and_rank
        from casper.safety_kernel import derive_repair_guidance

        graph = diagnosis.interaction_graph

        # Step 1: Build internal representations
        task_frame = build_task_frame(command, scene_context, graph)
        diagnosis = derive_repair_guidance(diagnosis, task_frame)
        grounding = build_grounding_pack(
            scene_entities=entity_names,
            scene_objects=scene_objects,
            robot_skills=allowed_verbs,
            diagnosis=diagnosis,
        )

        # Step 2: Operator-conditioned LLM candidates (all 6 operators, parallel)
        all_candidates: list[RepairCandidate] = []
        repair_diagnostics: list[dict] = []
        logger.info(f"Attempting all operators in parallel: {REPAIR_OPERATORS}")

        max_per_op = self.repair_config.max_candidates_per_operator

        from concurrent.futures import ThreadPoolExecutor, as_completed
        from casper.llm_providers import create_llm_backend

        # Each operator gets its own LLM backend to avoid shared state
        model_name = self.llm.model_name
        from casper.llm_providers import MODEL_REGISTRY
        provider = MODEL_REGISTRY.get(model_name, {}).get("provider", "openai")

        def _run_operator(op):
            try:
                worker_llm = create_llm_backend(provider, model=model_name)
                candidates, need = generate_repairs_by_operator(
                    command=command,
                    task_frame=task_frame,
                    diagnosis=diagnosis,
                    grounding=grounding,
                    operator=op,
                    llm=worker_llm,
                    scene_context=scene_context,
                    max_candidates=max_per_op,
                )
                return op, candidates, need, None
            except Exception as e:
                return op, [], "", str(e)

        underlying_need = ""
        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = {pool.submit(_run_operator, op): op for op in REPAIR_OPERATORS}
            for future in as_completed(futures):
                op, candidates, need, error = future.result()
                if error:
                    logger.warning(f"Operator {op} failed: {error}")
                    repair_diagnostics.append({
                        "operator": op, "raw_count": 0, "error": error,
                    })
                else:
                    repair_diagnostics.append({
                        "operator": op,
                        "raw_count": len(candidates),
                        "raw_commands": [c.command for c in candidates],
                    })
                    all_candidates.extend(candidates)
                    if need and not underlying_need:
                        underlying_need = need

        logger.info(
            f"Structured generation: {len(all_candidates)} raw candidates "
            f"from {len(REPAIR_OPERATORS)} operators"
        )
        for diag in repair_diagnostics:
            logger.info(
                f"  {diag['operator']}: {diag['raw_count']} raw — "
                f"{diag.get('raw_commands', diag.get('error', ''))}"
            )

        # Step 3: Quality pipeline
        # Pre-lint — track what gets rejected and why
        prelint_rejected: list[dict] = []
        if self.repair_config.enable_prelint:
            passed = []
            entities_lower = {e.lower() for e in grounding.scene_entities}
            from casper.repair_operators import _VERB_ALIASES
            skills_lower = {s.lower() for s in grounding.robot_skills}
            for alias, canonical in _VERB_ALIASES.items():
                if canonical in skills_lower:
                    skills_lower.add(alias)

            for c in all_candidates:
                if prelint_candidate(c, grounding):
                    passed.append(c)
                else:
                    reasons = []
                    for a in c.action_plan:
                        if a.verb.lower() not in skills_lower:
                            reasons.append(f"verb '{a.verb}' not in skills")
                        if a.obj and a.obj.lower() not in entities_lower:
                            reasons.append(f"obj '{a.obj}' not in scene")
                        if a.receptacle and a.receptacle.lower() not in entities_lower:
                            reasons.append(f"receptacle '{a.receptacle}' not in scene")
                    if not c.action_plan:
                        reasons.append("no action plan")
                    prelint_rejected.append({
                        "command": c.command[:80],
                        "strategy": c.strategy,
                        "reasons": reasons,
                    })
                    logger.info(
                        f"  Pre-lint REJECTED [{c.strategy}] "
                        f"'{c.command[:60]}' — {reasons}"
                    )
            all_candidates = passed
            if prelint_rejected:
                logger.info(f"Pre-lint rejected {len(prelint_rejected)} candidates")

        # Critic
        from casper.repair_critic import critique_candidate
        critic_rejected: list[dict] = []
        before_critic = len(all_candidates)
        all_candidates = critique_and_rank(
            all_candidates, task_frame, diagnosis, grounding,
        )
        critic_rejected_count = before_critic - len(all_candidates)

        # Deduplication
        before_dedup = len(all_candidates)
        if self.repair_config.enable_dedup:
            all_candidates = deduplicate_candidates(all_candidates)
        dedup_removed = before_dedup - len(all_candidates)

        # Coverage check
        if self.repair_config.enable_coverage_check:
            all_candidates = ensure_operator_coverage(all_candidates)

        logger.info(f"Structured generation: {len(all_candidates)} final candidates")

        # Store diagnostics and underlying need for downstream use
        self._last_repair_diagnostics = {
            "per_operator": repair_diagnostics,
            "prelint_rejected": prelint_rejected,
            "critic_rejected": critic_rejected_count,
            "dedup_removed": dedup_removed,
            "final_count": len(all_candidates),
            "underlying_need": underlying_need,
        }
        self._last_underlying_need = underlying_need
        if underlying_need:
            logger.info(f"Underlying need: {underlying_need}")

        return all_candidates

    # Gate 2: LLM Safety Screen

    def screen_repair(
        self,
        candidate: RepairCandidate,
        diagnosis: HazardDiagnosis,
        scene_context: str,
        original_command: str = "",
        underlying_need: str = "",
    ) -> ScreenResult:
        """Gate 2: Single-call structured safety screen (1 LLM call).

        Receives the hazard diagnosis, repair command, action plan, and
        expected end state. Returns whether the repair resolves the original
        hazard and whether it introduces new concerns across D1-D6.

        This is a pruning layer, not a safety replacement.
        """
        action_plan_text = "\n".join(
            f"  {i+1}. {a.verb}"
            + (f" {a.obj}" if a.obj else "")
            + (f" → {a.receptacle}" if a.receptacle else "")
            for i, a in enumerate(candidate.action_plan)
        ) if candidate.action_plan else "(no structured plan provided)"

        prompt = render_prompt(
            "safety_screen",
            original_command=original_command,
            hazard_diagnosis=diagnosis.to_prompt_context(),
            repair_command=candidate.command,
            action_plan=action_plan_text,
            expected_end_state=candidate.expected_end_state or "(not specified)",
            scene_context=scene_context,
            underlying_need=underlying_need or "accomplish the task safely",
        )

        response = self.llm.generate_parsed(prompt, temperature=0.3)
        result = parse_screen_response(response)

        logger.debug(
            f"Screen '{candidate.command[:40]}...': "
            f"resolved={result.resolved}, safe={result.is_safe}"
        )

        return result

    # Repair Generation + Safety Filtering

    def generate_repairs(
        self,
        command: str,
        scene_context: str,
        safety_result: SafetyResult | None = None,
        K: int = 7,
        entity_names: set[str] | None = None,
        diagnosis: HazardDiagnosis | None = None,
        scene_objects: list[str] | None = None,
        object_instances: list[dict] | None = None,
        evaluate: bool = True,
        objective_frame=None,
        allowed_verbs: set[str] | None = None,
    ) -> list[RepairCandidate]:
        """Generate K repair candidates and filter through safety pipeline."""
        # Check for structured operator mode
        if (self.repair_config
                and self.repair_config.generation_mode == "structured_operator"
                and diagnosis is not None):
            return self._generate_repairs_structured(
                command=command,
                scene_context=scene_context,
                diagnosis=diagnosis,
                K=K,
                entity_names=entity_names,
                scene_objects=scene_objects,
                allowed_verbs=allowed_verbs,
            )

        # Legacy mode: Step 1: Build causal diagnosis context
        if diagnosis is not None:
            causal_diagnosis = diagnosis.to_prompt_context()
        elif safety_result is not None:
            causal_diagnosis = (
                f"HAZARD SUMMARY:\n{safety_result.hazard_summary()}"
            )
        else:
            raise ValueError("Either diagnosis or safety_result must be provided")

        # Build entity constraint instruction if entities are available
        entity_constraint = ""
        if entity_names:
            entity_list = ", ".join(sorted(entity_names))
            entity_constraint = (
                f"IMPORTANT: Only reference objects that exist in the scene. "
                f"Available objects: {entity_list}\n"
                f"Do NOT propose repairs involving objects not in this list.\n"
            )

        # Build valid verbs context
        from casper.action_ir import VALID_ACTION_VERBS
        verb_set = allowed_verbs or VALID_ACTION_VERBS
        valid_verbs = (
            f"VALID ACTION VERBS: {', '.join(sorted(verb_set))}\n"
            f"Only use these verbs in the action_plan.\n"
        )

        # Build scene objects context
        scene_objects_str = ""
        if scene_objects:
            scene_objects_str = (
                f"OBJECTS IN SCENE: {', '.join(sorted(scene_objects))}\n"
                f"Action plans must only reference objects from this list.\n"
            )

        # Build objective context from frame (if available)
        objective_context_str = ""
        if objective_frame is not None:
            lines = ["TASK OBJECTIVE:"]
            gi = objective_frame.goal_intent
            lines.append(f"  Goal: {gi.verb}({gi.target_object or '?'} → {gi.recipient or '?'})")
            if objective_frame.task_referents:
                lines.append(f"  Key entities: {', '.join(objective_frame.task_referents)}")
            if objective_frame.target_relations:
                rels = [f"{r.relation_type}({r.source} → {r.target})"
                        for r in objective_frame.target_relations]
                lines.append(f"  Target relations: {', '.join(rels)}")
            anch = objective_frame.repair_anchors
            preserve = []
            if anch.preserve_goal:
                preserve.append("goal verb/recipient")
            if anch.preserve_primary_object:
                preserve.append("primary object")
            if anch.preserve_recipient:
                preserve.append("recipient")
            mutable = anch.mutable_fields
            if preserve:
                lines.append(f"  Preserve if safe: {', '.join(preserve)}")
            if mutable:
                lines.append(f"  May change for safety: {', '.join(mutable)}")
            objective_context_str = "\n".join(lines) + "\n"

        # Step 2: Call LLM for repair candidates
        prompt = render_prompt(
            "repair_generation",
            command=command,
            scene_context=scene_context,
            causal_diagnosis=causal_diagnosis,
            K=K,
            entity_constraint=entity_constraint,
            valid_verbs=valid_verbs,
            scene_objects=scene_objects_str,
            objective_context=objective_context_str,
        )

        response = self.llm.generate_parsed(prompt, temperature=0.7)
        candidates = parse_repair_response(response)

        if not candidates:
            logger.warning("No repair candidates generated.")
            return []

        logger.info(f"Generated {len(candidates)} repair candidates")

        if evaluate:
            # Step 3: Evaluate each candidate through safety pipeline (concurrently)
            def _eval_candidate(candidate: RepairCandidate) -> None:
                try:
                    candidate.safety_result = self.evaluate(
                        candidate.command, scene_context
                    )
                except Exception as e:
                    logger.error(
                        f"Safety evaluation failed for candidate "
                        f"'{candidate.command}': {e}"
                    )

            with ThreadPoolExecutor(max_workers=min(len(candidates), 8)) as pool:
                list(pool.map(_eval_candidate, candidates))

            safe_count = sum(1 for c in candidates if c.is_safe)
            logger.info(
                f"Repair filtering: {safe_count}/{len(candidates)} candidates are safe"
            )

        return candidates

    def get_safe_repairs(
        self,
        command: str,
        scene_context: str,
        safety_result: SafetyResult,
        K: int = 7,
    ) -> list[RepairCandidate]:
        """
        Convenience: generate repairs and return only safe ones,
        sorted by safety margin (highest first).
        """
        all_candidates = self.generate_repairs(
            command, scene_context, safety_result, K
        )
        safe = [c for c in all_candidates if c.is_safe]
        safe.sort(key=lambda c: c.safety_margin, reverse=True)
        return safe
