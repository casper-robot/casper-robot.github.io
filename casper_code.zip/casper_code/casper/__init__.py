"""
CASPER — Constrained Bayesian Preference Learning for Personalized Robot Task Repair

Public API:
    CasperPipeline       — End-to-end Algorithm 1 pipeline
    SafetyPipeline       — Safety evaluation subsystem (Steps 1-3)
    PreferenceModel      — Bayesian preference model with Laplace updates
    FeatureExtractor     — Strategy feature extraction (φ₁-φ₁₀)
    SafetyConfig         — Safety kernel configuration (N_G, N, k)
    PreferenceConfig     — Preference model hyperparameters (beta, lambda, epsilon)
"""

from casper.safety_kernel import SafetyConfig, SafetyResult, HarmDimension
from casper.safety_pipeline import SafetyPipeline, RepairCandidate
from casper.feature_extraction import FeatureExtractor, StrategyFeatures, FEATURE_DIM
from casper.preference_model import PreferenceConfig, PreferenceModel, SelectionMode
from casper.casper_pipeline import CasperPipeline, CommandOutcome, PipelineResult, ScoredCandidate
from casper.llm_interface import LLMBackend, LLMResponse

__all__ = [
    "CasperPipeline",
    "SafetyPipeline",
    "PreferenceModel",
    "FeatureExtractor",
    "SafetyConfig",
    "PreferenceConfig",
    "SafetyResult",
    "SelectionMode",
    "CommandOutcome",
    "PipelineResult",
    "ScoredCandidate",
    "RepairCandidate",
    "StrategyFeatures",
    "HarmDimension",
    "LLMBackend",
    "LLMResponse",
    "FEATURE_DIM",
]
