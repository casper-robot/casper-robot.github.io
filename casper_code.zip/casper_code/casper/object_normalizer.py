"""
Object Normalizer — Scene-Grounded Object Resolution.

Maps natural language noun phrases to scene inventory entries.

Also resolves type-level names to instance-level objectIds for
grounded execution.
"""

from __future__ import annotations

from typing import Optional

from casper.llm_interface import LLMBackend


HOUSEHOLD_ALIASES = {
    "cup": "mug", "rag": "cloth", "wipes": "cleaning wipes",
    "blade": "knife", "pot": "cooking pot", "pan": "frying pan",
    "couch": "sofa", "tv": "television", "fridge": "refrigerator",
    "tissues": "tissue box", "bin": "trash can",
    "rubbish bin": "trash can", "stove": "stove burner",
}

_STOP_WORDS = {
    "the", "a", "an", "to", "on", "in", "for", "with", "and",
    "put", "place", "give", "move", "take", "get", "make",
    "it", "them", "this", "that", "some", "all", "into",
}


class ObjectNormalizer:
    """Resolve natural language object references against a scene inventory."""

    def __init__(
        self,
        scene_inventory: list[str],
        llm: LLMBackend | None = None,
    ):
        self.inventory = {obj.lower().strip() for obj in scene_inventory}
        self.llm = llm

    def normalize(self, noun_phrase: str) -> str | None:
        """Map a noun phrase to a scene inventory entry, or None if not found."""
        phrase = noun_phrase.lower().strip()
        if phrase in self.inventory:
            return phrase
        canonical = HOUSEHOLD_ALIASES.get(phrase, phrase)
        if canonical in self.inventory:
            return canonical
        for obj in self.inventory:
            if obj in phrase or phrase in obj:
                return obj
        return None

    def resolve_to_instance(
        self,
        noun_phrase: str,
        instances: list[dict],
    ) -> str | None:
        """Resolve a noun phrase to a scene objectId."""
        phrase = noun_phrase.lower().strip()
        canonical = HOUSEHOLD_ALIASES.get(phrase, phrase)
        for inst in instances:
            obj_type = inst.get("objectType", "").lower()
            if obj_type == canonical or obj_type == phrase:
                return inst.get("objectId")
        for inst in instances:
            obj_type = inst.get("objectType", "").lower()
            if canonical in obj_type or obj_type in canonical:
                return inst.get("objectId")
        return None

    def check_feasibility(self, command: str) -> tuple[bool, str]:
        """Check if all objects in a command exist in the scene inventory."""
        objects = self._extract_objects(command)
        missing = [obj for obj in objects if self.normalize(obj) is None]
        if missing:
            return False, f"Objects not in scene: {missing}"
        return True, ""

    def _extract_objects(self, command: str) -> list[str]:
        """Extract candidate object nouns from a command string."""
        words = command.lower().split()
        return [w for w in words if w not in _STOP_WORDS and len(w) > 2]
