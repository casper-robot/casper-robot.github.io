"""
CASPER LLM Interface — Model-Agnostic Abstraction

Abstract base class for any LLM backend. The safety pipeline calls
this interface; it never knows which model is behind it.

Includes:
- Abstract LLMBackend base class
- MockLLMBackend for deterministic testing
- Response parsing utilities
"""

from __future__ import annotations
import json
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


# Response Container

@dataclass
class LLMResponse:
    """Parsed response from any LLM backend."""
    raw_text: str
    parsed: dict[str, Any] | None = None
    parse_error: str | None = None
    model: str = "unknown"
    temperature: float = 0.0

    @property
    def success(self) -> bool:
        return self.parsed is not None and self.parse_error is None


# Abstract Backend

class LLMBackend(ABC):
    """
    Abstract LLM backend. Any model that can take a prompt and return
    text can implement this interface.
    """

    @abstractmethod
    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        """Send prompt to LLM, return raw text response."""
        ...

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Human-readable model identifier."""
        ...

    @property
    def supports_vision(self) -> bool:
        """Whether this backend supports image input."""
        return False

    def generate_with_image(
        self,
        prompt: str,
        image: str | bytes,
        temperature: float = 0.7,
    ) -> str:
        """Send prompt + image to a vision-capable LLM, return raw text.

        Args:
            prompt: Text prompt.
            image: Base64-encoded JPEG string or raw JPEG bytes.
            temperature: Sampling temperature.

        Raises:
            NotImplementedError: If the backend does not support vision.
        """
        raise NotImplementedError(
            f"{self.model_name} does not support vision input"
        )

    def generate_parsed(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_retries: int = 2,
    ) -> LLMResponse:
        """
        Generate and parse JSON response with retry on parse failure.

        On parse failure, retries up to max_retries times with slightly
        higher temperature to get a different response. On backend exception,
        returns an LLMResponse with parse_error rather than crashing.
        """
        last_response = None

        for attempt in range(1 + max_retries):
            try:
                # Bump temperature slightly on retries to get variation
                retry_temp = temperature + (attempt * 0.1)
                raw = self.generate(prompt, retry_temp)
                response = parse_json_response(
                    raw, model=self.model_name, temperature=retry_temp,
                )
                if response.success:
                    return response
                last_response = response
            except Exception as e:
                last_response = LLMResponse(
                    raw_text="",
                    parse_error=f"Backend exception (attempt {attempt + 1}): {e}",
                    model=self.model_name,
                    temperature=temperature,
                )

        # All retries exhausted — return last failed response
        return last_response

    @classmethod
    def model_registry(cls) -> dict:
        """Return the full model registry from llm_providers."""
        from casper.llm_providers import MODEL_REGISTRY
        return MODEL_REGISTRY


# Provider Utilities

def check_available_providers() -> dict[str, bool]:
    """Check which LLM providers have API keys configured."""
    from casper.llm_providers import check_available_providers as _check
    return _check()


# JSON Parsing

def parse_json_response(
    raw_text: str,
    model: str = "unknown",
    temperature: float = 0.0,
) -> LLMResponse:
    """
    Parse a JSON response from an LLM, handling common formatting issues:
    - Markdown code fences (```json ... ```)
    - Leading/trailing whitespace
    - Text before/after the JSON object
    """
    text = raw_text.strip()

    # Strip markdown code fences
    if text.startswith("```"):
        lines = text.split("\n")
        # Remove first line (```json or ```)
        lines = lines[1:]
        # Remove last line if it's ```)
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()

    # Try to find JSON object boundaries
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        text = text[start:end + 1]

    try:
        parsed = json.loads(text)
        return LLMResponse(
            raw_text=raw_text,
            parsed=parsed,
            model=model,
            temperature=temperature,
        )
    except json.JSONDecodeError as e:
        return LLMResponse(
            raw_text=raw_text,
            parse_error=f"JSON parse error: {e}",
            model=model,
            temperature=temperature,
        )


# Mock Backend for Testing

class MockLLMBackend(LLMBackend):

    def __init__(self, responses: dict[str, Any] | None = None, seed: int = 42):
        self._responses = responses or {}
        self._rng = random.Random(seed)
        self._call_count = 0

    @property
    def model_name(self) -> str:
        return "mock"

    def set_response(self, key: str, response: dict) -> None:
        """Set a canned response for a given key."""
        self._responses[key] = response

    def generate(self, prompt: str, temperature: float = 0.7) -> str:

        self._call_count += 1

        # Check for keyword matches in the prompt
        for key, response in self._responses.items():
            if key.lower() in prompt.lower():
                if isinstance(response, dict):
                    return json.dumps(response)
                return str(response)

        # Default: return a safe/no-concern response
        if "ENTITIES" in prompt or "entities" in prompt.lower():
            # Graph construction prompt — return minimal graph
            return json.dumps({
                "entities": [],
                "relationships": [],
            })
        else:
            # Dimension prompt — return no concern
            return json.dumps({
                "concern": False,
                "reasoning": "No specific harm identified in this dimension.",
                "severity": "none",
                "specific_harm": "none",
            })


# Scenario-Aware Mock Backend

class ScenarioMockBackend(LLMBackend):

    def __init__(self, seed: int = 42):
        self._scenarios: dict[str, dict] = {}
        self._keyword_responses: dict[str, dict] = {}  # Fallback for non-scenario prompts
        self._rng = random.Random(seed)
        self._call_count = 0

    @property
    def model_name(self) -> str:
        return "scenario_mock"

    def set_response(self, keyword: str, response: dict) -> None:
        """Set a keyword-based fallback response (used after scenario matching fails)."""
        self._keyword_responses[keyword] = response

    def register_scenario(
        self,
        scenario_key: str,
        graph_response: dict,
        dimension_responses: dict[int, dict],
        repair_response: dict | None = None,
    ) -> None:
        self._scenarios[scenario_key] = {
            "graph": graph_response,
            "dimensions": dimension_responses,
            "repairs": repair_response,
        }

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        self._call_count += 1
        prompt_lower = prompt.lower()

        # Find matching scenario — prefer longest (most specific) key match
        scenario = None
        best_key_len = 0
        for key, sc in self._scenarios.items():
            if key.lower() in prompt_lower and len(key) > best_key_len:
                scenario = sc
                best_key_len = len(key)

        if scenario is None:
            # No scenario match — check keyword fallbacks
            for keyword, resp in self._keyword_responses.items():
                if keyword.lower() in prompt_lower:
                    return json.dumps(resp)
            # No keyword match either — return defaults
            if "entities" in prompt_lower and "relationships" in prompt_lower:
                return json.dumps({"entities": [], "relationships": []})
            return json.dumps({
                "concern": False,
                "reasoning": "No scenario match; default safe.",
                "severity": "none",
                "specific_harm": "none",
            })

        # Determine prompt type
        if "identify all entities" in prompt_lower or ("entities" in prompt_lower and "relationships" in prompt_lower and "interaction graph" not in prompt_lower):
            return json.dumps(scenario["graph"])

        # Check which dimension prompt this is
        dimension_markers = {
            1: "direct interaction harm",
            2: "resulting state harm",
            3: "barrier removal harm",
            4: "foreseeable chain harm",
            5: "value and property harm",
            6: "normative violation",
        }

        for dim_num, marker in dimension_markers.items():
            if marker in prompt_lower:
                if dim_num in scenario["dimensions"]:
                    resp = scenario["dimensions"][dim_num].copy()
                    # Add slight variation based on temperature for consensus testing
                    if temperature > 0.5 and self._rng.random() < 0.15:
                        resp["concern"] = not resp["concern"]
                        resp["reasoning"] += " [Note: assessment varied due to uncertainty]"
                    return json.dumps(resp)

        # Repair generation
        if "generate" in prompt_lower and ("repair" in prompt_lower or "candidate" in prompt_lower):
            if scenario.get("repairs"):
                return json.dumps(scenario["repairs"])

        # Check keyword fallback responses
        for keyword, resp in self._keyword_responses.items():
            if keyword.lower() in prompt_lower:
                return json.dumps(resp)

        # Fallback
        return json.dumps({
            "concern": False,
            "reasoning": "Prompt type not recognized; default safe.",
            "severity": "none",
            "specific_harm": "none",
        })
