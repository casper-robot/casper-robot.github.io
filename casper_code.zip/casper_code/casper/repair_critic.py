"""
Repair Critic — Internal quality scoring before validation gates.

"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from casper.safety_pipeline import RepairCandidate
from casper.task_frame import TaskFrame
from casper.repair_grounding import RepairGroundingPack

logger = logging.getLogger(__name__)


@dataclass
class CritiqueResult:
    """Result of critiquing a single repair candidate."""
    passes: bool
    score: float
    reasons: list[str] = field(default_factory=list)


def critique_candidate(
    candidate: RepairCandidate,
    original_frame: TaskFrame,
    diagnosis,
    grounding: RepairGroundingPack,
) -> CritiqueResult:
    score = 1.0
    reasons = []
    hazard_lower = {e.lower() for e in diagnosis.hazardous_entities}
    entities_lower = {e.lower() for e in grounding.scene_entities}

    # 1. Did it modify at least one diagnosed intervention point?
    if diagnosis.candidate_intervention_points:
        cmd_lower = candidate.command.lower()
        modified_any = False
        for point in diagnosis.candidate_intervention_points:
            # Check if the intervention point entity is changed
            if point.startswith("object:"):
                entity = point.split(":", 1)[1].lower()
                if entity not in cmd_lower:
                    modified_any = True
                    break
            elif point.startswith("relation:"):
                modified_any = True
                break
        if not modified_any:
            score -= 0.3
            reasons.append("does not modify any diagnosed intervention point")

    # 2. Did it preserve protected slots?
    if "action" in diagnosis.preserve_slots:
        if original_frame.action.lower() not in candidate.command.lower():
            # Action changed — minor deduction (sometimes necessary)
            score -= 0.1
            reasons.append("original action not preserved")

    # 3. Is the plan grounded?
    ungrounded = 0
    for action in candidate.action_plan:
        if action.obj and action.obj.lower() not in entities_lower:
            ungrounded += 1
        if action.receptacle and action.receptacle.lower() not in entities_lower:
            ungrounded += 1
    if ungrounded > 0:
        score -= 0.2 * ungrounded
        reasons.append(f"{ungrounded} ungrounded binding(s)")

    # 4. Is the plan non-empty and plausible?
    if not candidate.action_plan:
        score -= 0.2
        reasons.append("no action plan")
    elif len(candidate.action_plan) > 8:
        score -= 0.1
        reasons.append("plan is unusually long")

    # 5. Is the explanation non-empty?
    if not candidate.explanation or len(candidate.explanation) < 10:
        score -= 0.1
        reasons.append("weak or missing explanation")

    # 6. Does the repair still reference the hazardous entity unchanged?
    if candidate.action_plan:
        plan_objects = {a.obj.lower() for a in candidate.action_plan if a.obj}
        still_hazardous = plan_objects & hazard_lower
        original_objects = {o.lower() for o in original_frame.objects}
        if still_hazardous and still_hazardous == (original_objects & hazard_lower):
            # Same hazardous object used in same way — may not have fixed anything
            score -= 0.15
            reasons.append("hazardous entity still used unchanged in plan")

    score = max(0.0, min(1.0, score))
    passes = score >= 0.4

    return CritiqueResult(passes=passes, score=score, reasons=reasons)


def critique_and_rank(
    candidates: list[RepairCandidate],
    original_frame: TaskFrame,
    diagnosis,
    grounding: RepairGroundingPack,
) -> list[RepairCandidate]:
    """Critique all candidates, reject failures, rank by score."""
    scored = []
    for c in candidates:
        result = critique_candidate(c, original_frame, diagnosis, grounding)
        if result.passes:
            scored.append((c, result.score))
        else:
            logger.info(
                f"Critic rejected '{c.command[:40]}...' "
                f"(score={result.score:.2f}, reasons={result.reasons})"
            )

    scored.sort(key=lambda x: x[1], reverse=True)
    kept = [c for c, _ in scored]

    rejected = len(candidates) - len(kept)
    if rejected:
        logger.info(f"Critic: {rejected}/{len(candidates)} candidates rejected")

    return kept
