"""
CASPER VLM Scene Perception
============================

Vision-Language Model perception module that extracts Scene objects
from images using Endsley's Situation Awareness framework (1995).

Three-level perception pipeline based on Endsley's SA framework:
  Level 1 (Perception):  Identify objects, people, spatial layout
  Level 2 (Comprehension): Infer object properties, hazards, affordances
  Level 3 (Projection):  Anticipate safety-relevant interactions

Converts VLM output directly to CASPER's Scene/SceneObject types
for use in the safety pipeline.
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from casper.llm_interface import LLMBackend
from casper.scene_provider import Scene, SceneObject, _categorize_object, _OBJECT_PROPERTIES

logger = logging.getLogger(__name__)

SCENE_PERCEPTION_PROMPT = """\
You are a robot perception system applying Situation Awareness analysis \
(Endsley, 1995) to understand a domestic environment at three levels.

{context_hint}

**Level 1 — PERCEPTION**: Identify every distinct object and person visible.
For objects: determine physical properties relevant to robot manipulation \
and safety — temperature state (hot/warm/cold), sharpness, weight class, \
fragility, functional state (on/off, open/closed, full/empty), whether \
it is pickupable, whether it is a receptacle/surface, and hazard type.
For people: estimate age group, note current activity, assess safety awareness.

**Level 2 — COMPREHENSION**: Describe what is HAPPENING in this scene. \
Do not just list objects — synthesize them into a situational understanding. \
What activity or routine is in progress? What is the overall safety state? \
Are there existing tensions or risks independent of any specific task?

**Level 3 — PROJECTION**: Identify spatial relationships between entities \
that are relevant to safety. Which objects are on, near, or inside other \
objects? Which objects are within reach of people? Note any safety-relevant \
proximity (e.g., sharp object near edge, hot appliance near child).

Return a JSON object with this exact structure:
{{
  "objects": [
    {{
      "name": "ObjectType",
      "category": "utensil|container|food|appliance|fixture|lighting|plumbing|person|object",
      "properties": {{
        "pickupable": true/false,
        "openable": true/false,
        "toggleable": true/false,
        "breakable": true/false,
        "sliceable": true/false,
        "sharp": true/false,
        "hot_when_on": true/false,
        "receptacle": true/false,
        "hazard": "burn|cut|choking|poisoning|drowning|fall|poke|null",
        "state": "on|off|open|closed|full|empty|null",
        "child_safe": true/false,
        "material": "metal|glass|plastic|wood|ceramic|fabric|null"
      }},
      "position": "brief spatial description (e.g., on counter edge, inside cabinet)"
    }}
  ],
  "edges": [
    {{
      "source": "ObjectA",
      "target": "ObjectB",
      "relation": "on|near|inside|adjacent_to|within_reach_of",
      "safety_relevant": true/false
    }}
  ],
  "room_type": "Kitchen|Living Room|Bedroom|Bathroom|Room",
  "scene_summary": "One-sentence factual description of the scene.",
  "situation_description": "2-3 sentences describing what is happening in the scene.",
  "safety_notes": "Any projected safety concerns from Level 3 analysis."
}}

Rules:
- Use PascalCase names (e.g., "ButterKnife", "StoveBurner", "CoffeeMachine")
- One entry per object TYPE (don't duplicate if there are two apples)
- Set hazard to null if the object poses no obvious hazard
- Include people visible in the scene as objects with category "person"
- Include spatial edges between objects that are safety-relevant
- Only output the JSON, no other text
"""


def perceive_scene(
    backend: LLMBackend,
    image: str | bytes,
    context_hint: str = "",
    temperature: float = 0.3,
) -> Scene:
    """
    Perceive a scene from an image using a vision-capable LLM.

    Parameters
    ----------
    backend : LLMBackend
        A vision-capable LLM backend (must support generate_with_image).
    image : str or bytes
        Base64-encoded JPEG string or raw JPEG bytes.
    context_hint : str
        Optional hint about the environment (e.g., "This is a kitchen").
    temperature : float
        Sampling temperature (low for consistency).

    Returns
    -------
    Scene
        CASPER Scene with objects extracted from the image.

    Raises
    ------
    NotImplementedError
        If the backend does not support vision.
    """
    if not backend.supports_vision:
        raise NotImplementedError(
            f"{backend.model_name} does not support vision. "
            f"Use a vision-capable model (GPT-4o, Claude Sonnet, Gemini)."
        )

    hint_text = f"Context: {context_hint}" if context_hint else ""
    prompt = SCENE_PERCEPTION_PROMPT.format(context_hint=hint_text)

    raw = backend.generate_with_image(prompt, image, temperature=temperature)
    return _parse_vlm_response(raw, model=backend.model_name)


def _parse_vlm_response(raw_text: str, model: str = "unknown") -> Scene:
    """Parse VLM JSON response into a CASPER Scene."""
    text = raw_text.strip()

    if text.startswith("```"):
        lines = text.split("\n")
        lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()

    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        text = text[start:end + 1]

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        logger.error(f"VLM response parse failed: {e}\nRaw: {raw_text[:500]}")
        return Scene(
            scene_id="vlm_unknown",
            room_type="Room",
            objects=[],
            source="vlm",
            description=f"VLM parse error: {e}",
        )

    room_type = data.get("room_type", "Room")
    summary = data.get("scene_summary", "")
    safety_notes = data.get("safety_notes", "")

    objects = []
    for obj_data in data.get("objects", []):
        name = obj_data.get("name", "Unknown")
        category = obj_data.get("category", _categorize_object(name))
        props = obj_data.get("properties", {})

        clean_props = {}
        for key in ("pickupable", "openable", "toggleable", "breakable",
                     "sliceable", "sharp", "hot_when_on", "receptacle",
                     "child_safe"):
            if props.get(key):
                clean_props[key] = True

        # Preserve string/enum properties
        for key in ("state", "material"):
            val = props.get(key)
            if val and val != "null":
                clean_props[key] = val

        hazard = props.get("hazard")
        if hazard and hazard != "null":
            clean_props["hazard"] = hazard

        # Position from VLM
        position = obj_data.get("position", "")
        if position:
            clean_props["position"] = position

        known = _OBJECT_PROPERTIES.get(name, {})
        for key, val in known.items():
            if key not in clean_props:
                clean_props[key] = val

        objects.append(SceneObject(
            name=name,
            category=category,
            properties=clean_props,
        ))

    # Build description from all Endsley levels
    description_parts = []
    if summary:
        description_parts.append(summary)
    situation = data.get("situation_description", "")
    if situation:
        description_parts.append(f"Situation: {situation}")
    if safety_notes:
        description_parts.append(f"Safety: {safety_notes}")
    description = " ".join(description_parts)

    scene = Scene(
        scene_id=f"vlm_{model}",
        room_type=room_type,
        objects=sorted(objects, key=lambda o: o.name),
        source="vlm",
        description=description,
    )

    # Store VLM edges as extra data for the adapter to use
    scene._vlm_edges = data.get("edges", [])

    return scene
