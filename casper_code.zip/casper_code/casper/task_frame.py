"""
TaskFrame — Structured task representation for repair generation.

A compact internal representation of the task that the repair generator
edits instead of working directly on raw command text. It is an internal substrate used inside 
the existing Repair Generation module.

Distinct from ObjectiveFrame: TaskFrame feeds generation (what to edit),
ObjectiveFrame feeds scoring (how well was task objective preserved).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from casper.safety_kernel import InteractionGraph

_PLACEMENT_VERBS = {"put", "place", "set", "move", "push", "slide", "drop"}
_TRANSFER_VERBS = {"give", "hand", "pass", "deliver", "bring", "serve"}
_REMOVAL_VERBS = {"remove", "take", "clear", "pick"}
_ACTIVATION_VERBS = {"turn", "turn_on", "turn_off", "light", "toggle", "start"}
_MANIPULATION_VERBS = {"slice", "cut", "break", "open", "close", "fill", "pour", "dirty"}

_PREP_TARGET = {"on", "onto", "to", "into", "in", "inside", "near", "next"}
_PREP_SOURCE = {"from", "off", "out"}

_PERSON_INDICATORS = {
    "child", "kid", "toddler", "baby", "infant",
    "adult", "parent", "person", "user", "chef",
}


@dataclass
class TaskFrame:
    """Structured decomposition of a task command for repair editing."""
    action: str
    objects: list[str] = field(default_factory=list)
    source_locations: list[str] = field(default_factory=list)
    target_locations: list[str] = field(default_factory=list)
    recipient: str | None = None
    constraints: list[str] = field(default_factory=list)
    ordering: list[str] = field(default_factory=list)
    manner: str | None = None
    required_skills: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = {
            "action": self.action,
            "objects": self.objects,
            "target_locations": self.target_locations,
        }
        if self.source_locations:
            d["source_locations"] = self.source_locations
        if self.recipient:
            d["recipient"] = self.recipient
        if self.constraints:
            d["constraints"] = self.constraints
        if self.ordering:
            d["ordering"] = self.ordering
        if self.manner:
            d["manner"] = self.manner
        if self.required_skills:
            d["required_skills"] = self.required_skills
        return d

    def to_prompt_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    def copy(self) -> TaskFrame:
        """Return a shallow copy for editing."""
        import copy
        return copy.copy(self)


@dataclass
class PlanSkeleton:
    """Executable plan derived from an edited TaskFrame."""
    steps: list[dict] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    bindings: dict[str, str] = field(default_factory=dict)

    def to_action_plan(self):
        """Convert to list of CanonicalAction."""
        from casper.action_ir import CanonicalAction
        actions = []
        for step in self.steps:
            actions.append(CanonicalAction(
                verb=step.get("verb", ""),
                obj=step.get("obj", ""),
                receptacle=step.get("receptacle", ""),
            ))
        return actions


def apply_repair_operator(
    frame: TaskFrame,
    diagnosis,
    operator: str,
    grounding,
) -> TaskFrame | None:
    """Apply a repair operator to produce an edited TaskFrame.

    Returns the edited frame, or None if the operator is not applicable.
    Deterministic — no LLM calls.
    """
    edited = frame.copy()
    hazard_lower = {e.lower() for e in diagnosis.hazardous_entities}

    if operator == "substitution":
        for i, obj in enumerate(edited.objects):
            if obj.lower() in hazard_lower:
                for alt in grounding.movable_objects:
                    if alt.lower() not in hazard_lower and alt.lower() != obj.lower():
                        edited.objects = list(edited.objects)
                        edited.objects[i] = alt
                        return edited
        return None

    elif operator == "relocation":
        current_targets = {t.lower() for t in edited.target_locations}
        for recep in grounding.safe_receptacles:
            if recep.lower() not in current_targets and recep.lower() not in hazard_lower:
                edited.target_locations = [recep]
                return edited
        return None

    elif operator == "separation":
        for recep in grounding.safe_receptacles:
            if recep.lower() not in hazard_lower:
                edited.constraints = list(edited.constraints)
                edited.constraints.append(
                    f"keep hazardous items separated on {recep}"
                )
                return edited
        return None

    elif operator == "barrier":
        barriers = [
            r for r in grounding.safe_receptacles
            if r.lower() not in {o.lower() for o in edited.objects}
        ]
        if barriers:
            edited.constraints = list(edited.constraints)
            edited.constraints.append(f"use {barriers[0]} as containment")
            return edited
        return None

    elif operator == "constraint_tighten":
        edited.constraints = list(edited.constraints)
        if edited.manner:
            edited.constraints.append(f"handle {edited.manner}")
        edited.constraints.append("verify placement is stable and safe")
        return edited

    elif operator == "recipient_change":
        if grounding.allowed_recipients:
            edited.recipient = grounding.allowed_recipients[0]
            return edited
        return None

    return None


def derive_plan_skeleton(
    original_frame: TaskFrame,
    edited_frame: TaskFrame,
    grounding,
) -> PlanSkeleton:
    """Build a concrete execution plan from original and edited frames."""
    steps = []
    bindings = {}

    for obj in edited_frame.objects:
        steps.append({"verb": "pick", "obj": obj, "receptacle": ""})
        bindings[f"object_{len(bindings)}"] = obj

        target = ""
        if edited_frame.target_locations:
            target = edited_frame.target_locations[0]
        elif grounding.safe_receptacles:
            target = grounding.safe_receptacles[0]

        if target:
            steps.append({"verb": "place", "obj": obj, "receptacle": target})
            bindings[f"target_{len(bindings)}"] = target

    skills = list(set(s.get("verb", "") for s in steps))

    return PlanSkeleton(steps=steps, skills=skills, bindings=bindings)


def derive_expected_end_state(
    edited_frame: TaskFrame,
    skeleton: PlanSkeleton,
) -> str:
    """Produce expected postcondition summary from edited frame and plan."""
    parts = []
    for step in skeleton.steps:
        if step.get("verb") == "place" and step.get("obj") and step.get("receptacle"):
            parts.append(f"{step['obj']} is on {step['receptacle']}")
    if edited_frame.constraints:
        parts.extend(edited_frame.constraints)
    return "; ".join(parts) if parts else "task completed safely"


def verbalize_repair(
    edited_frame: TaskFrame,
    skeleton: PlanSkeleton,
) -> str:
    """Render repaired command text from structured edited frame."""
    parts = [edited_frame.action]

    if edited_frame.objects:
        parts.append(" ".join(edited_frame.objects))

    if edited_frame.target_locations:
        parts.append("to " + edited_frame.target_locations[0])

    if edited_frame.recipient:
        parts.append("for " + edited_frame.recipient)

    if edited_frame.manner:
        parts.insert(1, edited_frame.manner)

    return " ".join(parts)


def build_task_frame(
    command: str,
    scene_context: str = "",
    interaction_graph: InteractionGraph | None = None,
) -> TaskFrame:
    """Derive a TaskFrame from command text and scene artifacts.

    Deterministic extraction — no LLM calls. Uses simple token parsing
    with preposition-based role assignment.
    """
    tokens = command.lower().split()
    if not tokens:
        return TaskFrame(action="unknown")

    # Extract action verb
    action = tokens[0]
    if len(tokens) > 1 and tokens[0] in ("turn", "pick") and tokens[1] in ("on", "off", "up"):
        action = f"{tokens[0]}_{tokens[1]}"

    # Extract entities from interaction graph if available
    graph_entities = set()
    if interaction_graph:
        for e in interaction_graph.entities:
            graph_entities.add(e.name.lower())

    # Parse objects, targets, sources from command
    objects = []
    target_locations = []
    source_locations = []
    recipient = None
    manner = None

    # Manner qualifiers
    manner_words = {"gently", "carefully", "slowly", "quickly", "safely", "securely"}
    found_manner = [t for t in tokens if t in manner_words]
    if found_manner:
        manner = found_manner[0]

    # Walk tokens to find prepositional roles
    i = 1
    current_role = "object"
    while i < len(tokens):
        token = tokens[i]

        if token in _PREP_TARGET:
            current_role = "target"
            i += 1
            continue
        elif token in _PREP_SOURCE:
            current_role = "source"
            i += 1
            continue
        elif token in ("and", "then", ","):
            i += 1
            continue
        elif token in manner_words:
            i += 1
            continue
        elif token in ("the", "a", "an"):
            i += 1
            continue

        # Check for person indicators
        if token in _PERSON_INDICATORS:
            recipient = token
            i += 1
            continue

        # Use graph entity name if available, otherwise raw token
        resolved = token
        if graph_entities:
            for ge in graph_entities:
                if ge in token or token in ge:
                    resolved = ge
                    break

        if current_role == "object":
            objects.append(resolved)
        elif current_role == "target":
            target_locations.append(resolved)
        elif current_role == "source":
            source_locations.append(token)

        i += 1

    # Derive required skills from action
    skills = []
    if action in _PLACEMENT_VERBS or action == "put":
        skills.extend(["pick", "place"])
    elif action in _TRANSFER_VERBS:
        skills.extend(["pick", "place"])
    elif action in _REMOVAL_VERBS:
        skills.append("pick")
    elif action in _ACTIVATION_VERBS:
        skills.append("toggle")
    elif action in _MANIPULATION_VERBS:
        skills.append(action)
    else:
        skills.append(action)

    return TaskFrame(
        action=action,
        objects=objects,
        source_locations=source_locations,
        target_locations=target_locations,
        recipient=recipient,
        manner=manner,
        required_skills=skills,
    )
