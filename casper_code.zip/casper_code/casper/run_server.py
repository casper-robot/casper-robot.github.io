"""
CASPER Web Server Entry Point
================================

Starts the Flask web interface for interactive command processing.

Usage:
    python casper/run_server.py
    python casper/run_server.py --port 8080 --no-browser --debug
    python casper/run_server.py --model gpt-4o
"""

from __future__ import annotations

import argparse
import logging
import sys
import webbrowser

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("casper.server")


def main():
    parser = argparse.ArgumentParser(description="CASPER Web Interface")
    parser.add_argument("--port", type=int, default=5000, help="Port to serve on")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--no-browser", action="store_true", help="Don't auto-open browser")
    parser.add_argument("--debug", action="store_true", help="Enable Flask debug mode")
    parser.add_argument("--model", default=None, help="Initial LLM model (e.g., gpt-4o)")
    parser.add_argument("--provider", default=None, help="LLM provider (auto-detected if model given)")
    parser.add_argument(
        "--repair-mode", default="structured_operator",
        choices=["structured_operator", "legacy"],
        help="Repair generation mode (default: structured_operator)",
    )
    args = parser.parse_args()

    from casper.interface.app import create_app

    app = create_app()
    app.config["REPAIR_MODE"] = args.repair_mode
    if args.repair_mode == "structured_operator":
        logger.info("Repair mode: structured_operator (operator-conditioned generation)")

    if args.model or args.provider:
        provider = args.provider or "openai"
        model = args.model or "gpt-4o"
        app.config["DEFAULT_PROVIDER"] = provider
        app.config["DEFAULT_MODEL"] = model
        logger.info(f"Default LLM: provider={provider}, model={model}")
    else:
        try:
            from casper.llm_providers import check_available_providers
            available = check_available_providers()
            provider_defaults = {
                "openai": "gpt-4o",
                "anthropic": "claude-sonnet-4-6",
                "google": "gemini-2.0-flash",
            }
            for provider_name in ["openai", "anthropic", "google"]:
                if available.get(provider_name):
                    app.config["DEFAULT_PROVIDER"] = provider_name
                    app.config["DEFAULT_MODEL"] = provider_defaults[provider_name]
                    logger.info(f"Auto-detected provider: {provider_name}")
                    break
            else:
                logger.info("No API keys found. Start with --model or set env vars.")
        except Exception as e:
            logger.info(f"Auto-detect failed: {e}. Server starting without LLM.")

    url = f"http://{args.host}:{args.port}"
    if not args.no_browser:
        webbrowser.open(url)
        logger.info(f"Opening browser at {url}")

    logger.info(f"CASPER server starting on {url}")
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
