"""
CASPER Strategy Feature Extraction

Extracts a 10-dimensional feature vector φ(c, c') from an (original, repair) pair.
Features describe HOW a repair was performed, not WHAT specific task was repaired.

Canonical configuration:
    φ₁: Modification degree         [0, 1]  — deterministic (Levenshtein)
    φ₂: Object preservation          [0, 1]  — deterministic (entity set overlap)
    φ₃: Parameter modification       [0, 1]  — deterministic (token diff + synonyms)
    φ₄: Safety margin                [0, 1]  — from SafetyResult (Gate 3)
    φ₅: Structural preservation      [0, 1]  — LLM (semantic judgment)
    φ₆: Recipient interaction change [0, 1]  — LLM (semantic judgment)
    φ₇: Plan length (normalized)     [0, 1]  — deterministic (from action plan)
    φ₈: Navigation required          {0, 1}  — deterministic (from action plan)
    φ₉: Container manipulation       {0, 1}  — deterministic (from action plan)
    φ₁₀: Handled object set change   [0, 1]  — deterministic (Jaccard distance)

Two extractors:
    FeatureExtractor      — original (φ₂,₃,₅,₆ via LLM). Kept for backward compat.
    DeterministicFeatureExtractor — canonical (φ₁–₃ deterministic, φ₅–₆ LLM, φ₇–₁₀ deterministic).
"""

from __future__ import annotations
import logging
from dataclasses import dataclass
import numpy as np

from casper.llm_interface import LLMBackend

logger = logging.getLogger(__name__)

FEATURE_DIM = 10


# Deterministic φ₁: Normalized Levenshtein Distance

def _levenshtein_distance(s1: str, s2: str) -> int:
    """Standard Levenshtein edit distance via dynamic programming."""
    if len(s1) < len(s2):
        return _levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)

    prev_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        curr_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = prev_row[j + 1] + 1
            deletions = curr_row[j] + 1
            substitutions = prev_row[j] + (c1 != c2)
            curr_row.append(min(insertions, deletions, substitutions))
        prev_row = curr_row

    return prev_row[-1]


def normalized_levenshtein(s1: str, s2: str) -> float:
    s1_norm = s1.strip().lower()
    s2_norm = s2.strip().lower()
    if s1_norm == s2_norm:
        return 0.0
    max_len = max(len(s1_norm), len(s2_norm))
    if max_len == 0:
        return 0.0
    return _levenshtein_distance(s1_norm, s2_norm) / max_len

# Deterministic φ₂: Entity Set Overlap

def entity_overlap(original_entities: set[str], repair_entities: set[str]) -> float:
    if not original_entities:
        return 1.0
    orig_lower = {e.lower().strip() for e in original_entities}
    repair_lower = {e.lower().strip() for e in repair_entities}
    return len(orig_lower & repair_lower) / len(orig_lower)


# Deterministic φ₃: Token Diff Ratio + Synonym Map

SYNONYM_MAP = {
    "cut": "slice", "chop": "slice",
    "put": "place", "set": "place",
    "grab": "pick", "take": "pick",
    "give": "hand", "pass": "hand",
    "mug": "cup", "rag": "cloth",
    "couch": "sofa", "tv": "television",
    "fridge": "refrigerator", "bin": "trash",
    "stove": "burner", "pot": "pan",
}


def _normalize_tokens(text: str) -> set[str]:
    """Tokenize and normalize through synonym map."""
    tokens = set(text.lower().split())
    return {SYNONYM_MAP.get(t, t) for t in tokens}


def token_diff_ratio(original: str, repair: str) -> float:
    orig_tokens = _normalize_tokens(original)
    repair_tokens = _normalize_tokens(repair)
    if not orig_tokens:
        return 0.0
    shared = orig_tokens & repair_tokens
    return 1.0 - (len(shared) / len(orig_tokens))


FEATURE_NAMES = [
    "modification_degree",           # φ₁
    "object_preservation",           # φ₂
    "parameter_modification",        # φ₃
    "safety_margin",                 # φ₄
    "structural_preservation",       # φ₅
    "recipient_interaction_change",  # φ₆
    "plan_length",                   # φ₇  (plan-derived)
    "navigation_required",           # φ₈  (plan-derived)
    "container_manipulation",        # φ₉  (plan-derived)
    "handled_object_set_change",     # φ₁₀ (plan-derived)
]


# Feature Extraction Prompt

NAVIGATION_VERBS = {'find', 'move_to'}
CONTAINER_VERBS = {'put', 'open', 'close'}
MAX_PLAN_LENGTH = 10


def plan_length_normalized(action_plan: list) -> float:
    """φ₇: Normalized plan step count ∈ [0, 1]. More steps = higher burden."""
    if not action_plan:
        return 0.0
    return min(len(action_plan) / MAX_PLAN_LENGTH, 1.0)


def navigation_required(action_plan: list) -> float:
    """φ₈: 1.0 if the plan includes navigation verbs, 0.0 otherwise."""
    if not action_plan:
        return 0.0
    return 1.0 if any(a.verb in NAVIGATION_VERBS for a in action_plan) else 0.0


def container_manipulation(action_plan: list) -> float:
    """φ₉: 1.0 if the plan involves container/receptacle actions, 0.0 otherwise."""
    if not action_plan:
        return 0.0
    return 1.0 if any(a.verb in CONTAINER_VERBS for a in action_plan) else 0.0


def handled_object_set_change(
    original_entities: set[str],
    action_plan: list,
) -> float:
    if not action_plan:
        return 0.0

    repair_objects: set[str] = set()
    for a in action_plan:
        if a.obj:
            repair_objects.add(a.obj.lower().strip())
        if a.receptacle:
            repair_objects.add(a.receptacle.lower().strip())

    orig_lower = {e.lower().strip() for e in original_entities} if original_entities else set()

    if not orig_lower and not repair_objects:
        return 0.0

    union = orig_lower | repair_objects
    intersection = orig_lower & repair_objects
    return 1.0 - (len(intersection) / len(union))


FEATURE_EXTRACTION_PROMPT = """\
You are analyzing how a repair command differs from the original command. \
Extract the following features by comparing the original and repaired commands.

ORIGINAL COMMAND: {original_command}
REPAIRED COMMAND: {repair_command}
SCENE CONTEXT: {scene_context}

For each feature, provide a value:

1. object_preservation (0.0 or 1.0): Is the primary object the same?
   - 1.0 = same object (e.g., grapes → quartered grapes)
   - 0.0 = different object (e.g., grapes → banana)

2. parameter_modification (0.0 or 1.0): Were hazardous parameters adjusted?
   - 1.0 = parameters changed (quantity, size, temperature, form, etc.)
   - 0.0 = no parameter change (object was substituted or task restructured instead)

3. structural_preservation (0.0 to 1.0): Was the task structure maintained?
   - 1.0 = same structure (e.g., "give X to Y" → "give X' to Y")
   - 0.5 = partially changed (e.g., added supervision step)
   - 0.0 = completely restructured (e.g., single step → multi-step process)

4. recipient_interaction_change (0.0 to 1.0): Did how the recipient \
interacts with the result change?
   - 0.0 = same interaction (e.g., eating whole food → eating whole food)
   - 0.5 = moderately changed (e.g., self-feeding → supervised feeding)
   - 1.0 = completely different interaction (e.g., eating whole → eating puree)

Respond with ONLY a JSON object:
{{
  "object_preservation": <float>,
  "parameter_modification": <float>,
  "structural_preservation": <float>,
  "recipient_interaction_change": <float>,
  "reasoning": "<brief explanation of your assessment>"
}}"""


# Feature Vector

@dataclass
class StrategyFeatures:
    """A 10-dimensional strategy feature vector with metadata."""
    values: np.ndarray          # Shape (10,)
    original_command: str
    repair_command: str
    reasoning: str = ""         # LLM's explanation

    @property
    def modification_degree(self) -> float:
        return float(self.values[0])

    @property
    def object_preservation(self) -> float:
        return float(self.values[1])

    @property
    def parameter_modification(self) -> float:
        return float(self.values[2])

    @property
    def safety_margin(self) -> float:
        return float(self.values[3])

    @property
    def structural_preservation(self) -> float:
        return float(self.values[4])

    @property
    def recipient_interaction_change(self) -> float:
        return float(self.values[5])

    @property
    def plan_length(self) -> float:
        return float(self.values[6])

    @property
    def navigation_required_flag(self) -> float:
        return float(self.values[7])

    @property
    def container_manipulation_flag(self) -> float:
        return float(self.values[8])

    @property
    def handled_object_change(self) -> float:
        return float(self.values[9])

    def to_dict(self) -> dict:
        return {
            name: float(self.values[i])
            for i, name in enumerate(FEATURE_NAMES)
        }

    def infer_haddon_strategy(self) -> str:
        """
        Infer the most likely Haddon countermeasure from feature pattern.

        Uses a scoring approach against the feature signatures from the
        formulation's Table I, rather than a cascading if-chain that
        would have order-dependent blind spots.
        """
        φ = self.values
        # Each strategy's ideal signature: (feature_index, ideal_value, weight)
        # Based on formulation Table I
        strategy_scores: dict[str, float] = {}

        # H1 Substitute: low φ₂ (new object), high φ₁ (big change)
        strategy_scores["H1"] = (1.0 - φ[1]) * 2.0 + φ[0] * 1.0

        # H2 Reduce: high φ₃ (params changed), high φ₂ (same object), high φ₅ (structure kept)
        strategy_scores["H2"] = φ[2] * 2.0 + φ[1] * 1.0 + φ[4] * 1.0

        # H3 Contain: high φ₆ (interaction changed), moderate φ₁, high φ₂ (same object)
        strategy_scores["H3"] = φ[5] * 1.5 + φ[1] * 1.0 + (1.0 - abs(φ[0] - 0.4)) * 0.5

        # H4 Control rate: low φ₁ (small change), moderate φ₅ change
        strategy_scores["H4"] = (1.0 - φ[0]) * 2.0 + (1.0 - abs(φ[4] - 0.5)) * 1.0

        # H5 Separate: high φ₁ (big change), low φ₅ (structure changed)
        strategy_scores["H5"] = φ[0] * 1.5 + (1.0 - φ[4]) * 1.5

        # H6 Barrier: high φ₆ (interaction changed), high φ₁ moderate
        strategy_scores["H6"] = φ[5] * 2.0 + φ[1] * 0.5 + (1.0 - φ[0]) * 0.5

        # H7 Transform: high φ₂ (same object), low φ₅ (form changed), high φ₆
        strategy_scores["H7"] = φ[1] * 1.5 + (1.0 - φ[4]) * 1.0 + φ[5] * 1.5

        best = max(strategy_scores, key=strategy_scores.get)
        return best

    def __repr__(self) -> str:
        parts = [f"{name}={self.values[i]:.2f}" for i, name in enumerate(FEATURE_NAMES)]
        return f"StrategyFeatures({', '.join(parts)})"


# Feature Extractor

class FeatureExtractor:

    def __init__(self, llm: LLMBackend):
        self.llm = llm

    def extract(
        self,
        original_command: str,
        repair_command: str,
        scene_context: str,
        safety_margin: float = 1.0,
        repair_action_plan: list | None = None,
        original_entities: set[str] | None = None,
    ) -> StrategyFeatures:
        phi_1 = normalized_levenshtein(original_command, repair_command)

        prompt = FEATURE_EXTRACTION_PROMPT.format(
            original_command=original_command,
            repair_command=repair_command,
            scene_context=scene_context,
        )

        response = self.llm.generate_parsed(prompt, temperature=0.2)

        if response.success:
            data = response.parsed
            core = [
                phi_1,
                self._clamp(data.get("object_preservation", 0.5), 0.0, 1.0),
                self._clamp(data.get("parameter_modification", 0.5), 0.0, 1.0),
                safety_margin,
                self._clamp(data.get("structural_preservation", 0.5), 0.0, 1.0),
                self._clamp(data.get("recipient_interaction_change", 0.5), 0.0, 1.0),
            ]
            reasoning = data.get("reasoning", "")
        else:
            logger.warning(
                f"Feature extraction parse failed: {response.parse_error}. "
                f"Using default features for semantic dimensions."
            )
            core = [phi_1, 0.5, 0.5, safety_margin, 0.5, 0.5]
            reasoning = f"Default features (parse failure: {response.parse_error})"

        plan = repair_action_plan or []
        plan_feats = [
            plan_length_normalized(plan),
            navigation_required(plan),
            container_manipulation(plan),
            handled_object_set_change(original_entities or set(), plan),
        ]

        values = np.array(core + plan_feats, dtype=np.float64)

        return StrategyFeatures(
            values=values,
            original_command=original_command,
            repair_command=repair_command,
            reasoning=reasoning,
        )

    def extract_batch(
        self,
        original_command: str,
        repairs: list[str],
        scene_context: str,
        safety_margins: list[float] | None = None,
    ) -> list[StrategyFeatures]:
        """Extract features for multiple repairs against the same original."""
        if safety_margins is None:
            safety_margins = [1.0] * len(repairs)

        return [
            self.extract(original_command, repair, scene_context, sm)
            for repair, sm in zip(repairs, safety_margins)
        ]

    @staticmethod
    def _clamp(val: float, lo: float, hi: float) -> float:
        """Clamp a value to [lo, hi], handling non-numeric gracefully."""
        try:
            v = float(val)
        except (TypeError, ValueError):
            return (lo + hi) / 2.0
        return max(lo, min(hi, v))


# Semantic Feature Prompt (φ₅ and φ₆ only)

SEMANTIC_FEATURE_PROMPT = """\
You are analyzing how a repair command differs from the original command. \
Extract ONLY the following two semantic features.

ORIGINAL COMMAND: {original_command}
REPAIRED COMMAND: {repair_command}
SCENE CONTEXT: {scene_context}

1. structural_preservation (0.0 to 1.0): Was the task structure maintained?
   - 1.0 = same structure (e.g., "give X to Y" → "give X' to Y")
   - 0.5 = partially changed (e.g., added supervision step)
   - 0.0 = completely restructured (e.g., single step → multi-step process)

2. recipient_interaction_change (0.0 to 1.0): Did how the recipient \
interacts with the result change?
   - 0.0 = same interaction (e.g., eating whole food → eating whole food)
   - 0.5 = moderately changed (e.g., self-feeding → supervised feeding)
   - 1.0 = completely different interaction (e.g., eating whole → eating puree)

Respond with ONLY a JSON object:
{{
  "structural_preservation": <float>,
  "recipient_interaction_change": <float>,
  "reasoning": "<brief explanation>"
}}"""


# Canonical Feature Extractor (φ₁–φ₃ deterministic, φ₅–φ₆ LLM)

class DeterministicFeatureExtractor:

    def __init__(self, llm: LLMBackend):
        self._llm = llm

    def extract(
        self,
        original_command: str,
        repair_command: str,
        scene_context: str,
        safety_margin: float,
        original_entities: set[str] | None = None,
        repair_entities: set[str] | None = None,
        repair_action_plan: list | None = None,
    ) -> StrategyFeatures:
        phi1 = normalized_levenshtein(original_command, repair_command)
        phi2 = entity_overlap(
            original_entities or set(), repair_entities or set()
        )
        phi3 = token_diff_ratio(original_command, repair_command)
        phi4 = safety_margin

        phi5, phi6, reasoning = self._extract_semantic(
            original_command, repair_command, scene_context
        )

        plan = repair_action_plan or []
        phi7 = plan_length_normalized(plan)
        phi8 = navigation_required(plan)
        phi9 = container_manipulation(plan)
        phi10 = handled_object_set_change(original_entities or set(), plan)

        values = np.array(
            [phi1, phi2, phi3, phi4, phi5, phi6, phi7, phi8, phi9, phi10],
            dtype=np.float64,
        )

        return StrategyFeatures(
            values=values,
            original_command=original_command,
            repair_command=repair_command,
            reasoning=reasoning,
        )

    def _extract_semantic(
        self,
        original_command: str,
        repair_command: str,
        scene_context: str,
    ) -> tuple[float, float, str]:
        """Extract φ₅ and φ₆ via LLM (1 call)."""
        prompt = SEMANTIC_FEATURE_PROMPT.format(
            original_command=original_command,
            repair_command=repair_command,
            scene_context=scene_context,
        )
        response = self._llm.generate_parsed(prompt, temperature=0.2)

        if response.success:
            data = response.parsed
            phi5 = _clamp(data.get("structural_preservation", 0.5))
            phi6 = _clamp(data.get("recipient_interaction_change", 0.5))
            reasoning = data.get("reasoning", "")
            return phi5, phi6, reasoning

        logger.warning(
            f"Semantic feature extraction failed: {response.parse_error}. "
            f"Using defaults for φ₅, φ₆."
        )
        return 0.5, 0.5, f"Default (parse failure: {response.parse_error})"

    def extract_batch(
        self,
        original_command: str,
        repairs: list[str],
        scene_context: str,
        safety_margins: list[float] | None = None,
        original_entities: set[str] | None = None,
        repair_entities_list: list[set[str]] | None = None,
        repair_action_plans: list[list] | None = None,
    ) -> list[StrategyFeatures]:
        """Extract features for multiple repairs against the same original."""
        if safety_margins is None:
            safety_margins = [1.0] * len(repairs)
        if repair_entities_list is None:
            repair_entities_list = [set()] * len(repairs)
        if repair_action_plans is None:
            repair_action_plans = [[] for _ in repairs]

        return [
            self.extract(
                original_command, repair, scene_context, sm,
                original_entities, repair_ents, plan,
            )
            for repair, sm, repair_ents, plan
            in zip(repairs, safety_margins, repair_entities_list,
                   repair_action_plans)
        ]


def _clamp(val: float, lo: float = 0.0, hi: float = 1.0) -> float:
    """Clamp a value to [lo, hi], handling non-numeric gracefully."""
    try:
        v = float(val)
    except (TypeError, ValueError):
        return (lo + hi) / 2.0
    return max(lo, min(hi, v))


# Baseline Feature Vector (for accept/reject feedback)

def baseline_features() -> np.ndarray:
    """
    The implicit baseline φ₀ representing "do nothing / refuse".

    Used for accept/reject updates: accept means the candidate is
    preferred over doing nothing; reject means doing nothing is preferred.

    φ₀ = [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    - Maximum modification (complete refusal = maximum deviation from intent)
    - No object preservation (task not performed)
    - No parameter modification (nothing to modify)
    - Zero safety margin (refusal has no safety evaluation)
    - No structural preservation (no structure)
    - No interaction change (no interaction)
    - Zero plan length (no plan)
    - No navigation (no action)
    - No container manipulation (no action)
    - No object set change (no action)
    """
    return np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                    dtype=np.float64)
