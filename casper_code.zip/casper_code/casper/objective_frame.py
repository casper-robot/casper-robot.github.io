"""
Repair-Aligned Objective Frame  κ = ⟨g, E, R, X, V, A, Π⟩

Lightweight structured representation for safe objective repair.
Makes task objective preservation explicit and measurable.

The frame is a control and comparison layer, not a reasoning engine.
It is assembled from existing pipeline artifacts (interaction graph,
hazard diagnosis, action plans, scene context) via deterministic
construction utilities:

    build_objective_frame()   — original command → ObjectiveFrame
    derive_repaired_frame()   — original frame + candidate → ObjectiveFrame

"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from casper.action_ir import CanonicalAction


# Frame Components

@dataclass
class GoalIntent:
    """Compact goal-state abstraction: what world change the user wants."""
    verb: str
    target_object: Optional[str] = None
    recipient: Optional[str] = None
    purpose: str = ""

    def matches(self, other: GoalIntent) -> bool:
        """Check if two goal intents share the same core objective."""
        if self.verb.lower() != other.verb.lower():
            return False
        if self.recipient and other.recipient:
            if self.recipient.lower() != other.recipient.lower():
                return False
        if self.target_object and other.target_object:
            if self.target_object.lower() != other.target_object.lower():
                return False
        return True

    def to_dict(self) -> dict:
        d: dict = {"verb": self.verb}
        if self.target_object:
            d["target_object"] = self.target_object
        if self.recipient:
            d["recipient"] = self.recipient
        if self.purpose:
            d["purpose"] = self.purpose
        return d


@dataclass
class TargetRelation:
    """A relation the task is trying to establish, preserve, or remove."""
    relation_type: str
    source: str
    target: str
    direction: str = "establish"

    def to_dict(self) -> dict:
        return {
            "relation_type": self.relation_type,
            "source": self.source,
            "target": self.target,
            "direction": self.direction,
        }


@dataclass
class ExecutionProfile:
    """Parameters, manner, and horizon of the task."""
    required_skills: list[str] = field(default_factory=list)
    step_count: int = 0
    involves_hazardous_object: bool = False
    involves_protected_entity: bool = False

    def to_dict(self) -> dict:
        return {
            "required_skills": self.required_skills,
            "step_count": self.step_count,
            "involves_hazardous_object": self.involves_hazardous_object,
            "involves_protected_entity": self.involves_protected_entity,
        }


@dataclass
class VulnerabilityContext:
    """Frame-level projection of HazardDiagnosis. Not a replacement."""
    hazardous_entities: list[str] = field(default_factory=list)
    protected_entities: list[str] = field(default_factory=list)
    hazardous_relations: list[dict] = field(default_factory=list)
    flagged_dimensions: list[str] = field(default_factory=list)
    hazard_summary: str = ""

    def to_dict(self) -> dict:
        return {
            "hazardous_entities": self.hazardous_entities,
            "protected_entities": self.protected_entities,
            "hazardous_relations": self.hazardous_relations,
            "flagged_dimensions": self.flagged_dimensions,
            "hazard_summary": self.hazard_summary,
        }


@dataclass
class RepairAnchors:
    """What should be preserved if possible, what may change if safety requires.

    Anchors are preferences, not inviolable rules. Safety necessity
    can override any anchor.
    """
    preserve_goal: bool = True
    preserve_primary_object: bool = True
    preserve_recipient: bool = True
    preserve_location: bool = False
    preserve_manner: bool = False
    mutable_fields: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "preserve_goal": self.preserve_goal,
            "preserve_primary_object": self.preserve_primary_object,
            "preserve_recipient": self.preserve_recipient,
            "preserve_location": self.preserve_location,
            "preserve_manner": self.preserve_manner,
            "mutable_fields": self.mutable_fields,
        }


# Objective Frame

@dataclass
class ObjectiveFrame:
    """
    Repair-Aligned Objective Frame  κ = ⟨g, E, R, X, V, A, Π⟩

    Assembled from existing pipeline artifacts. Used for:
    - Comparing original vs repaired intent
    - Anchor-aware fidelity scoring
    - Intent-preservation safeguard decisions
    """
    goal_intent: GoalIntent
    task_referents: list[str] = field(default_factory=list)
    target_relations: list[TargetRelation] = field(default_factory=list)
    execution_profile: ExecutionProfile = field(default_factory=ExecutionProfile)
    vulnerability_context: VulnerabilityContext = field(default_factory=VulnerabilityContext)
    repair_anchors: RepairAnchors = field(default_factory=RepairAnchors)
    realization_plan: list[CanonicalAction] = field(default_factory=list)
    expected_end_state: str = ""
    repair_posture: str = ""

    def to_dict(self) -> dict:
        return {
            "goal_intent": self.goal_intent.to_dict(),
            "task_referents": self.task_referents,
            "target_relations": [r.to_dict() for r in self.target_relations],
            "execution_profile": self.execution_profile.to_dict(),
            "vulnerability_context": self.vulnerability_context.to_dict(),
            "repair_anchors": self.repair_anchors.to_dict(),
            "realization_plan": [a.to_dict() for a in self.realization_plan],
            "expected_end_state": self.expected_end_state,
            "repair_posture": self.repair_posture,
        }


# Anchor-Aware Fidelity Scoring

# Fixed system hyperparameters (not learned)
GAMMA = 0.15
DELTA = 0.10
INTENT_PRESERVING_THRESHOLD = 0.7


def anchor_preservation_score(
    original: ObjectiveFrame,
    repaired: ObjectiveFrame,
) -> float:

    anchors = original.repair_anchors
    checks: list[tuple[bool, float]] = []

    if anchors.preserve_goal:
        verb_match = (
            original.goal_intent.verb.lower() == repaired.goal_intent.verb.lower()
        )
        checks.append((True, 1.0 if verb_match else 0.0))

    if anchors.preserve_primary_object:
        orig_obj = (original.goal_intent.target_object or "").lower()
        repair_obj = (repaired.goal_intent.target_object or "").lower()
        obj_preserved = orig_obj == repair_obj if orig_obj else True
        checks.append((True, 1.0 if obj_preserved else 0.0))

    if anchors.preserve_recipient:
        orig_recip = (original.goal_intent.recipient or "").lower()
        repair_recip = (repaired.goal_intent.recipient or "").lower()
        recip_preserved = orig_recip == repair_recip if orig_recip else True
        checks.append((True, 1.0 if recip_preserved else 0.0))

    if anchors.preserve_location:
        orig_rels = {(r.relation_type, r.target) for r in original.target_relations}
        repair_rels = {(r.relation_type, r.target) for r in repaired.target_relations}
        if orig_rels:
            overlap = len(orig_rels & repair_rels) / len(orig_rels)
        else:
            overlap = 1.0
        checks.append((True, overlap))

    if not checks:
        return 1.0

    return sum(score for _, score in checks) / len(checks)


def unjustified_drift(
    original: ObjectiveFrame,
    repaired: ObjectiveFrame,
    safety_margin: float,
    safety_margin_threshold: float = 0.15,
) -> float:
    anchor_score = anchor_preservation_score(original, repaired)
    drift = 1.0 - anchor_score

    if drift <= 0.0:
        return 0.0

    safety_justification = min(1.0, safety_margin / safety_margin_threshold)
    justified_fraction = safety_justification
    unjustified = drift * (1.0 - justified_fraction)
    return max(0.0, unjustified)


def is_intent_preserving(
    original: ObjectiveFrame,
    repaired: ObjectiveFrame,
    threshold: float = INTENT_PRESERVING_THRESHOLD,
) -> bool:
    return anchor_preservation_score(original, repaired) >= threshold


def compute_adjusted_score(
    preference_score: float,
    safety_margin: float,
    original_frame: ObjectiveFrame,
    repaired_frame: ObjectiveFrame,
    gamma: float = GAMMA,
    delta: float = DELTA,
) -> float:
    ap = anchor_preservation_score(original_frame, repaired_frame)
    ud = unjustified_drift(original_frame, repaired_frame, safety_margin)
    return preference_score + gamma * ap - delta * ud


# Repair Posture Classification

def classify_repair_posture(
    original: ObjectiveFrame,
    repaired: ObjectiveFrame,
) -> str:
    """Classify a repair as local, moderate, or strong based on anchor drift."""
    ap = anchor_preservation_score(original, repaired)
    if ap >= 0.9:
        return "local"
    elif ap >= 0.5:
        return "moderate"
    else:
        return "strong"


# Frame Construction Utilities

_TRANSFER_VERBS = {"give", "hand", "pass", "deliver", "bring", "serve"}
_PLACEMENT_VERBS = {"put", "place", "set", "move", "push", "slide"}
_REMOVAL_VERBS = {"remove", "take", "clear", "pick"}

_PERSON_INDICATORS = {
    "child", "kid", "toddler", "baby", "infant",
    "adult", "parent", "person", "user", "chef",
}


def _extract_goal_intent(
    command: str,
    action_plan: list[CanonicalAction] | None = None,
) -> GoalIntent:
    """Extract goal intent from command text and optional action plan.

    Deterministic extraction: parses the command verb, primary object,
    and recipient from command text. Falls back to action plan if
    command parsing is ambiguous.
    """
    tokens = command.lower().split()
    if not tokens:
        return GoalIntent(verb="unknown")

    verb = tokens[0]

    target_object: Optional[str] = None
    recipient: Optional[str] = None

    # Look for "to the <recipient>" pattern
    for i, tok in enumerate(tokens):
        if tok == "to" and i + 1 < len(tokens):
            remaining = tokens[i + 1:]
            if remaining and remaining[0] == "the":
                remaining = remaining[1:]
            if remaining:
                first_word = remaining[0].rstrip("'s")
                if first_word in _PERSON_INDICATORS:
                    recipient = first_word

    # Look for "on the <location>" or "in the <container>" for placement
    for i, tok in enumerate(tokens):
        if tok in ("on", "in", "into", "onto") and i + 1 < len(tokens):
            remaining = tokens[i + 1:]
            if remaining and remaining[0] == "the":
                remaining = remaining[1:]
            if remaining and not recipient:
                recipient = " ".join(remaining).split(",")[0].strip()
                break

    # Primary object: first noun after verb, before preposition
    preps = {"to", "on", "in", "into", "onto", "from", "near", "next", "away"}
    obj_tokens = []
    for tok in tokens[1:]:
        if tok in preps or tok == "the":
            if obj_tokens:
                break
            continue
        obj_tokens.append(tok)
    if obj_tokens:
        candidate = " ".join(obj_tokens).rstrip("'s")
        if candidate not in _PERSON_INDICATORS:
            target_object = candidate
        elif not recipient:
            recipient = candidate
            target_object = None

    # Refine from action plan if available
    if action_plan:
        primary = action_plan[0]
        if not target_object and primary.obj:
            target_object = primary.obj
        if not recipient and primary.receptacle:
            recipient = primary.receptacle
        if verb == "unknown":
            verb = primary.verb

    return GoalIntent(
        verb=verb,
        target_object=target_object,
        recipient=recipient,
    )


def _extract_target_relations(
    goal: GoalIntent,
    interaction_graph=None,
    action_plan: list[CanonicalAction] | None = None,
) -> list[TargetRelation]:
    """Extract target relations from goal intent and interaction graph."""
    relations: list[TargetRelation] = []

    if goal.verb.lower() in _TRANSFER_VERBS and goal.recipient:
        relations.append(TargetRelation(
            relation_type="transfer",
            source=goal.target_object or "object",
            target=goal.recipient,
            direction="establish",
        ))
    elif goal.verb.lower() in _PLACEMENT_VERBS and goal.recipient:
        relations.append(TargetRelation(
            relation_type="placement",
            source=goal.target_object or "object",
            target=goal.recipient,
            direction="establish",
        ))
    elif goal.verb.lower() in _REMOVAL_VERBS:
        relations.append(TargetRelation(
            relation_type="removal",
            source=goal.target_object or "object",
            target=goal.recipient or "location",
            direction="remove",
        ))

    if action_plan:
        for action in action_plan:
            if action.obj and action.receptacle:
                rel_type = "transfer" if action.verb in _TRANSFER_VERBS else "placement"
                rel = TargetRelation(
                    relation_type=rel_type,
                    source=action.obj,
                    target=action.receptacle,
                    direction="establish",
                )
                if rel not in relations:
                    relations.append(rel)

    return relations


def _extract_task_referents(
    goal: GoalIntent,
    interaction_graph=None,
    action_plan: list[CanonicalAction] | None = None,
) -> list[str]:
    """Extract primary task referents (manipulated, affected, protected entities)."""
    referents: set[str] = set()

    if goal.target_object:
        referents.add(goal.target_object.lower())
    if goal.recipient:
        referents.add(goal.recipient.lower())

    if action_plan:
        for action in action_plan:
            if action.obj:
                referents.add(action.obj.lower())
            if action.receptacle:
                referents.add(action.receptacle.lower())

    if interaction_graph:
        for entity in interaction_graph.entities:
            if entity.entity_type == "person":
                referents.add(entity.name.lower())

    return sorted(referents)


def _build_vulnerability_context(diagnosis) -> VulnerabilityContext:
    """Project HazardDiagnosis into a VulnerabilityContext."""
    protected: list[str] = []
    if diagnosis.interaction_graph:
        for entity in diagnosis.interaction_graph.entities:
            if entity.entity_type == "person":
                name_lower = entity.name.lower()
                if name_lower not in {e.lower() for e in diagnosis.hazardous_entities}:
                    protected.append(entity.name)

    return VulnerabilityContext(
        hazardous_entities=sorted(diagnosis.hazardous_entities),
        protected_entities=protected,
        hazardous_relations=list(diagnosis.hazardous_relationships),
        flagged_dimensions=[d.name for d in diagnosis.flagged_dimensions],
        hazard_summary=diagnosis.hazard_summary,
    )


def _build_repair_anchors(
    goal: GoalIntent,
    vulnerability: VulnerabilityContext,
) -> RepairAnchors:
    mutable: list[str] = []

    preserve_obj = True
    if goal.target_object:
        if goal.target_object.lower() in {e.lower() for e in vulnerability.hazardous_entities}:
            preserve_obj = False
            mutable.append("target_object")

    preserve_recip = True
    if goal.recipient:
        if goal.recipient.lower() in {e.lower() for e in vulnerability.hazardous_entities}:
            preserve_recip = False
            mutable.append("recipient")

    return RepairAnchors(
        preserve_goal=True,
        preserve_primary_object=preserve_obj,
        preserve_recipient=preserve_recip,
        preserve_location=False,
        preserve_manner=False,
        mutable_fields=mutable,
    )


def _build_execution_profile(
    action_plan: list[CanonicalAction] | None,
    vulnerability: VulnerabilityContext,
    task_referents: list[str],
) -> ExecutionProfile:
    """Build execution profile from action plan and vulnerability context."""
    skills: set[str] = set()
    if action_plan:
        for a in action_plan:
            skills.add(a.verb)

    hazardous_set = {e.lower() for e in vulnerability.hazardous_entities}
    protected_set = {e.lower() for e in vulnerability.protected_entities}

    involves_hazardous = bool(hazardous_set & {r.lower() for r in task_referents})
    involves_protected = bool(protected_set & {r.lower() for r in task_referents})

    return ExecutionProfile(
        required_skills=sorted(skills),
        step_count=len(action_plan) if action_plan else 0,
        involves_hazardous_object=involves_hazardous,
        involves_protected_entity=involves_protected,
    )


# Public Construction API

def build_objective_frame(
    command: str,
    diagnosis,
    interaction_graph=None,
    action_plan: list[CanonicalAction] | None = None,
    expected_end_state: str = "",
) -> ObjectiveFrame:
    """Build the original ObjectiveFrame from existing pipeline artifacts.

    Deterministic construction — no LLM calls. Assembles the frame from:
    - command text (goal intent extraction)
    - HazardDiagnosis (vulnerability context, entity inventory)
    - InteractionGraph (task referents, person entities)
    - Action plan if available (skills, step count, referents)

    Parameters
    ----------
    command : str
        The original unsafe command.
    diagnosis : HazardDiagnosis
        From initial safety evaluation.
    interaction_graph : InteractionGraph, optional
        From graph construction step. Falls back to diagnosis.interaction_graph.
    action_plan : list[CanonicalAction], optional
        If the original command was compiled to an action plan.
    expected_end_state : str
        Description of the intended outcome.
    """
    graph = interaction_graph or getattr(diagnosis, 'interaction_graph', None)

    goal = _extract_goal_intent(command, action_plan)
    vulnerability = _build_vulnerability_context(diagnosis)
    referents = _extract_task_referents(goal, graph, action_plan)
    relations = _extract_target_relations(goal, graph, action_plan)
    anchors = _build_repair_anchors(goal, vulnerability)
    profile = _build_execution_profile(action_plan, vulnerability, referents)

    return ObjectiveFrame(
        goal_intent=goal,
        task_referents=referents,
        target_relations=relations,
        execution_profile=profile,
        vulnerability_context=vulnerability,
        repair_anchors=anchors,
        realization_plan=list(action_plan) if action_plan else [],
        expected_end_state=expected_end_state,
    )


def derive_repaired_frame(
    original: ObjectiveFrame,
    candidate_command: str,
    candidate_action_plan: list[CanonicalAction] | None = None,
    candidate_expected_end_state: str = "",
    candidate_strategy: str = "",
) -> ObjectiveFrame:
    """Derive a repaired ObjectiveFrame from the original frame + candidate.

    Fully deterministic. Reads from the candidate's existing structured
    fields and inherits vulnerability context and anchors from the original.

    Parameters
    ----------
    original : ObjectiveFrame
        The original command's frame.
    candidate_command : str
        The repair candidate's command text.
    candidate_action_plan : list[CanonicalAction], optional
        The candidate's bundled action plan.
    candidate_expected_end_state : str
        The candidate's expected end state.
    candidate_strategy : str
        Haddon strategy ID (H1-H7).
    """
    goal = _extract_goal_intent(candidate_command, candidate_action_plan)
    referents = _extract_task_referents(goal, None, candidate_action_plan)
    relations = _extract_target_relations(goal, None, candidate_action_plan)

    profile = _build_execution_profile(
        candidate_action_plan,
        original.vulnerability_context,
        referents,
    )

    repaired = ObjectiveFrame(
        goal_intent=goal,
        task_referents=referents,
        target_relations=relations,
        execution_profile=profile,
        vulnerability_context=original.vulnerability_context,
        repair_anchors=original.repair_anchors,
        realization_plan=list(candidate_action_plan) if candidate_action_plan else [],
        expected_end_state=candidate_expected_end_state,
    )

    repaired.repair_posture = classify_repair_posture(original, repaired)

    return repaired
