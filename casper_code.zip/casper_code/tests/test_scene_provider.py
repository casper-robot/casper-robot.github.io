"""Tests for casper.scene_provider."""

from casper.scene_provider import (
    SceneProvider,
    Scene,
    SceneObject,
    _categorize_object,
    _build_scene_object,
    _infer_room_type,
)


def test_infer_room_type():
    assert _infer_room_type("FloorPlan1") == "Kitchen"
    assert _infer_room_type("FloorPlan30") == "Kitchen"
    assert _infer_room_type("FloorPlan201") == "Living Room"
    assert _infer_room_type("FloorPlan301") == "Bedroom"
    assert _infer_room_type("FloorPlan401") == "Bathroom"
    assert _infer_room_type("Unknown") == "Room"


def test_categorize_object():
    assert _categorize_object("Knife") == "utensil"
    assert _categorize_object("Bowl") == "container"
    assert _categorize_object("Microwave") == "appliance"
    assert _categorize_object("Apple") == "food"
    assert _categorize_object("SoapBottle") == "liquid/chemical"
    assert _categorize_object("CounterTop") == "fixture"
    assert _categorize_object("FloorLamp") == "lighting"
    assert _categorize_object("Bathtub") == "plumbing"


def test_build_scene_object():
    obj = _build_scene_object("Knife")
    assert obj.name == "Knife"
    assert obj.category == "utensil"
    assert obj.is_hazardous
    assert obj.hazard_type == "cut"
    assert obj.properties["pickupable"]
    assert obj.properties["sharp"]


def test_build_scene_object_unknown():
    obj = _build_scene_object("SomeNewObject")
    assert obj.name == "SomeNewObject"
    assert obj.properties == {}
    assert not obj.is_hazardous


def test_scene_provider_loads_from_cache():
    sp = SceneProvider(force_cache=True)
    scene = sp.load_scene("FloorPlan1")
    assert scene.scene_id == "FloorPlan1"
    assert scene.room_type == "Kitchen"
    assert scene.source == "cache"
    assert len(scene.objects) > 0
    assert "Knife" in scene.object_names
    assert "Apple" in scene.object_names


def test_scene_provider_available_scenes():
    sp = SceneProvider(force_cache=True)
    scenes = sp.available_scenes()
    assert len(scenes) > 0
    assert "FloorPlan1" in scenes


def test_scene_context_has_rich_info():
    sp = SceneProvider(force_cache=True)
    scene = sp.load_scene("FloorPlan1")
    ctx = scene.scene_context
    assert "Kitchen" in ctx
    assert "Knife" in ctx
    assert "pickupable" in ctx
    assert "hazard:" in ctx


def test_scene_hazardous_objects():
    sp = SceneProvider(force_cache=True)
    scene = sp.load_scene("FloorPlan1")
    hazardous = scene.hazardous_objects
    assert len(hazardous) > 0
    names = [o.name for o in hazardous]
    assert "Knife" in names
    assert "StoveBurner" in names


def test_scene_object_to_dict():
    obj = _build_scene_object("Knife")
    d = obj.to_dict()
    assert d["name"] == "Knife"
    assert d["category"] == "utensil"
    assert "sharp" in d["properties"]


def test_scene_to_dict():
    sp = SceneProvider(force_cache=True)
    scene = sp.load_scene("FloorPlan1")
    d = scene.to_dict()
    assert d["scene_id"] == "FloorPlan1"
    assert d["room_type"] == "Kitchen"
    assert len(d["objects"]) > 0
    assert len(d["object_names"]) > 0


def test_unknown_scene_returns_empty():
    sp = SceneProvider(force_cache=True)
    scene = sp.load_scene("FloorPlanNonexistent999")
    assert scene.source == "empty"
    assert len(scene.objects) == 0


def test_get_convenience_methods():
    sp = SceneProvider(force_cache=True)
    ctx = sp.get_scene_context("FloorPlan1")
    assert "Kitchen" in ctx
    names = sp.get_object_names("FloorPlan1")
    assert "Knife" in names
