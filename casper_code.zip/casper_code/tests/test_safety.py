"""
CASPER Safety Subsystem — Test Suite

Tests:
1. Unit: InteractionGraph union
2. Unit: Any-flag-unsafe aggregation logic
3. Unit: Safety margin computation
4. Unit: Structural completeness enforcement
5. Integration: Full pipeline with mock scenarios
6. Edge cases: parse failures, conservative defaults
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import json

from casper.safety_kernel import (
    Entity,
    Relationship,
    InteractionGraph,
    HarmDimension,
    DimensionAssessment,
    DimensionResult,
    SafetyConfig,
    SafetyKernel,
    SafetyResult,
)
from casper.llm_interface import (
    ScenarioMockBackend,
    MockLLMBackend,
    LLMBackend,
    LLMResponse,
    parse_json_response,
)
from casper.safety_pipeline import SafetyPipeline, RepairCandidate
from casper.prompt_templates import render_prompt


# Test Utilities

def make_assessments(
    dimension: HarmDimension,
    flags: list[bool],
) -> list[DimensionAssessment]:
    """Helper: create assessments with given flag pattern."""
    return [
        DimensionAssessment(
            dimension=dimension,
            concern=flag,
            reasoning=f"Pass {i}: {'concern' if flag else 'no concern'}",
            severity="high" if flag else "none",
            pass_id=i,
        )
        for i, flag in enumerate(flags)
    ]


def make_all_clear() -> dict[HarmDimension, DimensionResult]:
    """Helper: all 6 dimensions with no flags (single assessment each)."""
    return {
        dim: DimensionResult(
            dimension=dim,
            assessments=make_assessments(dim, [False]),
        )
        for dim in HarmDimension
    }


def make_with_flags(
    flagged_dim: HarmDimension,
    concern: bool = True,
) -> dict[HarmDimension, DimensionResult]:
    """Helper: all clear except one dimension with a single flagged assessment."""
    results = make_all_clear()
    results[flagged_dim] = DimensionResult(
        dimension=flagged_dim,
        assessments=make_assessments(flagged_dim, [concern]),
    )
    return results


passed = 0
failed = 0
total = 0


def check(name: str, condition: bool, detail: str = ""):
    global passed, failed, total
    total += 1
    if condition:
        passed += 1
        print(f"  ✓ {name}")
    else:
        failed += 1
        msg = f"  ✗ {name}"
        if detail:
            msg += f" — {detail}"
        print(msg)


# Unit Tests: Interaction Graph

def test_graph_union():
    print("\n== Graph Union ==")

    g1 = InteractionGraph()
    g1.add_entity(Entity("grapes", "round, smooth, small fruit", "object"))
    g1.add_entity(Entity("baby", "8 month old infant", "person"))
    g1.add_relationship(Relationship("grapes", "baby", "ingestion", "baby eats grapes"))

    g2 = InteractionGraph()
    g2.add_entity(Entity("grapes", "whole grapes, choking hazard size", "object"))
    g2.add_entity(Entity("baby", "8 month old infant", "person"))
    g2.add_entity(Entity("bowl", "on high chair tray, accessible", "object"))
    g2.add_relationship(Relationship("grapes", "baby", "ingestion", "baby puts grape in mouth"))
    g2.add_relationship(Relationship("bowl", "baby", "access", "baby can reach bowl"))

    g3 = InteractionGraph()
    g3.add_entity(Entity("grapes", "round fruit", "object"))
    g3.add_entity(Entity("high_chair", "baby seated in chair with tray", "object"))
    g3.add_relationship(Relationship("baby", "grapes", "handling", "baby grasps grapes"))

    g_star = InteractionGraph.union([g1, g2, g3])

    check("Union collects all unique entities", g_star.entity_count() == 4,
          f"got {g_star.entity_count()}")

    check("Union collects all unique relationships", g_star.relationship_count() == 3,
          f"got {g_star.relationship_count()}")

    grapes = g_star.get_entity("grapes")
    check("Keeps longest entity description",
          grapes is not None and "choking hazard" in grapes.description,
          f"got: {grapes.description if grapes else 'None'}")

    check("Entity from single graph included", g_star.get_entity("bowl") is not None)


def test_empty_graph_union():
    print("\n== Empty Graph Edge Cases ==")

    g1 = InteractionGraph()
    g2 = InteractionGraph()
    g2.add_entity(Entity("item", "a thing", "object"))

    g_star = InteractionGraph.union([g1, g2])
    check("Union with empty graph preserves entities", g_star.entity_count() == 1)

    g_star = InteractionGraph.union([g1])
    check("Union of single empty graph works", g_star.entity_count() == 0)


# Unit Tests: Any-Flag-Unsafe Aggregation

def test_any_flag_unsafe():
    print("\n== Any-Flag-Unsafe Aggregation ==")
    kernel = SafetyKernel()

    results = make_all_clear()
    outcome = kernel.evaluate_safety("test command", results)
    check("All clear → safe", outcome.is_safe)
    check("All clear → margin = 1.0", outcome.safety_margin == 1.0,
          f"got {outcome.safety_margin}")

    results = make_with_flags(HarmDimension.D1_DIRECT_INTERACTION, concern=True)
    outcome = kernel.evaluate_safety("test command", results)
    check("One flag → unsafe", not outcome.is_safe)
    check("Flagged dimension is D1",
          HarmDimension.D1_DIRECT_INTERACTION in outcome.flagged_dimensions)
    check("Unsafe → margin = 0.0", outcome.safety_margin == 0.0,
          f"got {outcome.safety_margin}")


def test_multiple_dimensions_flagged():
    print("\n== Multiple Dimensions Flagged ==")
    kernel = SafetyKernel()

    results = make_all_clear()
    results[HarmDimension.D1_DIRECT_INTERACTION] = DimensionResult(
        dimension=HarmDimension.D1_DIRECT_INTERACTION,
        assessments=make_assessments(HarmDimension.D1_DIRECT_INTERACTION, [True]),
    )
    results[HarmDimension.D4_FORESEEABLE_CHAIN] = DimensionResult(
        dimension=HarmDimension.D4_FORESEEABLE_CHAIN,
        assessments=make_assessments(HarmDimension.D4_FORESEEABLE_CHAIN, [True]),
    )

    outcome = kernel.evaluate_safety("test command", results)
    check("Two flagged dimensions → unsafe", not outcome.is_safe)
    check("Both dimensions in flagged list", len(outcome.flagged_dimensions) == 2)
    check("D1 in flagged",
          HarmDimension.D1_DIRECT_INTERACTION in outcome.flagged_dimensions)
    check("D4 in flagged",
          HarmDimension.D4_FORESEEABLE_CHAIN in outcome.flagged_dimensions)


def test_dimension_result_flagged():
    print("\n== DimensionResult.flagged ==")

    dr = DimensionResult(
        dimension=HarmDimension.D1_DIRECT_INTERACTION,
        assessments=make_assessments(HarmDimension.D1_DIRECT_INTERACTION, [False]),
    )
    check("No concern → not flagged", not dr.flagged)

    dr = DimensionResult(
        dimension=HarmDimension.D1_DIRECT_INTERACTION,
        assessments=make_assessments(HarmDimension.D1_DIRECT_INTERACTION, [True]),
    )
    check("Concern → flagged", dr.flagged)

    check("is_flagged() backward compat", dr.is_flagged())


def test_safety_margin():
    print("\n== Safety Margin ==")
    kernel = SafetyKernel()

    results = make_all_clear()
    outcome = kernel.evaluate_safety("cmd", results)
    check("Safe → margin = 1.0", outcome.safety_margin == 1.0)

    results = make_with_flags(HarmDimension.D2_RESULTING_STATE, concern=True)
    outcome = kernel.evaluate_safety("cmd", results)
    check("Unsafe → margin = 0.0", outcome.safety_margin == 0.0)


def test_structural_completeness():
    print("\n== Structural Completeness ==")
    kernel = SafetyKernel()

    incomplete = {
        dim: DimensionResult(
            dimension=dim,
            assessments=make_assessments(dim, [False]),
        )
        for dim in list(HarmDimension)[:5]  # Only 5 of 6
    }

    try:
        kernel.evaluate_safety("test", incomplete)
        check("Missing dimension raises error", False, "no exception raised")
    except ValueError as e:
        check("Missing dimension raises error", "Structural completeness" in str(e))


def test_safety_config_backward_compat():
    print("\n== SafetyConfig Backward Compat ==")

    config = SafetyConfig()
    check("Default config creates", config is not None)

    fast = SafetyConfig.fast()
    check("SafetyConfig.fast() works", fast is not None)


# Integration Tests: Full Pipeline with Mock LLM

def build_grapes_scenario() -> ScenarioMockBackend:
    """'Give the baby a few grapes' — should flag D1 (choking)."""
    mock = ScenarioMockBackend(seed=42)
    mock.register_scenario(
        scenario_key="grapes",
        graph_response={
            "entities": [
                {"name": "grapes", "entity_type": "object",
                 "description": "whole grapes, round, smooth, 15-20mm diameter, fits in infant mouth"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant, limited chewing, immature swallow reflex, small airway"},
                {"name": "bowl", "entity_type": "object",
                 "description": "bowl on high chair tray, within baby's reach"},
                {"name": "high_chair", "entity_type": "object",
                 "description": "baby seated in high chair with tray"},
            ],
            "relationships": [
                {"source": "grapes", "target": "baby", "relation": "ingestion",
                 "description": "baby will put grape in mouth and attempt to swallow"},
                {"source": "bowl", "target": "baby", "relation": "access",
                 "description": "bowl within reach, baby can self-serve more grapes"},
                {"source": "baby", "target": "grapes", "relation": "handling",
                 "description": "baby grasps grapes with palmar grip"},
            ],
        },
        dimension_responses={
            1: {"concern": True,
                "reasoning": "Whole grapes are a severe choking hazard for infants. "
                             "Spherical shape, smooth texture, and size (~15-20mm) matches "
                             "infant airway diameter. Infant lacks mature chewing and swallow reflex.",
                "severity": "critical",
                "specific_harm": "Airway obstruction from whole grape ingestion"},
            2: {"concern": False,
                "reasoning": "After grapes are given, the state is a baby with grapes. "
                             "No persistent environmental hazard created.",
                "severity": "none", "specific_harm": "none"},
            3: {"concern": False,
                "reasoning": "No safety mechanism is being removed.",
                "severity": "none", "specific_harm": "none"},
            4: {"concern": True,
                "reasoning": "Bowl within reach means baby can grab more grapes unsupervised. "
                             "Foreseeable chain: baby reaches bowl → grabs grape → puts in mouth → chokes.",
                "severity": "high",
                "specific_harm": "Unsupervised self-serving leading to choking"},
            5: {"concern": False,
                "reasoning": "No property damage.",
                "severity": "none", "specific_harm": "none"},
            6: {"concern": False,
                "reasoning": "No widely shared normative violation.",
                "severity": "none", "specific_harm": "none"},
        },
    )
    return mock


def build_safe_scenario() -> ScenarioMockBackend:
    """'Give the baby mashed banana' — should be safe on all dimensions."""
    mock = ScenarioMockBackend(seed=42)
    mock.register_scenario(
        scenario_key="mashed banana",
        graph_response={
            "entities": [
                {"name": "mashed_banana", "entity_type": "object",
                 "description": "soft, mashed banana, age-appropriate texture, no choking risk"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant, can handle soft foods"},
                {"name": "bowl", "entity_type": "object",
                 "description": "small bowl on high chair tray"},
            ],
            "relationships": [
                {"source": "mashed_banana", "target": "baby", "relation": "ingestion",
                 "description": "baby eats mashed banana with fingers or spoon"},
            ],
        },
        dimension_responses={
            1: {"concern": False, "reasoning": "Mashed banana is soft, age-appropriate, "
                "no choking risk for 8-month-old.", "severity": "none", "specific_harm": "none"},
            2: {"concern": False, "reasoning": "No hazardous resulting state.",
                "severity": "none", "specific_harm": "none"},
            3: {"concern": False, "reasoning": "No barriers removed.",
                "severity": "none", "specific_harm": "none"},
            4: {"concern": False, "reasoning": "No foreseeable chain to harm.",
                "severity": "none", "specific_harm": "none"},
            5: {"concern": False, "reasoning": "No property damage.",
                "severity": "none", "specific_harm": "none"},
            6: {"concern": False, "reasoning": "No normative violation.",
                "severity": "none", "specific_harm": "none"},
        },
    )
    return mock


def build_barrier_scenario() -> ScenarioMockBackend:
    """'Open the baby gate' — should flag D3 (barrier removal)."""
    mock = ScenarioMockBackend(seed=42)
    mock.register_scenario(
        scenario_key="baby gate",
        graph_response={
            "entities": [
                {"name": "baby_gate", "entity_type": "safety_mechanism",
                 "description": "gate at top of staircase, currently closed and locked"},
                {"name": "toddler", "entity_type": "person",
                 "description": "2-year-old, mobile, curious, cannot open gate independently"},
                {"name": "staircase", "entity_type": "region",
                 "description": "steep staircase, 12 steps, hardwood, no carpet"},
            ],
            "relationships": [
                {"source": "baby_gate", "target": "toddler", "relation": "containment",
                 "description": "gate prevents toddler from accessing staircase"},
                {"source": "staircase", "target": "toddler", "relation": "proximity",
                 "description": "staircase directly behind gate"},
            ],
        },
        dimension_responses={
            1: {"concern": False, "reasoning": "Opening a gate is not directly harmful.",
                "severity": "none", "specific_harm": "none"},
            2: {"concern": True,
                "reasoning": "After gate is opened, staircase is accessible to toddler. "
                             "This creates a persistent fall hazard.",
                "severity": "high",
                "specific_harm": "Toddler fall hazard from exposed staircase"},
            3: {"concern": True,
                "reasoning": "The baby gate is a safety mechanism protecting toddler from "
                             "staircase. Opening it removes this barrier.",
                "severity": "critical",
                "specific_harm": "Safety barrier removed, exposing toddler to staircase"},
            4: {"concern": True,
                "reasoning": "Foreseeable chain: gate opened → toddler approaches staircase → "
                             "toddler attempts to descend → falls.",
                "severity": "critical",
                "specific_harm": "Toddler staircase fall"},
            5: {"concern": False, "reasoning": "No property damage.",
                "severity": "none", "specific_harm": "none"},
            6: {"concern": False, "reasoning": "No normative violation.",
                "severity": "none", "specific_harm": "none"},
        },
    )
    return mock


def test_pipeline_grapes():
    print("\n== Pipeline: 'Give the baby a few grapes' ==")
    mock = build_grapes_scenario()
    pipeline = SafetyPipeline(llm=mock)

    result = pipeline.evaluate(
        command="Give the baby a few grapes",
        scene_context="8-month-old baby in high chair. Bowl of grapes on tray.",
    )

    check("Grapes → UNSAFE", not result.is_safe)
    check("D1 flagged (choking)",
          HarmDimension.D1_DIRECT_INTERACTION in result.flagged_dimensions)
    check("Graph has >= 3 entities", result.interaction_graph.entity_count() >= 3,
          f"got {result.interaction_graph.entity_count()}")
    print(f"  Summary:\n{result.summary()}")


def test_pipeline_safe_command():
    print("\n== Pipeline: 'Give the baby mashed banana' ==")
    mock = build_safe_scenario()
    pipeline = SafetyPipeline(llm=mock)

    result = pipeline.evaluate(
        command="Give the baby mashed banana",
        scene_context="8-month-old baby in high chair. Mashed banana in bowl.",
    )

    check("Mashed banana → SAFE", result.is_safe)
    check("No flagged dimensions", len(result.flagged_dimensions) == 0)
    check("Safety margin = 1.0",
          result.safety_margin == 1.0,
          f"got {result.safety_margin}")


def test_pipeline_barrier_removal():
    print("\n== Pipeline: 'Open the baby gate' ==")
    mock = build_barrier_scenario()
    pipeline = SafetyPipeline(llm=mock)

    result = pipeline.evaluate(
        command="Open the baby gate",
        scene_context="2-year-old toddler playing near top of staircase. Baby gate is closed.",
    )

    check("Baby gate → UNSAFE", not result.is_safe)
    check("D3 flagged (barrier removal)",
          HarmDimension.D3_BARRIER_REMOVAL in result.flagged_dimensions)
    check("D4 flagged (foreseeable chain)",
          HarmDimension.D4_FORESEEABLE_CHAIN in result.flagged_dimensions)
    check("Multiple dimensions flagged", len(result.flagged_dimensions) >= 2,
          f"got {len(result.flagged_dimensions)}")


def test_pipeline_candidate_filtering():
    print("\n== Pipeline: Candidate Filtering ==")
    mock = ScenarioMockBackend(seed=42)

    mock.register_scenario(
        scenario_key="quartered grapes",
        graph_response={
            "entities": [
                {"name": "quartered_grapes", "entity_type": "object",
                 "description": "grapes cut into quarters, age-appropriate size"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "quartered_grapes", "target": "baby", "relation": "ingestion",
                 "description": "baby eats quartered grape pieces"},
            ],
        },
        dimension_responses={
            1: {"concern": False, "reasoning": "Quartered grapes are size-appropriate.",
                "severity": "none", "specific_harm": "none"},
            2: {"concern": False, "reasoning": "No hazardous state.",
                "severity": "none", "specific_harm": "none"},
            3: {"concern": False, "reasoning": "No barriers removed.",
                "severity": "none", "specific_harm": "none"},
            4: {"concern": False, "reasoning": "No foreseeable chain.",
                "severity": "none", "specific_harm": "none"},
            5: {"concern": False, "reasoning": "No property damage.",
                "severity": "none", "specific_harm": "none"},
            6: {"concern": False, "reasoning": "No normative violation.",
                "severity": "none", "specific_harm": "none"},
        },
    )

    mock.register_scenario(
        scenario_key="whole grapes",
        graph_response={
            "entities": [
                {"name": "whole_grapes", "entity_type": "object",
                 "description": "whole grapes, choking hazard"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "whole_grapes", "target": "baby", "relation": "ingestion",
                 "description": "baby attempts to swallow whole grape"},
            ],
        },
        dimension_responses={
            1: {"concern": True, "reasoning": "Whole grapes are a choking hazard.",
                "severity": "critical", "specific_harm": "Airway obstruction"},
            2: {"concern": False, "severity": "none", "reasoning": "No state hazard.",
                "specific_harm": "none"},
            3: {"concern": False, "severity": "none", "reasoning": "No barrier removed.",
                "specific_harm": "none"},
            4: {"concern": False, "severity": "none", "reasoning": "No chain.",
                "specific_harm": "none"},
            5: {"concern": False, "severity": "none", "reasoning": "No damage.",
                "specific_harm": "none"},
            6: {"concern": False, "severity": "none", "reasoning": "No violation.",
                "specific_harm": "none"},
        },
    )

    pipeline = SafetyPipeline(llm=mock)

    candidates = [
        "Give baby quartered grapes",
        "Give baby whole grapes",
    ]

    safe_cmds, safe_results = pipeline.filter_safe(
        candidates,
        scene_context="8-month-old baby in high chair.",
    )

    check("1 of 2 candidates safe", len(safe_cmds) == 1,
          f"got {len(safe_cmds)}")
    check("Safe candidate is quartered grapes",
          len(safe_cmds) > 0 and "quartered" in safe_cmds[0])


# Unit Tests: SafetyResult Serialization

def test_serialization():
    print("\n== SafetyResult Serialization ==")
    kernel = SafetyKernel()

    results = make_with_flags(HarmDimension.D1_DIRECT_INTERACTION, concern=True)
    outcome = kernel.evaluate_safety("Give baby grapes", results)

    d = outcome.to_dict()
    check("to_dict has command", d["command"] == "Give baby grapes")
    check("to_dict has is_safe", d["is_safe"] is False)
    check("to_dict has flagged_dimensions", "D1_DIRECT_INTERACTION" in d["flagged_dimensions"])
    check("to_dict has all 6 dimensions", len(d["dimensions"]) == 6)

    d1 = d["dimensions"]["D1_DIRECT_INTERACTION"]
    check("Dimension detail has flagged", d1["flagged"] is True)
    check("Dimension detail has assessments", len(d1["assessments"]) == 1)

    try:
        json_str = json.dumps(d)
        check("to_dict is JSON serializable", len(json_str) > 0)
    except (TypeError, ValueError) as e:
        check("to_dict is JSON serializable", False, str(e))


# Unit Tests: Hazard Summary

def test_hazard_summary():
    print("\n== Hazard Summary ==")
    kernel = SafetyKernel()

    results = make_with_flags(HarmDimension.D1_DIRECT_INTERACTION, concern=True)
    for a in results[HarmDimension.D1_DIRECT_INTERACTION].assessments:
        if a.concern:
            a.reasoning = "Whole grapes are a choking hazard for infants."
            a.severity = "critical"
    outcome = kernel.evaluate_safety("Give baby grapes", results)

    summary = outcome.hazard_summary()
    check("Hazard summary mentions D1", "D1_DIRECT_INTERACTION" in summary)
    check("Hazard summary mentions severity", "critical" in summary)
    check("Hazard summary mentions reasoning", "choking" in summary)

    results = make_all_clear()
    outcome = kernel.evaluate_safety("Give baby mashed banana", results)
    summary = outcome.hazard_summary()
    check("Safe command → 'No hazards'", "No hazards" in summary)


def test_severity_threshold():
    """Severity threshold filters low-severity speculative concerns."""
    print("\n== Severity Threshold ==")

    kernel = SafetyKernel()
    results = make_all_clear()
    results[HarmDimension.D2_RESULTING_STATE] = DimensionResult(
        dimension=HarmDimension.D2_RESULTING_STATE,
        assessments=[DimensionAssessment(
            dimension=HarmDimension.D2_RESULTING_STATE,
            concern=True,
            reasoning="Opening cabinet might expose chemicals",
            severity="medium",
        )],
    )
    outcome = kernel.evaluate_safety("Open the cabinet", results)
    check("Medium severity not flagged at high threshold", outcome.is_safe)

    results2 = make_all_clear()
    results2[HarmDimension.D1_DIRECT_INTERACTION] = DimensionResult(
        dimension=HarmDimension.D1_DIRECT_INTERACTION,
        assessments=[DimensionAssessment(
            dimension=HarmDimension.D1_DIRECT_INTERACTION,
            concern=True,
            reasoning="Knife could cut child",
            severity="high",
        )],
    )
    outcome2 = kernel.evaluate_safety("Give knife to child", results2)
    check("High severity still flagged", not outcome2.is_safe)

    kernel_low = SafetyKernel(SafetyConfig(min_severity="low"))
    outcome3 = kernel_low.evaluate_safety("Open the cabinet", results)
    check("Medium severity flagged at low threshold", not outcome3.is_safe)


# Unit Tests: JSON Parsing Edge Cases

def test_json_parsing():
    print("\n== JSON Parsing ==")

    r = parse_json_response('{"concern": true, "reasoning": "test"}')
    check("Normal JSON parses", r.success and r.parsed["concern"] is True)

    r = parse_json_response('```json\n{"concern": false}\n```')
    check("Markdown-fenced JSON parses", r.success and r.parsed["concern"] is False)

    r = parse_json_response('Here is my analysis:\n{"concern": true, "reasoning": "bad"}')
    check("JSON with preamble parses", r.success and r.parsed["concern"] is True)

    r = parse_json_response('This is not JSON at all')
    check("Invalid text → parse_error", not r.success and r.parse_error is not None)

    r = parse_json_response('')
    check("Empty string → parse_error", not r.success)


# Unit Tests: Retry Logic

class FailThenSucceedBackend(LLMBackend):
    """Returns invalid JSON on first call, valid JSON on second."""
    def __init__(self):
        self._call_count = 0

    @property
    def model_name(self) -> str:
        return "fail_then_succeed"

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        self._call_count += 1
        if self._call_count <= 1:
            return "NOT VALID JSON {{{{"
        return json.dumps({"concern": False, "reasoning": "Safe.", "severity": "none"})


def test_retry_logic():
    print("\n== Retry Logic ==")

    backend = FailThenSucceedBackend()
    response = backend.generate_parsed("test prompt", temperature=0.5, max_retries=2)
    check("Retries on parse failure → succeeds", response.success)
    check("Backend called twice", backend._call_count == 2)

    # Backend that always fails
    class AlwaysFailBackend(LLMBackend):
        def __init__(self):
            self._call_count = 0

        @property
        def model_name(self) -> str:
            return "always_fail"

        def generate(self, prompt: str, temperature: float = 0.7) -> str:
            self._call_count += 1
            return "NOT JSON"

    backend = AlwaysFailBackend()
    response = backend.generate_parsed("test", temperature=0.5, max_retries=2)
    check("All retries exhausted → parse_error", not response.success)
    check("Called 3 times (1 + 2 retries)", backend._call_count == 3)


# Unit Tests: Exception Handling in generate_parsed

class ExplodingBackend(LLMBackend):
    """Throws an exception on generate()."""
    @property
    def model_name(self) -> str:
        return "exploding"

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        raise ConnectionError("Network timeout")


def test_exception_handling():
    print("\n== Exception Handling ==")

    backend = ExplodingBackend()
    response = backend.generate_parsed("test", temperature=0.5, max_retries=1)
    check("Backend exception → LLMResponse (not crash)", response is not None)
    check("Response has parse_error", response.parse_error is not None)
    check("Error mentions exception", "Backend exception" in response.parse_error)


# Unit Tests: Prompt Template Validation

def test_prompt_validation():
    print("\n== Prompt Template Validation ==")

    try:
        prompt = render_prompt("graph_construction", command="test", scene_context="test")
        check("Valid render_prompt succeeds", "test" in prompt)
    except Exception as e:
        check("Valid render_prompt succeeds", False, str(e))

    try:
        render_prompt("D1_direct_interaction", command="test")
        check("Missing params raises ValueError", False, "no exception raised")
    except ValueError as e:
        check("Missing params raises ValueError", "Missing" in str(e))

    try:
        render_prompt("nonexistent_template", command="test")
        check("Unknown template raises KeyError", False, "no exception raised")
    except KeyError as e:
        check("Unknown template raises KeyError", "Unknown" in str(e))


# Integration: Repair Generation Pipeline

def test_repair_generation():
    print("\n== Repair Generation Pipeline ==")

    mock = ScenarioMockBackend(seed=42)

    mock.register_scenario(
        scenario_key="grapes",
        graph_response={
            "entities": [
                {"name": "grapes", "entity_type": "object",
                 "description": "whole grapes, choking hazard"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "grapes", "target": "baby", "relation": "ingestion",
                 "description": "baby eats grapes"},
            ],
        },
        dimension_responses={
            1: {"concern": True, "reasoning": "Whole grapes are choking hazard.",
                "severity": "critical", "specific_harm": "Airway obstruction"},
            2: {"concern": False, "severity": "none", "reasoning": "No state hazard.",
                "specific_harm": "none"},
            3: {"concern": False, "severity": "none", "reasoning": "No barrier removed.",
                "specific_harm": "none"},
            4: {"concern": False, "severity": "none", "reasoning": "No chain.",
                "specific_harm": "none"},
            5: {"concern": False, "severity": "none", "reasoning": "No damage.",
                "specific_harm": "none"},
            6: {"concern": False, "severity": "none", "reasoning": "No violation.",
                "specific_harm": "none"},
        },
        repair_response={
            "candidates": [
                {"command": "Give the baby quartered grapes",
                 "strategy": "H7", "explanation": "Cut grapes into quarters"},
                {"command": "Give the baby mashed banana instead",
                 "strategy": "H1", "explanation": "Substitute with safe food"},
            ],
        },
    )

    mock.register_scenario(
        scenario_key="quartered",
        graph_response={
            "entities": [
                {"name": "quartered_grapes", "entity_type": "object",
                 "description": "grapes cut into quarters, safe size"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "quartered_grapes", "target": "baby",
                 "relation": "ingestion", "description": "baby eats quartered grapes"},
            ],
        },
        dimension_responses={
            1: {"concern": False, "reasoning": "Quartered grapes are safe.",
                "severity": "none", "specific_harm": "none"},
            2: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
            3: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
            4: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
            5: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
            6: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
        },
    )

    mock.register_scenario(
        scenario_key="banana",
        graph_response={
            "entities": [
                {"name": "mashed_banana", "entity_type": "object",
                 "description": "mashed banana, soft, safe"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "mashed_banana", "target": "baby",
                 "relation": "ingestion", "description": "baby eats banana"},
            ],
        },
        dimension_responses={
            1: {"concern": False, "reasoning": "Banana is safe.", "severity": "none", "specific_harm": "none"},
            2: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
            3: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
            4: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
            5: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
            6: {"concern": False, "reasoning": "Safe.", "severity": "none", "specific_harm": "none"},
        },
    )

    pipeline = SafetyPipeline(llm=mock)

    original_result = pipeline.evaluate(
        "Give the baby grapes",
        "8-month-old baby in high chair.",
    )
    check("Original is unsafe", not original_result.is_safe)

    candidates = pipeline.generate_repairs(
        command="Give the baby grapes",
        scene_context="8-month-old baby in high chair.",
        safety_result=original_result,
        K=5,
    )

    check("Candidates generated", len(candidates) >= 1,
          f"got {len(candidates)}")

    safe_candidates = [c for c in candidates if c.is_safe]
    check("At least one safe candidate", len(safe_candidates) >= 1,
          f"got {len(safe_candidates)} safe out of {len(candidates)}")

    if candidates:
        c = candidates[0]
        check("Candidate has command", len(c.command) > 0)
        check("Candidate has strategy", c.strategy in ["H1", "H2", "H3", "H4", "H5", "H6", "H7", "unknown"])
        check("Candidate has explanation", len(c.explanation) > 0)
        check("Candidate has safety_result", c.safety_result is not None)

    safe_sorted = pipeline.get_safe_repairs(
        command="Give the baby grapes",
        scene_context="8-month-old baby in high chair.",
        safety_result=original_result,
        K=5,
    )
    check("get_safe_repairs returns only safe", all(c.is_safe for c in safe_sorted))
    if len(safe_sorted) >= 2:
        check("get_safe_repairs sorted by margin",
              safe_sorted[0].safety_margin >= safe_sorted[1].safety_margin)


# Integration: Parse Failure Conservative Default

class GarbageBackend(LLMBackend):
    """Returns invalid JSON for everything. Tests conservative defaults."""
    @property
    def model_name(self) -> str:
        return "garbage"

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        return "I'm sorry, I can't help with that. <<<NOT JSON>>>"


def test_parse_failure_conservative():
    print("\n== Parse Failure Conservative Default ==")

    pipeline = SafetyPipeline(llm=GarbageBackend())

    result = pipeline.evaluate(
        command="Test command",
        scene_context="Test context",
    )

    check("Parse failure → unsafe (conservative)", not result.is_safe)
    check("All dimensions flagged",
          len(result.flagged_dimensions) == 6,
          f"got {len(result.flagged_dimensions)}")


# Unit Tests: Plan Lint Case Normalization

def test_plan_lint_case_insensitive():
    """PlanLinter must match objects/verbs case-insensitively."""
    print("\n== Plan Lint — Case Insensitive ==")
    from casper.plan_lint import PlanLinter
    from casper.action_ir import CanonicalAction

    scene_objects = {"knife", "cutting_board", "apple"}
    linter = PlanLinter(
        valid_actions={"pick", "put", "slice"},
        scene_objects=scene_objects,
    )

    class FakeCandidate:
        def __init__(self, plan):
            self.action_plan = plan

    candidate_mixed = FakeCandidate([
        CanonicalAction(verb="Pick", obj="Knife"),
        CanonicalAction(verb="slice", obj="Apple", receptacle="Cutting_Board"),
    ])
    result = linter.lint(candidate_mixed)
    check("Mixed-case objects pass lint", result.passed,
          f"errors: {result.errors}")

    candidate_bad = FakeCandidate([
        CanonicalAction(verb="pick", obj="Sword"),
    ])
    result_bad = linter.lint(candidate_bad)
    check("Nonexistent object fails lint", not result_bad.passed)

    candidate_verb = FakeCandidate([
        CanonicalAction(verb="PICK", obj="knife"),
    ])
    result_verb = linter.lint(candidate_verb)
    check("Mixed-case verb passes lint", result_verb.passed,
          f"errors: {result_verb.errors}")

    candidate_hold = FakeCandidate([
        CanonicalAction(verb="Pick", obj="knife"),
        CanonicalAction(verb="Pick", obj="apple"),
    ])
    result_hold = linter.lint(candidate_hold)
    check("Double-hold with mixed-case Pick rejected",
          not result_hold.passed)

    candidate_hold_ok = FakeCandidate([
        CanonicalAction(verb="PICK", obj="knife"),
        CanonicalAction(verb="PUT", obj="knife", receptacle="cutting_board"),
        CanonicalAction(verb="Pick", obj="apple"),
    ])
    result_hold_ok = linter.lint(candidate_hold_ok)
    check("Pick-Put-Pick with mixed case passes",
          result_hold_ok.passed, f"errors: {result_hold_ok.errors}")


# Run All Tests

if __name__ == "__main__":
    print("=" * 60)
    print("CASPER Safety Subsystem — Test Suite")
    print("=" * 60)

    # Unit tests — kernel
    test_graph_union()
    test_empty_graph_union()
    test_any_flag_unsafe()
    test_multiple_dimensions_flagged()
    test_dimension_result_flagged()
    test_safety_margin()
    test_structural_completeness()
    test_safety_config_backward_compat()

    # Unit tests — serialization and hazard summary
    test_serialization()
    test_hazard_summary()

    # Unit tests — LLM interface
    test_json_parsing()
    test_retry_logic()
    test_exception_handling()

    # Unit tests — prompt templates
    test_prompt_validation()

    # Unit tests — plan lint
    test_plan_lint_case_insensitive()

    # Integration tests
    test_pipeline_grapes()
    test_pipeline_safe_command()
    test_pipeline_barrier_removal()
    test_pipeline_candidate_filtering()
    test_repair_generation()
    test_parse_failure_conservative()

    print("\n" + "=" * 60)
    print(f"Results: {passed}/{total} passed, {failed} failed")
    print("=" * 60)

    if failed > 0:
        sys.exit(1)
