"""
CASPER Preference Subsystem — Test Suite

Tests:
1. Unit: Bayesian posterior updates (pairwise, accept, reject, edit)
2. Unit: Three-term scoring function
3. Unit: Pairwise selection via PairScore
4. Unit: Autonomy gate transitions
5. Unit: Feature extraction
6. Integration: Full pipeline (safety → preference → selection)
7. Convergence: Posterior converges to simulated user
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import json
import numpy as np

from casper.safety_kernel import (
    SafetyConfig,
    SafetyResult,
    SafetyKernel,
    HarmDimension,
    DimensionAssessment,
    DimensionResult,
)
from casper.feature_extraction import (
    FeatureExtractor,
    StrategyFeatures,
    FEATURE_DIM,
    FEATURE_NAMES,
    baseline_features,
    normalized_levenshtein,
)
from casper.preference_model import (
    PreferenceConfig,
    PreferenceModel,
    SelectionMode,
)
from casper.llm_interface import ScenarioMockBackend, MockLLMBackend
from casper.safety_pipeline import SafetyPipeline
from casper.casper_pipeline import CasperPipeline, CommandOutcome


passed = 0
failed = 0
total = 0


def check(name: str, condition: bool, detail: str = ""):
    global passed, failed, total
    total += 1
    if condition:
        passed += 1
        print(f"  ✓ {name}")
    else:
        failed += 1
        msg = f"  ✗ {name}"
        if detail:
            msg += f" — {detail}"
        print(msg)


# Helpers

def make_features(vals: list[float]) -> np.ndarray:
    """Helper: create a feature vector from a list, padding to FEATURE_DIM."""
    v = list(vals)
    if len(v) < FEATURE_DIM:
        v.extend([0.0] * (FEATURE_DIM - len(v)))
    assert len(v) == FEATURE_DIM
    return np.array(v, dtype=np.float64)


# Features representing different Haddon strategies
PHI_SUBSTITUTE = make_features([0.8, 0.0, 0.0, 0.9, 0.3, 0.7])  # H1: different object
PHI_REDUCE = make_features([0.3, 1.0, 1.0, 0.8, 0.9, 0.2])      # H2: reduce hazard params
PHI_TRANSFORM = make_features([0.5, 1.0, 0.5, 0.7, 0.4, 0.9])   # H7: transform form
PHI_SEPARATE = make_features([0.7, 1.0, 0.0, 0.6, 0.2, 0.3])    # H5: separate in time/space
PHI_BARRIER = make_features([0.4, 1.0, 0.3, 0.85, 0.7, 0.6])    # H6: barrier


# Unit Tests: Posterior Updates

def test_pairwise_update():
    print("\n== Pairwise Update ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    mu_before = model.mu.copy()
    sigma_trace_before = np.trace(model.sigma)

    # User prefers REDUCE over SUBSTITUTE
    model.update_pairwise(PHI_REDUCE, PHI_SUBSTITUTE)

    check("μ changes after update", not np.allclose(model.mu, mu_before))
    check("Σ trace decreases (uncertainty reduced)",
          np.trace(model.sigma) < sigma_trace_before,
          f"{np.trace(model.sigma):.3f} vs {sigma_trace_before:.3f}")
    check("t incremented", model.t == 1)
    check("History recorded", len(model.history) == 1)
    check("History type is pairwise", model.history[0]["type"] == "pairwise")


    delta = PHI_REDUCE - PHI_SUBSTITUTE
    mu_shift = model.mu - mu_before
    check("μ shifted in direction of Δφ",
          np.dot(mu_shift, delta) > 0,
          f"dot product: {np.dot(mu_shift, delta):.4f}")


def test_accept_update():
    print("\n== Accept Update ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    mu_before = model.mu.copy()

    model.update_accept(PHI_REDUCE)

    check("μ changes after accept", not np.allclose(model.mu, mu_before))
    check("t incremented", model.t == 1)
    check("History type is accept", model.history[0]["type"] == "accept")


def test_reject_update():
    print("\n== Reject Update ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    mu_before = model.mu.copy()

    model.update_reject(PHI_SUBSTITUTE)

    check("μ changes after reject", not np.allclose(model.mu, mu_before))
    check("t incremented", model.t == 1)
    check("History type is reject", model.history[0]["type"] == "reject")


def test_edit_update():
    print("\n== Edit Update ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0, alpha_edit=0.5))

    mu_before = model.mu.copy()
    sigma_trace_before = np.trace(model.sigma)

    model.update_edit(PHI_SUBSTITUTE, PHI_REDUCE)

    check("μ changes after edit", not np.allclose(model.mu, mu_before))
    check("Σ trace decreases after edit",
          np.trace(model.sigma) < sigma_trace_before)
    check("t incremented", model.t == 1)
    check("History type is edit", model.history[0]["type"] == "edit")

    delta = PHI_REDUCE - PHI_SUBSTITUTE
    mu_shift = model.mu - mu_before
    check("μ shifted toward edit direction",
          np.dot(mu_shift, delta) > 0)


def test_multiple_updates():
    print("\n== Multiple Sequential Updates ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    for _ in range(5):
        model.update_pairwise(PHI_REDUCE, PHI_SUBSTITUTE)

    check("t = 5 after 5 updates", model.t == 5)
    check("5 history entries", len(model.history) == 5)

    score_reduce = model.score(PHI_REDUCE, safety_margin=0.8)
    score_substitute = model.score(PHI_SUBSTITUTE, safety_margin=0.9)
    check("REDUCE scores higher after 5 preferences",
          score_reduce > score_substitute,
          f"reduce={score_reduce:.3f}, substitute={score_substitute:.3f}")


def test_posterior_symmetry():
    print("\n== Posterior Covariance Symmetry ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    # Run several different update types
    model.update_pairwise(PHI_REDUCE, PHI_SUBSTITUTE)
    model.update_accept(PHI_BARRIER)
    model.update_reject(PHI_SEPARATE)
    model.update_edit(PHI_TRANSFORM, PHI_REDUCE)

    check("Σ remains symmetric",
          np.allclose(model.sigma, model.sigma.T, atol=1e-10),
          f"max asymmetry: {np.max(np.abs(model.sigma - model.sigma.T)):.2e}")

    # Check positive definiteness
    eigenvalues = np.linalg.eigvalsh(model.sigma)
    check("Σ remains positive definite",
          np.all(eigenvalues > 0),
          f"min eigenvalue: {np.min(eigenvalues):.2e}")


# Unit Tests: Scoring Function

def test_scoring_components():
    print("\n== Scoring Components ==")
    model = PreferenceModel(PreferenceConfig(
        sigma_0=2.0, beta=0.3, lam=0.5
    ))

    # At cold start, scoring is dominated by prior and conservative bias
    score = model.score(PHI_REDUCE, safety_margin=0.9)
    check("Score is finite", np.isfinite(score), f"got {score}")

    score_high_sm = model.score(PHI_REDUCE, safety_margin=0.95)
    score_low_sm = model.score(PHI_REDUCE, safety_margin=0.6)
    check("Higher safety margin → higher score",
          score_high_sm > score_low_sm,
          f"high={score_high_sm:.3f}, low={score_low_sm:.3f}")

    # Information gain should be positive
    ig = model.information_gain(PHI_REDUCE)
    check("Information gain is positive", ig > 0, f"got {ig:.4f}")


def test_scoring_after_learning():
    print("\n== Scoring After Learning ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0, beta=0.3, lam=0.5))

    for _ in range(10):
        model.update_pairwise(PHI_REDUCE, PHI_SUBSTITUTE)

    sr = model.score(PHI_REDUCE, safety_margin=0.8)
    ss = model.score(PHI_SUBSTITUTE, safety_margin=0.8)
    check("Learned preference: REDUCE >> SUBSTITUTE",
          sr > ss,
          f"reduce={sr:.3f}, substitute={ss:.3f}")

    ig_after = model.information_gain(PHI_REDUCE)
    fresh = PreferenceModel(PreferenceConfig(sigma_0=2.0))
    ig_before = fresh.information_gain(PHI_REDUCE)
    check("IG decreases after learning",
          ig_after < ig_before,
          f"after={ig_after:.3f}, before={ig_before:.3f}")


def test_rank_candidates():
    print("\n== Rank Candidates ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    for _ in range(5):
        model.update_pairwise(PHI_REDUCE, PHI_SUBSTITUTE)

    features = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM, PHI_BARRIER]
    margins = [0.9, 0.8, 0.7, 0.85]

    ranking = model.rank_candidates(features, margins)
    check("Ranking has correct length", len(ranking) == 4)
    check("All indices unique", len(set(ranking)) == 4)
    reduce_rank = ranking.index(1)
    check("REDUCE ranked highly", reduce_rank <= 1,
          f"ranked {reduce_rank}")


# Unit Tests: Pairwise Selection

def test_pair_selection():
    print("\n== Pairwise Selection ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0, lam=0.5))

    features = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM]
    margins = [0.9, 0.8, 0.7]

    idx_i, idx_j = model.select_pair(features, margins)
    check("Pair indices are valid", 0 <= idx_i < 3 and 0 <= idx_j < 3)
    check("Pair indices are different", idx_i != idx_j)

    ps = model.pair_score(features[idx_i], features[idx_j], margins[idx_i], margins[idx_j])
    check("PairScore is finite", np.isfinite(ps), f"got {ps}")


def test_pair_selection_minimum():
    print("\n== Pair Selection Edge Cases ==")
    model = PreferenceModel()

    features = [PHI_REDUCE, PHI_SUBSTITUTE]
    margins = [0.8, 0.9]
    idx_i, idx_j = model.select_pair(features, margins)
    check("2 candidates → returns (0, 1)", (idx_i, idx_j) == (0, 1))

    try:
        model.select_pair([PHI_REDUCE], [0.8])
        check("1 candidate raises error", False)
    except ValueError:
        check("1 candidate raises error", True)


# Unit Tests: Autonomy Gate

def test_autonomy_gate_cold_start():
    print("\n== Autonomy Gate — Cold Start ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0, epsilon=0.1))

    features = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM]
    mode = model.selection_mode(features)

    # At cold start with high uncertainty, should be pairwise
    check("Cold start → pairwise mode", mode == SelectionMode.PAIRWISE)


def test_autonomy_gate_after_learning():
    print("\n== Autonomy Gate — After Learning ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=1.0, epsilon=0.5))

    features = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM]

    all_candidates = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM, PHI_SEPARATE, PHI_BARRIER]
    for _ in range(10):
        for i in range(len(all_candidates)):
            for j in range(i + 1, len(all_candidates)):
                model.update_pairwise(all_candidates[i], all_candidates[j])

    mode = model.selection_mode(features)
    max_gain = model.max_pair_info_gain(features)
    check("After extensive learning → autonomous mode",
          mode == SelectionMode.AUTONOMOUS,
          f"max_gain={max_gain:.6f}, epsilon={model.config.epsilon}")


def test_autonomy_gate_single_candidate():
    print("\n== Autonomy Gate — Single Candidate ==")
    model = PreferenceModel()
    mode = model.selection_mode([PHI_REDUCE])
    check("Single candidate → autonomous", mode == SelectionMode.AUTONOMOUS)


def test_autonomy_transition():
    print("\n== Autonomy Transition ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=1.0, epsilon=0.5))

    features = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM]
    all_candidates = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM, PHI_SEPARATE, PHI_BARRIER]

    # Track when we transition from pairwise to autonomous
    pairwise_count = 0
    pair_idx = 0
    pairs = [(i, j) for i in range(len(all_candidates)) for j in range(i+1, len(all_candidates))]

    for iteration in range(200):
        mode = model.selection_mode(features)
        if mode == SelectionMode.PAIRWISE:
            pairwise_count += 1
        else:
            break
        i, j = pairs[pair_idx % len(pairs)]
        model.update_pairwise(all_candidates[i], all_candidates[j])
        pair_idx += 1

    check("Transition happens eventually", pairwise_count < 200,
          f"still pairwise after {pairwise_count} iterations")
    predicted = model.predicted_autonomy_time()
    check(f"Transition within reasonable range of O(d/ε) ≈ {predicted:.0f}",
          pairwise_count < predicted * 5,
          f"transitioned at {pairwise_count}")


# Unit Tests: Feature Extraction

def test_feature_extraction():
    print("\n== Feature Extraction ==")

    mock = MockLLMBackend()
    mock.set_response("object_preservation", {
        "object_preservation": 1.0,
        "parameter_modification": 1.0,
        "structural_preservation": 0.9,
        "recipient_interaction_change": 0.2,
        "reasoning": "Grapes were quartered — same object, parameter modified.",
    })

    extractor = FeatureExtractor(mock)
    features = extractor.extract(
        original_command="Give the baby grapes",
        repair_command="Give the baby quartered grapes",
        scene_context="8-month-old baby in high chair",
        safety_margin=0.85,
    )

    check("Feature vector has 6 dimensions", len(features.values) == 6)
    check("φ₁ is deterministic Levenshtein (not from LLM)",
          features.modification_degree > 0.0 and features.modification_degree < 1.0,
          f"got {features.modification_degree:.3f}")
    # "Give the baby grapes" vs "Give the baby quartered grapes" — should be moderate distance
    check("φ₁ reflects moderate change",
          0.1 < features.modification_degree < 0.7,
          f"got {features.modification_degree:.3f}")
    check("φ₄ is injected safety margin", features.safety_margin == 0.85)
    check("φ₂ is object preservation from LLM", features.object_preservation == 1.0)
    check("φ₃ is parameter modification from LLM", features.parameter_modification == 1.0)
    check("All values in [0, 1]",
          all(0.0 <= v <= 1.0 for v in features.values))
    check("Reasoning captured", "quartered" in features.reasoning.lower())


def test_deterministic_phi1():
    print("\n== Deterministic φ₁ (Normalized Levenshtein) ==")

    # Identical commands → 0.0
    check("Identical → 0.0",
          normalized_levenshtein("give grapes", "give grapes") == 0.0)

    # Completely different → high
    dist = normalized_levenshtein("give grapes", "open the door")
    check("Completely different → high distance",
          dist > 0.5, f"got {dist:.3f}")

    # Case insensitive
    check("Case insensitive",
          normalized_levenshtein("Give Grapes", "give grapes") == 0.0)

    # Small edit → small distance
    dist_small = normalized_levenshtein("give grapes", "give quartered grapes")
    check("Small edit → moderate distance",
          0.0 < dist_small < 0.6, f"got {dist_small:.3f}")

    # Empty strings
    check("Both empty → 0.0",
          normalized_levenshtein("", "") == 0.0)
    check("One empty → 1.0",
          normalized_levenshtein("hello", "") == 1.0)

    # φ₁ is NOT LLM-extracted: verify extractor always uses Levenshtein
    mock = MockLLMBackend()
    # Even if LLM returns a modification_degree, it should be ignored
    mock.set_response("object_preservation", {
        "modification_degree": 0.99,  # This should be IGNORED
        "object_preservation": 1.0,
        "parameter_modification": 1.0,
        "structural_preservation": 0.9,
        "recipient_interaction_change": 0.2,
        "reasoning": "test",
    })
    extractor = FeatureExtractor(mock)
    features = extractor.extract("give grapes", "give quartered grapes", "ctx", 0.8)

    expected_phi1 = normalized_levenshtein("give grapes", "give quartered grapes")
    check("φ₁ matches deterministic Levenshtein (LLM value ignored)",
          abs(features.modification_degree - expected_phi1) < 1e-10,
          f"got {features.modification_degree:.4f}, expected {expected_phi1:.4f}")


def test_feature_extraction_parse_failure():
    print("\n== Feature Extraction Parse Failure ==")

    from casper.llm_interface import LLMBackend

    class BadBackend(LLMBackend):
        @property
        def model_name(self) -> str:
            return "bad"
        def generate(self, prompt, temperature=0.7):
            return "NOT JSON"

    extractor = FeatureExtractor(BadBackend())
    features = extractor.extract("cmd original", "cmd repair", "context", safety_margin=0.7)

    check("Parse failure → no crash", True)
    check("φ₁ still deterministic on parse failure",
          features.modification_degree == normalized_levenshtein("cmd original", "cmd repair"),
          f"got {features.modification_degree}")
    check("φ₄ still correct on parse failure", features.safety_margin == 0.7)
    check("Semantic features are 0.5 default",
          features.object_preservation == 0.5 and features.structural_preservation == 0.5)


def test_baseline_features():
    print("\n== Baseline Features ==")
    phi_0 = baseline_features()
    check("Baseline has 6 dimensions", len(phi_0) == FEATURE_DIM)
    check("Baseline φ₁ = 1.0 (max modification)", phi_0[0] == 1.0)
    check("Baseline φ₂ = 0.0 (no object preservation)", phi_0[1] == 0.0)


def test_feature_clamping():
    print("\n== Feature Value Clamping ==")

    mock = MockLLMBackend()
    mock.set_response("object_preservation", {
        "object_preservation": -0.3,      # Out of range
        "parameter_modification": "yes",  # Wrong type
        "structural_preservation": 1.5,   # Out of range
        "recipient_interaction_change": 0.3,
        "reasoning": "Test clamping",
    })

    extractor = FeatureExtractor(mock)
    features = extractor.extract("cmd", "repair", "ctx", safety_margin=0.8)

    check("Out-of-range low clamped to 0.0",
          features.object_preservation == 0.0,
          f"got {features.object_preservation}")
    check("Non-numeric → 0.5 default",
          features.parameter_modification == 0.5,
          f"got {features.parameter_modification}")
    check("Out-of-range high clamped to 1.0",
          features.structural_preservation == 1.0,
          f"got {features.structural_preservation}")


# Unit Tests: Bradley-Terry Probability

def test_preference_probability():
    print("\n== Preference Probability ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    # At prior, probability depends on μ₀
    p = model.preference_probability(PHI_REDUCE, PHI_SUBSTITUTE)
    check("Probability in [0, 1]", 0.0 <= p <= 1.0, f"got {p}")

    # Symmetric: P(A > B) + P(B > A) = 1
    p_ab = model.preference_probability(PHI_REDUCE, PHI_SUBSTITUTE)
    p_ba = model.preference_probability(PHI_SUBSTITUTE, PHI_REDUCE)
    check("P(A>B) + P(B>A) ≈ 1.0",
          abs(p_ab + p_ba - 1.0) < 1e-10,
          f"sum = {p_ab + p_ba}")

    # After training, probability should shift toward preferred
    for _ in range(10):
        model.update_pairwise(PHI_REDUCE, PHI_SUBSTITUTE)

    p_after = model.preference_probability(PHI_REDUCE, PHI_SUBSTITUTE)
    check("P(REDUCE > SUBSTITUTE) increases after training",
          p_after > p, f"before={p:.3f}, after={p_after:.3f}")
    check("P(REDUCE > SUBSTITUTE) > 0.5 after training",
          p_after > 0.5, f"got {p_after:.3f}")


# Unit Tests: Model Reset

def test_model_reset():
    print("\n== Model Reset ==")
    config = PreferenceConfig(sigma_0=2.0)
    model = PreferenceModel(config)
    mu_initial = model.mu.copy()

    for _ in range(5):
        model.update_pairwise(PHI_REDUCE, PHI_SUBSTITUTE)

    check("μ changed after updates", not np.allclose(model.mu, mu_initial))

    model.reset()
    check("μ reset to prior", np.allclose(model.mu, config.mu_0))
    check("t reset to 0", model.t == 0)
    check("History cleared", len(model.history) == 0)
    check("Σ reset to σ₀²I",
          np.allclose(model.sigma, config.sigma_0**2 * np.eye(FEATURE_DIM)))


def test_mu0_copy_safety():
    print("\n== μ₀ Copy Safety ==")
    external_mu = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.0, 0.0, 0.0, 0.0])
    config = PreferenceConfig(mu_0=external_mu)
    model = PreferenceModel(config)

    original_mu = model.mu.copy()

    external_mu[:] = 99.0

    check("Config mu_0 not corrupted",
          not np.allclose(config.mu_0, 99.0),
          f"config.mu_0 = {config.mu_0}")
    check("Model mu not corrupted",
          np.allclose(model.mu, original_mu),
          f"model.mu = {model.mu}")


# Integration: Convergence to Simulated User

def test_convergence():
    """
    Simulate a user with known θ_true and verify the posterior
    converges toward it.
    """
    print("\n== Convergence to Simulated User ==")

    theta_true = np.array([-0.8, 1.5, 0.5, 0.3, 0.4, -0.2, 0.0, 0.0, 0.0, 0.0], dtype=np.float64)

    config = PreferenceConfig(
        sigma_0=2.0,
        mu_0=np.zeros(FEATURE_DIM),  # Uninformative prior
    )
    model = PreferenceModel(config)

    # Simulate 50 pairwise interactions with Bradley-Terry user
    rng = np.random.RandomState(42)
    candidates = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM, PHI_SEPARATE, PHI_BARRIER]

    for _ in range(50):
        # Pick two random candidates
        i, j = rng.choice(len(candidates), size=2, replace=False)
        phi_i, phi_j = candidates[i], candidates[j]

        # Simulated user chooses via Bradley-Terry
        delta = phi_i - phi_j
        p_i = 1.0 / (1.0 + np.exp(-float(theta_true @ delta)))

        if rng.random() < p_i:
            model.update_pairwise(phi_i, phi_j)
        else:
            model.update_pairwise(phi_j, phi_i)

    correlation = np.corrcoef(model.mu, theta_true)[0, 1]
    check("Posterior correlated with θ_true (r > 0.5)",
          correlation > 0.5,
          f"r = {correlation:.3f}")

    check("Highest weight on φ₂ (object preservation)",
          np.argmax(model.mu) == 1,
          f"argmax = {FEATURE_NAMES[np.argmax(model.mu)]}")

    # Check uncertainty decreased
    initial_uncertainty = config.sigma_0**2 * FEATURE_DIM
    final_uncertainty = np.trace(model.sigma)
    check("Uncertainty decreased",
          final_uncertainty < initial_uncertainty * 0.7,
          f"final={final_uncertainty:.3f}, initial={initial_uncertainty:.3f}")


# Integration: Full Pipeline

def build_full_pipeline_mock() -> ScenarioMockBackend:
    """Build a mock with complete scenarios for the full pipeline test."""
    mock = ScenarioMockBackend(seed=42)

    mock.register_scenario(
        scenario_key="give the baby grapes",
        graph_response={
            "entities": [
                {"name": "grapes", "entity_type": "object",
                 "description": "whole grapes, choking hazard"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "grapes", "target": "baby", "relation": "ingestion",
                 "description": "baby eats grapes"},
            ],
        },
        dimension_responses={
            1: {"concern": True, "reasoning": "Choking hazard.",
                "severity": "critical", "specific_harm": "Airway obstruction"},
            2: {"concern": False, "severity": "none", "reasoning": "n/a", "specific_harm": "none"},
            3: {"concern": False, "severity": "none", "reasoning": "n/a", "specific_harm": "none"},
            4: {"concern": False, "severity": "none", "reasoning": "n/a", "specific_harm": "none"},
            5: {"concern": False, "severity": "none", "reasoning": "n/a", "specific_harm": "none"},
            6: {"concern": False, "severity": "none", "reasoning": "n/a", "specific_harm": "none"},
        },
        repair_response={
            "candidates": [
                {"command": "Give the baby quartered grapes",
                 "strategy": "H7", "explanation": "Cut into safe pieces"},
                {"command": "Give the baby mashed banana instead",
                 "strategy": "H1", "explanation": "Safe substitute"},
            ],
        },
    )

    mock.register_scenario(
        scenario_key="quartered grapes",
        graph_response={
            "entities": [
                {"name": "quartered_grapes", "entity_type": "object",
                 "description": "grapes quartered, safe"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "quartered_grapes", "target": "baby",
                 "relation": "ingestion", "description": "safe eating"},
            ],
        },
        dimension_responses={d: {"concern": False, "severity": "none",
                                  "reasoning": "Safe.", "specific_harm": "none"}
                             for d in range(1, 7)},
    )

    mock.register_scenario(
        scenario_key="mashed banana",
        graph_response={
            "entities": [
                {"name": "mashed_banana", "entity_type": "object",
                 "description": "mashed banana, safe"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "mashed_banana", "target": "baby",
                 "relation": "ingestion", "description": "safe eating"},
            ],
        },
        dimension_responses={d: {"concern": False, "severity": "none",
                                  "reasoning": "Safe.", "specific_harm": "none"}
                             for d in range(1, 7)},
    )

    mock.register_scenario(
        scenario_key="give the baby water",
        graph_response={
            "entities": [
                {"name": "water", "entity_type": "object",
                 "description": "room temperature water in sippy cup"},
                {"name": "baby", "entity_type": "person",
                 "description": "8-month-old infant"},
            ],
            "relationships": [
                {"source": "water", "target": "baby", "relation": "ingestion",
                 "description": "baby drinks water from sippy cup"},
            ],
        },
        dimension_responses={d: {"concern": False, "severity": "none",
                                  "reasoning": "Safe.", "specific_harm": "none"}
                             for d in range(1, 7)},
    )

    mock.set_response("object_preservation", {
        "object_preservation": 0.5,
        "parameter_modification": 0.5,
        "structural_preservation": 0.5,
        "recipient_interaction_change": 0.5,
        "reasoning": "Default feature extraction",
    })

    return mock


def test_full_pipeline_safe_command():
    print("\n== Full Pipeline — Safe Command ==")
    mock = build_full_pipeline_mock()
    pipeline = CasperPipeline(
        llm=mock,
        safety_config=SafetyConfig(),
    )

    result = pipeline.process_command(
        "Give the baby water",
        "8-month-old baby in high chair. Sippy cup available.",
    )

    check("Safe command → SAFE_EXECUTE", result.outcome == CommandOutcome.SAFE_EXECUTE)
    check("Safety result present", result.safety_result is not None)
    check("Safety result is safe", result.safety_result.is_safe)


def test_full_pipeline_unsafe_command():
    print("\n== Full Pipeline — Unsafe Command ==")
    mock = build_full_pipeline_mock()
    pipeline = CasperPipeline(
        llm=mock,
        safety_config=SafetyConfig(),
        preference_config=PreferenceConfig(sigma_0=2.0, epsilon=0.1),
    )

    result = pipeline.process_command(
        "Give the baby grapes",
        "8-month-old baby in high chair.",
    )

    check("Unsafe command → repair outcome",
          result.outcome in (CommandOutcome.REPAIR_PAIRWISE, CommandOutcome.REPAIR_AUTONOMOUS))
    check("Original safety result is unsafe", not result.safety_result.is_safe)
    check("Safe candidates found", len(result.safe_candidates) >= 1,
          f"got {len(result.safe_candidates)}")
    check("Selection mode determined", result.selection_mode is not None)

    if result.outcome == CommandOutcome.REPAIR_PAIRWISE:
        check("Pair provided", result.pair is not None)
        check("Pair has two candidates",
              result.pair is not None and len(result.pair) == 2)
        pipeline.receive_pairwise_feedback(
            chosen=result.pair[0],
            rejected=result.pair[1],
        )
        check("Feedback processed (t incremented)", pipeline.preference.t == 1)

    elif result.outcome == CommandOutcome.REPAIR_AUTONOMOUS:
        check("Selected candidate provided", result.selected_candidate is not None)
        pipeline.receive_accept_feedback(result.selected_candidate)
        check("Accept feedback processed", pipeline.preference.t == 1)


def test_full_pipeline_feedback_loop():
    print("\n== Full Pipeline — Multi-Interaction Feedback Loop ==")
    mock = build_full_pipeline_mock()
    pipeline = CasperPipeline(
        llm=mock,
        safety_config=SafetyConfig(),
        preference_config=PreferenceConfig(sigma_0=2.0, epsilon=0.1),
    )

    for i in range(5):
        result = pipeline.process_command(
            "Give the baby grapes",
            "8-month-old baby in high chair.",
        )

        if result.outcome == CommandOutcome.REPAIR_PAIRWISE and result.pair:
            pipeline.receive_pairwise_feedback(
                chosen=result.pair[0],
                rejected=result.pair[1],
            )
        elif result.outcome == CommandOutcome.REPAIR_AUTONOMOUS and result.selected_candidate:
            pipeline.receive_accept_feedback(result.selected_candidate)

    check("Multiple interactions processed",
          pipeline.preference.t >= 3,
          f"t = {pipeline.preference.t}")
    check("Interaction log populated",
          len(pipeline.interaction_log) >= 3)

    state = pipeline.system_state()
    check("System state has posterior", "preference_posterior" in state)
    check("System state has interaction_count", state["interaction_count"] >= 3)


# Unit Tests: Diagnostics

def test_diagnostics():
    print("\n== Diagnostics ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    summary = model.posterior_summary()
    check("Summary has t", "t" in summary)
    check("Summary has mu", "mu" in summary)
    check("Summary has sigma_diag", "sigma_diag" in summary)
    check("Summary is JSON serializable",
          json.dumps(summary) is not None)

    ws = model.weight_summary()
    check("Weight summary is string", isinstance(ws, str))
    check("Weight summary mentions features",
          "modification_degree" in ws)

    t_auto = model.predicted_autonomy_time()
    check("Autonomy time is positive", t_auto > 0, f"got {t_auto}")
    check("Autonomy time ≈ d/ε = 60",
          abs(t_auto - 60.0) < 1.0,
          f"got {t_auto}")



def test_haddon_inference():
    print("\n== Haddon Strategy Inference ==")

    f_h1 = StrategyFeatures(
        values=make_features([0.8, 0.0, 0.0, 0.9, 0.3, 0.7]),
        original_command="", repair_command="",
    )
    check("H1 Substitute detected", f_h1.infer_haddon_strategy() == "H1")

    f_h2 = StrategyFeatures(
        values=make_features([0.3, 1.0, 1.0, 0.8, 0.9, 0.2]),
        original_command="", repair_command="",
    )
    check("H2 Reduce detected", f_h2.infer_haddon_strategy() == "H2")

    import numpy as np
    rng = np.random.RandomState(123)
    for _ in range(20):
        vals = rng.random(FEATURE_DIM).tolist()
        f = StrategyFeatures(values=make_features(vals), original_command="", repair_command="")
        result = f.infer_haddon_strategy()
        check(f"Random features → valid strategy ({result})",
              result in ("H1", "H2", "H3", "H4", "H5", "H6", "H7"))


# Unit Tests: Numerical Stability

def test_numerical_stability():
    print("\n== Numerical Stability ==")
    model = PreferenceModel(PreferenceConfig(sigma_0=2.0))

    rng = np.random.RandomState(99)
    candidates = [PHI_SUBSTITUTE, PHI_REDUCE, PHI_TRANSFORM, PHI_SEPARATE, PHI_BARRIER]
    for i in range(200):
        a, b = rng.choice(len(candidates), size=2, replace=False)
        model.update_pairwise(candidates[a], candidates[b])

    check("μ finite after 200 updates", np.all(np.isfinite(model.mu)),
          f"mu={model.mu}")
    check("Σ finite after 200 updates", np.all(np.isfinite(model.sigma)),
          f"max={np.max(np.abs(model.sigma)):.2e}")
    check("Σ symmetric after 200 updates",
          np.allclose(model.sigma, model.sigma.T, atol=1e-10))
    eigenvalues = np.linalg.eigvalsh(model.sigma)
    check("Σ positive definite after 200 updates",
          np.all(eigenvalues > 0),
          f"min eigenvalue={np.min(eigenvalues):.2e}")

    model2 = PreferenceModel(PreferenceConfig(sigma_0=2.0))
    for i in range(50):
        model2.update_pairwise(candidates[i % 5], candidates[(i+1) % 5])
        model2.update_accept(candidates[i % 5])
        model2.update_reject(candidates[(i+2) % 5])
        model2.update_edit(candidates[i % 5], candidates[(i+3) % 5])

    check("μ finite after mixed 200 updates", np.all(np.isfinite(model2.mu)))
    check("Σ finite after mixed 200 updates", np.all(np.isfinite(model2.sigma)))
    check("Σ PD after mixed 200 updates",
          np.all(np.linalg.eigvalsh(model2.sigma) > 0))


# Integration: Error Boundary

def test_error_boundary():
    print("\n== Error Boundary ==")

    mock = build_full_pipeline_mock()
    pipeline = CasperPipeline(
        llm=mock,
        safety_config=SafetyConfig(),
    )

    original_evaluate = pipeline.safety.evaluate
    def exploding_evaluate(command, scene_context):
        raise RuntimeError("Internal pipeline crash!")
    pipeline.safety.evaluate = exploding_evaluate

    result = pipeline.process_command("give baby grapes", "baby in chair")
    check("Error caught → ERROR outcome", result.outcome == CommandOutcome.ERROR)
    check("Error message captured", result.error_message is not None)
    check("Error message contains details",
          result.error_message is not None and "crash" in result.error_message.lower())
    check("Safety result is conservative (unsafe)", not result.safety_result.is_safe)

    pipeline.safety.evaluate = original_evaluate
    result2 = pipeline.process_command("Give the baby water", "baby in chair")
    check("Pipeline recovers after error", result2.outcome == CommandOutcome.SAFE_EXECUTE)



def test_serialization():
    print("\n== Serialization ==")
    mock = build_full_pipeline_mock()
    pipeline = CasperPipeline(
        llm=mock,
        safety_config=SafetyConfig(),
    )

    result_safe = pipeline.process_command("Give the baby water", "baby in chair")
    d = result_safe.to_dict()
    check("to_dict has outcome", d["outcome"] == "safe_execute")
    check("to_dict has safety_result", "is_safe" in d["safety_result"])
    check("to_dict is JSON serializable", json.dumps(d) is not None)

    result_unsafe = pipeline.process_command("Give the baby grapes", "baby in chair")
    d2 = result_unsafe.to_dict()
    check("Unsafe to_dict has outcome", d2["outcome"] in ("repair_pairwise", "repair_autonomous"))
    check("Unsafe to_dict has safe_candidates", "safe_candidates" in d2)
    check("Unsafe to_dict is JSON serializable", json.dumps(d2) is not None)

    if result_unsafe.safe_candidates:
        cd = result_unsafe.safe_candidates[0].to_dict()
        check("ScoredCandidate to_dict has command", "command" in cd)
        check("ScoredCandidate to_dict has features", "features" in cd)
        check("ScoredCandidate to_dict has score", "score" in cd)
        check("ScoredCandidate to_dict is JSON serializable", json.dumps(cd) is not None)


# Integration: Edit Feedback Safety Check

def test_edit_feedback_safety():
    print("\n== Edit Feedback Safety Check ==")
    mock = build_full_pipeline_mock()
    pipeline = CasperPipeline(
        llm=mock,
        safety_config=SafetyConfig(),
    )

    # Get an unsafe command result with candidates
    result = pipeline.process_command("Give the baby grapes", "baby in chair")
    if not result.safe_candidates:
        check("Has candidates for edit test", False, "No candidates available")
        return

    proposed = result.safe_candidates[0]

    edit_result = pipeline.receive_edit_feedback(
        proposed=proposed,
        edited_command="Give the baby mashed banana instead",
        scene_context="baby in chair",
        original_command="Give the baby grapes",
    )
    check("Edit returns SafetyResult", edit_result is not None)
    check("Safe edit → is_safe", edit_result.is_safe if edit_result else False)
    check("Preference updated from edit", pipeline.preference.t >= 1)

    edit_log = [e for e in pipeline.interaction_log if e["type"] == "edit"]
    check("Edit logged", len(edit_log) >= 1)
    check("Edit log has safety field", "edit_is_safe" in edit_log[0])


# Run All Tests

if __name__ == "__main__":
    print("=" * 60)
    print("CASPER Preference Subsystem — Test Suite")
    print("=" * 60)

    # Unit: posterior updates
    test_pairwise_update()
    test_accept_update()
    test_reject_update()
    test_edit_update()
    test_multiple_updates()
    test_posterior_symmetry()

    # Unit: scoring
    test_scoring_components()
    test_scoring_after_learning()
    test_rank_candidates()

    # Unit: pair selection
    test_pair_selection()
    test_pair_selection_minimum()

    # Unit: autonomy gate
    test_autonomy_gate_cold_start()
    test_autonomy_gate_after_learning()
    test_autonomy_gate_single_candidate()
    test_autonomy_transition()

    # Unit: feature extraction
    test_feature_extraction()
    test_deterministic_phi1()
    test_feature_extraction_parse_failure()
    test_baseline_features()
    test_feature_clamping()

    # Unit: Bradley-Terry
    test_preference_probability()

    # Unit: reset
    test_model_reset()
    test_mu0_copy_safety()

    # Unit: diagnostics
    test_diagnostics()

    # Unit: Haddon inference
    test_haddon_inference()

    # Unit: numerical stability
    test_numerical_stability()

    # Integration: convergence
    test_convergence()

    # Integration: full pipeline
    test_full_pipeline_safe_command()
    test_full_pipeline_unsafe_command()
    test_full_pipeline_feedback_loop()

    # Integration: error boundary
    test_error_boundary()

    # Integration: serialization
    test_serialization()

    # Integration: edit safety
    test_edit_feedback_safety()

    print("\n" + "=" * 60)
    print(f"Results: {passed}/{total} passed, {failed} failed")
    print("=" * 60)

    if failed > 0:
        sys.exit(1)
