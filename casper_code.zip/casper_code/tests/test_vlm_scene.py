"""Tests for VLM scene perception (casper.vlm_scene)."""

import json
import pytest

from casper.vlm_scene import perceive_scene, _parse_vlm_response
from casper.llm_interface import LLMBackend
from casper.scene_provider import SceneProvider


# ── Mock VLM backend ──────────────────────────────────────────────

class MockVLMBackend(LLMBackend):
    """Mock vision-capable backend that returns canned VLM JSON."""

    def __init__(self, response_json: dict):
        self._response = json.dumps(response_json)

    @property
    def model_name(self) -> str:
        return "mock-vlm"

    @property
    def supports_vision(self) -> bool:
        return True

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        return self._response

    def generate_with_image(
        self, prompt: str, image: str | bytes, temperature: float = 0.7,
    ) -> str:
        return self._response


class MockNonVisionBackend(LLMBackend):
    @property
    def model_name(self) -> str:
        return "mock-text-only"

    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        return "{}"


SAMPLE_VLM_RESPONSE = {
    "objects": [
        {
            "name": "Knife",
            "category": "utensil",
            "properties": {
                "pickupable": True,
                "sharp": True,
                "hazard": "cut",
            },
        },
        {
            "name": "Apple",
            "category": "food",
            "properties": {
                "pickupable": True,
                "sliceable": True,
                "hazard": "null",
            },
        },
        {
            "name": "StoveBurner",
            "category": "appliance",
            "properties": {
                "toggleable": True,
                "hot_when_on": True,
                "hazard": "burn",
            },
        },
    ],
    "room_type": "Kitchen",
    "scene_summary": "A kitchen with a knife, apple, and stove.",
    "safety_notes": "Knife is near the edge of the counter.",
}


# ── Tests ─────────────────────────────────────────────────────────

def test_perceive_scene_basic():
    backend = MockVLMBackend(SAMPLE_VLM_RESPONSE)
    scene = perceive_scene(backend, b"fake_jpeg_bytes", context_hint="kitchen")

    assert scene.source == "vlm"
    assert scene.room_type == "Kitchen"
    assert len(scene.objects) == 3
    assert "Knife" in scene.object_names
    assert "Apple" in scene.object_names
    assert "StoveBurner" in scene.object_names


def test_vlm_object_properties():
    backend = MockVLMBackend(SAMPLE_VLM_RESPONSE)
    scene = perceive_scene(backend, b"fake")

    knife = next(o for o in scene.objects if o.name == "Knife")
    assert knife.is_hazardous
    assert knife.hazard_type == "cut"
    assert knife.properties.get("sharp") is True
    assert knife.properties.get("pickupable") is True

    stove = next(o for o in scene.objects if o.name == "StoveBurner")
    assert stove.hazard_type == "burn"
    assert stove.properties.get("hot_when_on") is True


def test_vlm_null_hazard_excluded_for_unknown_object():
    """VLM hazard="null" is excluded; but known objects still get DB hazards."""
    response = {
        "objects": [
            {"name": "Widget", "category": "object", "properties": {"hazard": "null"}},
        ],
        "room_type": "Room",
        "scene_summary": "A widget.",
    }
    backend = MockVLMBackend(response)
    scene = perceive_scene(backend, b"fake")

    widget = scene.objects[0]
    assert not widget.is_hazardous
    assert "hazard" not in widget.properties


def test_vlm_known_object_enrichment():
    """Known objects get missing properties merged from _OBJECT_PROPERTIES."""
    response = {
        "objects": [
            {"name": "Egg", "category": "food", "properties": {"pickupable": True}},
        ],
        "room_type": "Kitchen",
        "scene_summary": "An egg.",
    }
    backend = MockVLMBackend(response)
    scene = perceive_scene(backend, b"fake")

    egg = scene.objects[0]
    assert egg.properties.get("breakable") is True
    assert egg.properties.get("food") is True
    assert egg.hazard_type == "choking"


def test_parse_markdown_wrapped_json():
    raw = '```json\n' + json.dumps(SAMPLE_VLM_RESPONSE) + '\n```'
    scene = _parse_vlm_response(raw)
    assert len(scene.objects) == 3
    assert scene.room_type == "Kitchen"


def test_parse_invalid_json():
    scene = _parse_vlm_response("not json at all")
    assert scene.source == "vlm"
    assert len(scene.objects) == 0
    assert "parse error" in scene.description.lower()


def test_non_vision_backend_raises():
    backend = MockNonVisionBackend()
    with pytest.raises(NotImplementedError):
        perceive_scene(backend, b"fake")


def test_scene_provider_load_from_image():
    backend = MockVLMBackend(SAMPLE_VLM_RESPONSE)
    provider = SceneProvider(vlm_backend=backend, force_cache=True)

    scene = provider.load_scene_from_image(
        image=b"fake_jpeg",
        scene_id="test_kitchen",
        context_hint="kitchen",
    )
    assert scene.scene_id == "test_kitchen"
    assert scene.source == "vlm"
    assert len(scene.objects) == 3


def test_scene_provider_no_vlm_raises():
    provider = SceneProvider(force_cache=True)
    with pytest.raises(ValueError, match="No VLM backend"):
        provider.load_scene_from_image(image=b"fake")


def test_scene_context_from_vlm():
    backend = MockVLMBackend(SAMPLE_VLM_RESPONSE)
    scene = perceive_scene(backend, b"fake")
    ctx = scene.scene_context
    assert "Kitchen" in ctx
    assert "Knife" in ctx
    assert "hazard: cut" in ctx


# ── VLMCasperAdapter Tests ───────────────────────────────────────

from evaluation.scene_adapters import VLMCasperAdapter


def test_vlm_adapter_basic():
    backend = MockVLMBackend(SAMPLE_VLM_RESPONSE)
    scene = perceive_scene(backend, b"fake")
    adapter = VLMCasperAdapter()
    ctx = adapter.adapt(scene)

    assert ctx.room_type == "Kitchen"
    assert "Knife" in ctx.entities
    assert "Apple" in ctx.entities
    assert "StoveBurner" in ctx.entities
    assert ctx.prompt_context
    assert ctx.scene_id.startswith("vlm_")


def test_vlm_adapter_properties():
    backend = MockVLMBackend(SAMPLE_VLM_RESPONSE)
    scene = perceive_scene(backend, b"fake")
    adapter = VLMCasperAdapter()
    ctx = adapter.adapt(scene)

    assert "Knife" in ctx.properties
    assert ctx.properties["Knife"].get("sharp") is True
    assert ctx.properties["Knife"].get("hazard") == "cut"


def test_vlm_adapter_relations():
    backend = MockVLMBackend(SAMPLE_VLM_RESPONSE)
    scene = perceive_scene(backend, b"fake")
    adapter = VLMCasperAdapter()
    ctx = adapter.adapt(scene)

    assert len(ctx.relations) > 0
    near_rels = [r for r in ctx.relations if r["relation"] == "NEAR"]
    hazard_sources = {r["source"] for r in near_rels}
    assert hazard_sources & {"Knife", "StoveBurner"}


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
