"""
Tests for the CASPER Evaluation Framework
==========================================

Uses unittest (stdlib). Run with:
    python -m unittest tests.test_evaluation -v

"""

import unittest
import numpy as np

from casper.feature_extraction import FEATURE_DIM


# Simulated User Tests

from evaluation.simulated_user import (
    SimulatedUser,
    SimulatedUserFactory,
    UserProfile,
    ALL_PROFILES,
    CONSERVATIVE_PARENT,
    MINIMAL_CHANGE,
    OBJECT_ATTACHED,
    PRAGMATIC,
    compute_pairwise_probability,
    _stable_sigmoid,
)


class TestUserProfiles(unittest.TestCase):

    def test_all_profiles_defined(self):
        self.assertEqual(len(ALL_PROFILES), 7)

    def test_all_profiles_are_user_profiles(self):
        for p in ALL_PROFILES:
            self.assertIsInstance(p, UserProfile)

    def test_profile_theta_dimensionality(self):
        for p in ALL_PROFILES:
            self.assertEqual(len(p.theta_true), FEATURE_DIM)

    def test_profiles_have_positive_beta(self):
        for p in ALL_PROFILES:
            self.assertGreater(p.default_beta, 0)

    def test_profiles_are_distinct(self):
        for i in range(len(ALL_PROFILES)):
            for j in range(i + 1, len(ALL_PROFILES)):
                self.assertNotEqual(
                    ALL_PROFILES[i].theta_true,
                    ALL_PROFILES[j].theta_true,
                )

    def test_conservative_parent_prioritizes_safety(self):
        theta = np.array(CONSERVATIVE_PARENT.theta_true)
        self.assertEqual(np.argmax(theta), 3)

    def test_object_attached_dominant_phi2(self):
        theta = np.array(OBJECT_ATTACHED.theta_true)
        self.assertEqual(np.argmax(theta), 1)

    def test_pragmatic_near_uniform(self):
        theta = np.array(PRAGMATIC.theta_true)
        self.assertLess(np.max(np.abs(theta)), 0.5)


class TestSimulatedUser(unittest.TestCase):

    def setUp(self):
        self.user = SimulatedUser(
            CONSERVATIVE_PARENT, beta_temp=0.3,
            rng=np.random.default_rng(42),
        )

    def test_creation(self):
        self.assertEqual(self.user.name, "Conservative Parent")
        self.assertAlmostEqual(self.user.beta_temp, 0.3)
        self.assertEqual(len(self.user.theta_true), FEATURE_DIM)

    def test_invalid_beta(self):
        with self.assertRaises(ValueError):
            SimulatedUser(CONSERVATIVE_PARENT, beta_temp=-0.1)

    def test_invalid_theta_dim(self):
        bad_profile = UserProfile(
            name="bad", theta_true=(1.0, 2.0), description="wrong"
        )
        with self.assertRaises(ValueError):
            SimulatedUser(bad_profile)

    def test_true_utility(self):
        features = np.array([0.5, 1.0, 0.5, 0.8, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0])
        expected = float(self.user.theta_true @ features)
        self.assertAlmostEqual(self.user.true_utility(features), expected)

    def test_true_utility_wrong_shape(self):
        with self.assertRaises(ValueError):
            self.user.true_utility(np.array([1.0, 2.0]))

    def test_oracle_select_picks_highest_utility(self):
        fvs = [
            np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.0, 0.0, 0.0, 0.0]),
            np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            np.array([0.9, 0.9, 0.9, 0.1, 0.9, 0.9, 0.0, 0.0, 0.0, 0.0]),
        ]
        idx = self.user.oracle_select(fvs)
        utilities = [self.user.true_utility(f) for f in fvs]
        self.assertEqual(idx, int(np.argmax(utilities)))

    def test_oracle_select_empty_raises(self):
        with self.assertRaises(ValueError):
            self.user.oracle_select([])

    def test_choose_pairwise_returns_0_or_1(self):
        fi = np.array([0.5, 1.0, 0.5, 0.8, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0])
        fj = np.array([0.3, 0.0, 0.3, 0.5, 0.3, 0.5, 0.0, 0.0, 0.0, 0.0])
        for _ in range(50):
            c = self.user.choose_pairwise(fi, fj)
            self.assertIn(c, (0, 1))

    def test_low_beta_near_deterministic(self):
        user = SimulatedUser(
            CONSERVATIVE_PARENT, beta_temp=0.01,
            rng=np.random.default_rng(42),
        )
        fi = np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        fj = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        choices = [user.choose_pairwise(fi, fj) for _ in range(100)]
        self.assertGreaterEqual(sum(c == 0 for c in choices), 99)

    def test_high_beta_near_random(self):
        user = SimulatedUser(
            CONSERVATIVE_PARENT, beta_temp=100.0,
            rng=np.random.default_rng(42),
        )
        fi = np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        fj = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        choices = [user.choose_pairwise(fi, fj) for _ in range(1000)]
        ratio = sum(c == 0 for c in choices) / 1000
        self.assertGreater(ratio, 0.35)
        self.assertLess(ratio, 0.65)

    def test_choose_pairwise_deterministic(self):
        fi = np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        fj = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        self.assertEqual(self.user.choose_pairwise_deterministic(fi, fj), 0)
        self.assertEqual(self.user.choose_pairwise_deterministic(fj, fi), 1)

    def test_choose_pairwise_deterministic_tie(self):
        f = np.array([0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.0, 0.0, 0.0, 0.0])
        self.assertEqual(self.user.choose_pairwise_deterministic(f, f), 0)

    def test_accept_reject_bias(self):
        good = np.array([0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        bad = np.array([1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0])
        accepts_good = sum(self.user.accept_reject(good) for _ in range(100))
        accepts_bad = sum(self.user.accept_reject(bad) for _ in range(100))
        self.assertGreater(accepts_good, accepts_bad)

    def test_rank_candidates(self):
        fvs = [
            np.array([0.9, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            np.array([0.0, 1.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
        ]
        ranking = self.user.rank_candidates(fvs)
        utilities = [self.user.true_utility(f) for f in fvs]
        expected = sorted(range(3), key=lambda i: utilities[i], reverse=True)
        self.assertEqual(ranking, expected)

    def test_serialization(self):
        d = self.user.to_dict()
        self.assertEqual(d["profile_name"], "Conservative Parent")
        self.assertEqual(len(d["theta_true"]), FEATURE_DIM)


class TestSimulatedUserFactory(unittest.TestCase):

    def test_create_single(self):
        factory = SimulatedUserFactory(seed=42)
        user = factory.create(CONSERVATIVE_PARENT)
        self.assertIsInstance(user, SimulatedUser)

    def test_create_all_profiles(self):
        factory = SimulatedUserFactory(seed=42)
        users = factory.create_all_profiles()
        self.assertEqual(len(users), 7)

    def test_create_noise_sweep(self):
        factory = SimulatedUserFactory(seed=42)
        betas = [0.1, 0.5, 1.0, 2.0]
        users = factory.create_noise_sweep(CONSERVATIVE_PARENT, betas)
        self.assertEqual(len(users), 4)
        for u, b in zip(users, betas):
            self.assertEqual(u.beta_temp, b)

    def test_reproducibility(self):
        f1 = SimulatedUserFactory(seed=42)
        f2 = SimulatedUserFactory(seed=42)
        u1 = f1.create(CONSERVATIVE_PARENT)
        u2 = f2.create(CONSERVATIVE_PARENT)
        fi = np.array([0.5, 1.0, 0.5, 0.8, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0])
        fj = np.array([0.3, 0.0, 0.3, 0.5, 0.3, 0.5, 0.0, 0.0, 0.0, 0.0])
        c1 = [u1.choose_pairwise(fi, fj) for _ in range(20)]
        c2 = [u2.choose_pairwise(fi, fj) for _ in range(20)]
        self.assertEqual(c1, c2)


class TestBradleyTerryProbability(unittest.TestCase):

    def test_equal_features_give_50_50(self):
        theta = np.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        f = np.array([0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        p = compute_pairwise_probability(theta, f, f, beta_temp=1.0)
        self.assertAlmostEqual(p, 0.5)

    def test_probabilities_sum_to_one(self):
        theta = np.array([1.0, -0.5, 0.3, 0.8, 0.2, -0.1, 0.0, 0.0, 0.0, 0.0])
        fi = np.array([0.5, 1.0, 0.5, 0.8, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0])
        fj = np.array([0.3, 0.0, 0.3, 0.5, 0.3, 0.5, 0.0, 0.0, 0.0, 0.0])
        p_ij = compute_pairwise_probability(theta, fi, fj)
        p_ji = compute_pairwise_probability(theta, fj, fi)
        self.assertAlmostEqual(p_ij + p_ji, 1.0)


class TestSigmoid(unittest.TestCase):

    def test_sigmoid_at_zero(self):
        self.assertAlmostEqual(_stable_sigmoid(0.0), 0.5)

    def test_sigmoid_large_positive(self):
        self.assertAlmostEqual(_stable_sigmoid(100.0), 1.0, places=10)

    def test_sigmoid_large_negative(self):
        self.assertAlmostEqual(_stable_sigmoid(-100.0), 0.0, places=10)

    def test_sigmoid_symmetry(self):
        for x in [0.5, 1.0, 3.0, 10.0]:
            self.assertAlmostEqual(
                _stable_sigmoid(x) + _stable_sigmoid(-x), 1.0
            )

    def test_no_overflow(self):
        self.assertTrue(0.0 <= _stable_sigmoid(1000.0) <= 1.0)
        self.assertTrue(0.0 <= _stable_sigmoid(-1000.0) <= 1.0)



# Baselines Tests

from evaluation.baselines import (
    RandomBanditStrategy,
    GreedyBanditStrategy,
    ThompsonSamplingStrategy,
    CasperStrategy,
)


class TestBaselines(unittest.TestCase):

    def _fvs_and_params(self):
        fvs = [np.random.default_rng(i).random(FEATURE_DIM) for i in range(5)]
        sms = [0.85] * 5
        mu = np.zeros(FEATURE_DIM)
        sigma = np.eye(FEATURE_DIM)
        return fvs, sms, mu, sigma

    def test_random_uniform(self):
        s = RandomBanditStrategy(rng=np.random.default_rng(42))
        fvs, sms, mu, sigma = self._fvs_and_params()
        counts = [0] * 5
        for _ in range(1000):
            counts[s.select(fvs, sms, mu, sigma)] += 1
        for c in counts:
            self.assertGreater(c, 100)
            self.assertLess(c, 300)

    def test_greedy_selects_highest(self):
        s = GreedyBanditStrategy()
        fvs = [
            np.array([0.0, 0.0, 0.0, 0.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            np.array([0.0, 0.0, 0.0, 0.9, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            np.array([0.0, 0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
        ]
        mu = np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        self.assertEqual(s.select(fvs, [0.85]*3, mu, np.eye(FEATURE_DIM)), 1)

    def test_thompson_valid_index(self):
        s = ThompsonSamplingStrategy(rng=np.random.default_rng(42))
        fvs, sms, mu, sigma = self._fvs_and_params()
        for _ in range(50):
            idx = s.select(fvs, sms, mu, sigma)
            self.assertTrue(0 <= idx < 5)

    def test_casper_select_pair_distinct(self):
        s = CasperStrategy()
        fvs, sms, mu, sigma = self._fvs_and_params()
        i, j = s.select_pair(fvs, sms, mu, sigma)
        self.assertNotEqual(i, j)


# Experiments Tests

from evaluation.experiments import (
    ExperimentConfig,
    TrialResult,
    run_trial,
    _laplace_update,
)


class TestLaplaceUpdate(unittest.TestCase):

    def test_mean_moves_toward_chosen(self):
        mu = np.zeros(FEATURE_DIM)
        sigma = np.eye(FEATURE_DIM)
        chosen = np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        rejected = np.zeros(FEATURE_DIM)
        mu_new, _ = _laplace_update(mu, sigma, chosen, rejected)
        self.assertGreater(mu_new[3], mu[3])

    def test_covariance_contracts(self):
        mu = np.zeros(FEATURE_DIM)
        sigma = 4.0 * np.eye(FEATURE_DIM)
        chosen = np.full(FEATURE_DIM, 0.5)
        rejected = np.zeros(FEATURE_DIM)
        _, sigma_new = _laplace_update(mu, sigma, chosen, rejected)
        self.assertLess(np.trace(sigma_new), np.trace(sigma))

    def test_covariance_symmetric(self):
        mu = np.array([0.5, -0.3, 0.2, 0.8, 0.1, -0.4, 0.0, 0.0, 0.0, 0.0])
        sigma = 2.0 * np.eye(FEATURE_DIM)
        chosen = np.array([0.3, 0.7, 0.1, 0.9, 0.4, 0.2, 0.0, 0.0, 0.0, 0.0])
        rejected = np.array([0.8, 0.2, 0.6, 0.3, 0.9, 0.7, 0.0, 0.0, 0.0, 0.0])
        _, sigma_new = _laplace_update(mu, sigma, chosen, rejected)
        np.testing.assert_allclose(sigma_new, sigma_new.T, atol=1e-10)

    def test_covariance_positive_definite(self):
        mu = np.zeros(FEATURE_DIM)
        sigma = np.eye(FEATURE_DIM)
        chosen = np.array([0.5, 1.0, 0.5, 0.8, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0])
        rejected = np.array([0.3, 0.0, 0.3, 0.5, 0.3, 0.5, 0.0, 0.0, 0.0, 0.0])
        for _ in range(20):
            mu, sigma = _laplace_update(mu, sigma, chosen, rejected)
        for ev in np.linalg.eigvalsh(sigma):
            self.assertGreater(ev, 0)




# Benchmark Results & Cache Validation Tests

from evaluation.benchmark_results import TaskBenchmarkResult
from evaluation.candidate_cache import CachedScenario, CandidateCache, CacheProvenance


def _make_result(**overrides) -> TaskBenchmarkResult:
    """Factory for a valid TaskBenchmarkResult."""
    defaults = dict(
        task_id="test-001", split="unsafe_detailed",
        hazard_category="thermal", scene_name="FloorPlan1",
        command="put knife in toaster", scene_context="kitchen scene",
        ground_truth_safe=False, pipeline_detected_unsafe=True,
        flagged_dimensions=["D1"], safety_margin=0.8,
        total_candidates_generated=5, rejected_lint=1,
        rejected_lint_details=[], rejected_screen=1,
        rejected_screen_details=[], rejected_safety=1,
        rejected_safety_details=[], safe_candidates=2,
        repair_commands=["cmd1", "cmd2"],
        repair_strategies=["remove", "substitute"],
        repair_action_plans=[[{"verb": "put", "obj": "a", "receptacle": "b"}]] * 2,
        feature_vectors=[[0.1] * FEATURE_DIM, [0.2] * FEATURE_DIM],
        safety_margins=[0.9, 0.85],
    )
    defaults.update(overrides)
    return TaskBenchmarkResult(**defaults)


class TestBenchmarkResultValidation(unittest.TestCase):

    def test_valid_result_passes(self):
        r = _make_result()
        self.assertEqual(r.validate(), [])

    def test_mismatched_repair_commands(self):
        r = _make_result(safe_candidates=2, repair_commands=["cmd1"])
        errors = r.validate()
        self.assertTrue(any("repair_commands" in e for e in errors))

    def test_mismatched_strategies(self):
        r = _make_result(repair_strategies=["remove"])
        errors = r.validate()
        self.assertTrue(any("repair_strategies" in e for e in errors))

    def test_mismatched_feature_vectors(self):
        r = _make_result(feature_vectors=[[0.1] * FEATURE_DIM])
        errors = r.validate()
        self.assertTrue(any("feature_vectors" in e for e in errors))

    def test_gate_sum_exceeds_total(self):
        r = _make_result(
            total_candidates_generated=2,
            rejected_lint=1, rejected_screen=1,
            rejected_safety=1, safe_candidates=2,
        )
        errors = r.validate()
        self.assertTrue(any("gate outputs" in e for e in errors))

    def test_inconsistent_feature_dims(self):
        r = _make_result(
            feature_vectors=[[0.1] * FEATURE_DIM, [0.2] * 5],
        )
        errors = r.validate()
        self.assertTrue(any("inconsistent" in e for e in errors))

    def test_to_cache_entry_roundtrip(self):
        r = _make_result()
        cached = r.to_cache_entry()
        self.assertEqual(cached.task_id, "test-001")
        self.assertEqual(cached.n_safe, 2)
        self.assertTrue(cached.is_learnable)


class TestCachedScenarioValidation(unittest.TestCase):

    def test_valid_scenario(self):
        r = _make_result()
        cached = r.to_cache_entry()
        self.assertEqual(cached.validate(), [])

    def test_mismatched_margins(self):
        r = _make_result()
        cached = r.to_cache_entry()
        cached.safety_margins = [0.9]
        errors = cached.validate()
        self.assertTrue(any("safety_margins" in e for e in errors))


class TestCandidateCacheProvenance(unittest.TestCase):

    def test_from_benchmark_results(self):
        r1 = _make_result(task_id="t1", ground_truth_safe=False)
        r2 = _make_result(task_id="t2", ground_truth_safe=True)
        cache = CandidateCache.from_benchmark_results([r1, r2])
        self.assertEqual(cache.total, 1)
        self.assertIsNotNone(cache.get("t1"))
        self.assertIsNone(cache.get("t2"))

    def test_provenance_create(self):
        prov = CacheProvenance.create(
            model_name="gpt-4o", model_version="2024-05-13",
            prompt_template_hash="abc123",
            safety_config={}, benchmark_source="SafeAgentBench",
            benchmark_version="1.0", build_seed=42,
            total_tasks_processed=10, total_learnable=5,
        )
        self.assertEqual(prov.model_name, "gpt-4o")
        d = prov.to_dict()
        prov2 = CacheProvenance.from_dict(d)
        self.assertEqual(prov2.model_name, "gpt-4o")


class TestPosteriorSaveLoad(unittest.TestCase):

    def test_posterior_save_load_roundtrip(self):
        from evaluation.experiments import (
            save_posteriors, load_posteriors, TrialResult,
        )
        from evaluation.metrics import MetricsTracker
        import tempfile, os

        mu = np.array([0.1] * FEATURE_DIM)
        sigma = np.eye(FEATURE_DIM) * 0.5
        tracker = MetricsTracker.__new__(MetricsTracker)
        tracker._steps = []
        tracker._test_pairs = []
        tracker._prior_accuracy = 0.5

        results = [
            TrialResult(
                profile_name="Conservative Parent",
                strategy_name="CASPER",
                trial_id=i,
                tracker=tracker,
                final_mu=mu + i * 0.01,
                final_sigma=sigma,
                final_sigma_trace=float(np.trace(sigma)),
                convergence_time=10,
                autonomy_transition_time=None,
            )
            for i in range(3)
        ]

        with tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, mode="w"
        ) as f:
            path = f.name

        try:
            save_posteriors(results, path)
            loaded = load_posteriors(path)
            self.assertIn("Conservative Parent", loaded)
            mu_loaded, sigma_loaded = loaded["Conservative Parent"]
            self.assertEqual(mu_loaded.shape, (FEATURE_DIM,))
            self.assertEqual(sigma_loaded.shape, (FEATURE_DIM, FEATURE_DIM))
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
