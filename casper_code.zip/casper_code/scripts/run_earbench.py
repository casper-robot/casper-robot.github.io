#!/usr/bin/env python
"""
EAR-Bench Runner — Physical Risk Awareness Evaluation.

Runs CASPER + baselines (SafePlan, RoboGuard) on the EAR-Bench dataset
to evaluate physical risk detection across domestic environments.

All EAR-Bench tasks are unsafe (every task has a safety concern), so the
primary metric is detection rate (recall). We report per-scene breakdown.

Usage:
    # Home environment only (531 tasks)
    python -m scripts.run_earbench --provider openai --model gpt-4o --max-workers 50

    # With baselines
    python -m scripts.run_earbench --provider openai --model gpt-4o --max-workers 50 --baselines

    # Limit tasks
    python -m scripts.run_earbench --provider openai --model gpt-4o --num-tasks 50
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("earbench")


def _build_scene_context(task) -> str:
    """Build CASPER-compatible scene context from EAR-Bench task."""
    lines = []
    if task.scene:
        lines.append(f"Scene: {task.scene} ({task.environment})")
    if task.text_observation:
        lines.append(f"Description: {task.text_observation}")
    if task.objects:
        lines.append(f"Objects present: {task.objects}")
    if task.objects_attributes:
        lines.append(f"Object properties: {task.objects_attributes}")
    if task.objects_positions:
        lines.append(f"Object positions: {task.objects_positions}")
    return "\n".join(lines) if lines else "Unknown scene"


def _get_object_names(task) -> list[str]:
    """Extract object names from EAR-Bench task."""
    if not task.objects:
        return []
    return [o.strip() for o in task.objects.split(",") if o.strip()]


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Run CASPER + baselines on EAR-Bench (home environment)",
    )
    p.add_argument(
        "--provider", default="openai",
        help="LLM provider (default: openai)",
    )
    p.add_argument(
        "--model", default="gpt-4o",
        help="Model identifier (default: gpt-4o)",
    )
    p.add_argument(
        "--output", default=None,
        help="Output directory (default: results/earbench_<timestamp>)",
    )
    p.add_argument(
        "--environment", default="home",
        help="EAR-Bench environment to evaluate (default: home)",
    )
    p.add_argument(
        "--num-tasks", type=int, default=0,
        help="Cap total tasks (0 = all, default: 0)",
    )
    p.add_argument(
        "--max-workers", type=int, default=1,
        help="Parallel worker threads (default: 1)",
    )
    p.add_argument(
        "--baselines", action="store_true",
        help="Also run SafePlan and RoboGuard baselines",
    )
    return p


def _run_casper_task(task, provider, model, scene_context):
    """Run CASPER safety detection on a single EAR-Bench task."""
    from casper.llm_providers import create_llm_backend
    from casper.safety_pipeline import SafetyPipeline
    from casper.safety_kernel import SafetyConfig

    llm = create_llm_backend(provider, model=model)
    pipeline = SafetyPipeline(llm, SafetyConfig())

    start = time.perf_counter()
    try:
        result = pipeline.evaluate(task.instruction, scene_context)
        latency = (time.perf_counter() - start) * 1000
        return {
            "task_id": task.task_id,
            "method": "CASPER",
            "command": task.instruction,
            "scene": task.scene,
            "environment": task.environment,
            "detected_unsafe": not result.is_safe,
            "flagged_dimensions": [d.name for d in result.flagged_dimensions],
            "safety_tip": task.safety_tip,
            "latency_ms": latency,
            "error": "",
        }
    except Exception as e:
        latency = (time.perf_counter() - start) * 1000
        return {
            "task_id": task.task_id,
            "method": "CASPER",
            "command": task.instruction,
            "scene": task.scene,
            "environment": task.environment,
            "detected_unsafe": True,
            "flagged_dimensions": [],
            "safety_tip": task.safety_tip,
            "latency_ms": latency,
            "error": str(e),
        }


def _compute_metrics(results: list[dict], method: str) -> dict:
    """Compute detection metrics. All EAR-Bench tasks are unsafe."""
    total = len(results)
    detected = sum(1 for r in results if r["detected_unsafe"])
    detection_rate = detected / max(total, 1)

    by_scene: dict[str, dict] = {}
    for r in results:
        scene = r.get("scene", "unknown")
        by_scene.setdefault(scene, {"total": 0, "detected": 0})
        by_scene[scene]["total"] += 1
        if r["detected_unsafe"]:
            by_scene[scene]["detected"] += 1

    for scene, counts in by_scene.items():
        counts["detection_rate"] = counts["detected"] / max(counts["total"], 1)

    avg_latency = sum(r.get("latency_ms", 0) for r in results) / max(total, 1)

    return {
        "method": method,
        "total": total,
        "detected": detected,
        "detection_rate": round(detection_rate, 4),
        "avg_latency_ms": round(avg_latency, 1),
        "by_scene": by_scene,
    }


def main():
    args = build_parser().parse_args()

    output_dir = Path(args.output or (
        f"results/earbench_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    ))
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load EAR-Bench
    from evaluation.earbench_loader import load_dataset

    tasks = load_dataset(
        num_tasks=args.num_tasks,
        environments=[args.environment],
    )
    logger.info(f"Loaded {len(tasks)} EAR-Bench tasks ({args.environment})")

    # Build scene contexts
    scene_contexts = {t.task_id: _build_scene_context(t) for t in tasks}

    manifest = {
        "start_time": datetime.now(timezone.utc).isoformat(),
        "provider": args.provider,
        "model": args.model,
        "environment": args.environment,
        "num_tasks": len(tasks),
        "max_workers": args.max_workers,
        "baselines": args.baselines,
    }

    results_file = output_dir / "results.jsonl"
    file_lock = threading.Lock()
    all_method_results: dict[str, list[dict]] = {}

    # --- Run CASPER ---
    logger.info("Running CASPER on EAR-Bench...")
    t0 = time.perf_counter()
    casper_results = []

    with ThreadPoolExecutor(max_workers=args.max_workers) as pool:
        futures = {
            pool.submit(
                _run_casper_task, task, args.provider, args.model,
                scene_contexts[task.task_id],
            ): task.task_id
            for task in tasks
        }
        for future in as_completed(futures):
            result = future.result()
            casper_results.append(result)
            with file_lock:
                with open(results_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(result) + "\n")

    casper_elapsed = time.perf_counter() - t0
    casper_metrics = _compute_metrics(casper_results, "CASPER")
    all_method_results["CASPER"] = casper_results

    logger.info(
        f"CASPER: detection_rate={casper_metrics['detection_rate']:.1%} "
        f"({casper_metrics['detected']}/{casper_metrics['total']}) "
        f"in {casper_elapsed:.0f}s"
    )

    # --- Run baselines ---
    if args.baselines:
        from casper.llm_providers import create_llm_backend
        from evaluation.safety_baselines import SafePlanBaseline, RoboGuardBaseline

        baselines = {
            "SafePlan": SafePlanBaseline,
            "RoboGuard": RoboGuardBaseline,
        }

        for baseline_name, baseline_cls in baselines.items():
            logger.info(f"Running {baseline_name} on EAR-Bench...")
            t0 = time.perf_counter()
            baseline_results = []

            def _run_baseline_task(task, bname, bcls):
                llm = create_llm_backend(args.provider, model=args.model)
                baseline = bcls(llm)
                br = baseline.evaluate(
                    task_id=task.task_id,
                    command=task.instruction,
                    scene_context=scene_contexts[task.task_id],
                )
                return {
                    "task_id": br.task_id,
                    "method": bname,
                    "command": br.command,
                    "scene": task.scene,
                    "environment": task.environment,
                    "detected_unsafe": br.detected_unsafe,
                    "safety_tip": task.safety_tip,
                    "latency_ms": br.latency_ms,
                    "error": br.error,
                }

            with ThreadPoolExecutor(max_workers=args.max_workers) as pool:
                futures = {
                    pool.submit(
                        _run_baseline_task, task, baseline_name, baseline_cls,
                    ): task.task_id
                    for task in tasks
                }
                for future in as_completed(futures):
                    result = future.result()
                    baseline_results.append(result)
                    with file_lock:
                        with open(results_file, "a", encoding="utf-8") as f:
                            f.write(json.dumps(result) + "\n")

            elapsed = time.perf_counter() - t0
            metrics = _compute_metrics(baseline_results, baseline_name)
            all_method_results[baseline_name] = baseline_results

            logger.info(
                f"{baseline_name}: detection_rate={metrics['detection_rate']:.1%} "
                f"({metrics['detected']}/{metrics['total']}) "
                f"in {elapsed:.0f}s"
            )

    # --- Summary ---
    summary = {}
    for method_name, method_results in all_method_results.items():
        summary[method_name] = _compute_metrics(method_results, method_name)

    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8",
    )

    manifest["end_time"] = datetime.now(timezone.utc).isoformat()
    manifest["methods"] = list(summary.keys())
    for method_name, metrics in summary.items():
        manifest[f"{method_name}_detection_rate"] = metrics["detection_rate"]
    (output_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8",
    )

    logger.info("=" * 50)
    logger.info("EAR-Bench Results (all tasks are unsafe):")
    for method_name, metrics in summary.items():
        logger.info(
            f"  {method_name}: {metrics['detection_rate']:.1%} "
            f"({metrics['detected']}/{metrics['total']})"
        )

    return 0


if __name__ == "__main__":
    sys.exit(main())
