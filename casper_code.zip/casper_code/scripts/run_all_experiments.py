#!/usr/bin/env python
"""
CASPER Experiment Orchestrator — Runs A → B → C in dependency order.

Experiment dependency graph:
    A (Safety Detection)      →  produces candidate_cache.json
    B (Preference Learning)   ←  reads from candidate_cache.json
    C (Cross-Hazard Transfer) ←  reads from candidate_cache.json

Run order:
    1. A — SafeAgentBench detection + pipeline, builds CandidateCache
    2. B — Cached preference learning (zero LLM cost after A)
    3. C — Cross-hazard transfer from same cache

Usage:
    # Run all experiments
    python scripts/run_all_experiments.py --provider openai --model gpt-4o

    # Run only specific experiments
    python scripts/run_all_experiments.py --experiments A B

    # Quick smoke test
    python scripts/run_all_experiments.py --quick
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("experiment_orchestrator")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Run all CASPER experiments in dependency order",
    )
    p.add_argument(
        "--provider", default="openai",
        help="LLM provider (default: openai)",
    )
    p.add_argument(
        "--model", default="gpt-4o",
        help="Model identifier (default: gpt-4o)",
    )
    p.add_argument(
        "--output", default=None,
        help="Root output directory (default: results/full_run_<timestamp>)",
    )
    p.add_argument(
        "--experiments", nargs="+", default=["A", "B", "C"],
        choices=["A", "B", "B_ablation", "C"],
        help="Experiments to run (default: A B C). B_ablation runs CASPER component ablations.",
    )
    p.add_argument(
        "--quick", action="store_true",
        help="Quick smoke test (10 tasks, 2 trials)",
    )
    p.add_argument(
        "--num-tasks", type=int, default=0,
        help="Cap tasks for Experiment A (0 = all)",
    )
    p.add_argument(
        "--n-trials", type=int, default=20,
        help="Trials per (profile, strategy) pair for B/C (default: 20)",
    )
    p.add_argument(
        "--K", type=int, default=7,
        help="Repair candidates per command (default: 7)",
    )
    p.add_argument(
        "--cache-path", default=None,
        help="Pre-built candidate cache (skip Experiment A)",
    )
    return p


def run_experiment_a(args, output_dir: Path) -> Path | None:
    """Experiment A: Safety detection benchmark. Returns cache path."""
    from casper.llm_providers import create_llm_backend
    from casper.casper_pipeline import CasperPipeline
    from evaluation.benchmark_runner import BenchmarkRunner, RunConfig
    from evaluation.scene_adapters import BenchmarkSceneAdapter
    from evaluation.safeagentbench_loader import load_dataset

    exp_dir = output_dir / "experiment_a"

    llm = create_llm_backend(args.provider, model=args.model)
    pipeline = CasperPipeline(llm=llm, K=args.K)
    adapter = BenchmarkSceneAdapter()

    splits = ["unsafe_detailed", "safe_detailed"]
    num_tasks = args.num_tasks

    config = RunConfig(
        output_dir=str(exp_dir),
        splits=splits,
        num_tasks=num_tasks,
        resume=True,
    )

    tasks = load_dataset(splits=splits, num_tasks=num_tasks)
    logger.info(f"[A] Loaded {len(tasks)} tasks")

    runner = BenchmarkRunner(pipeline, adapter, config)
    output = runner.run(tasks)

    n_unsafe = sum(1 for r in output.results if r.pipeline_detected_unsafe)
    n_gt = sum(1 for r in output.results if not r.ground_truth_safe)
    logger.info(
        f"[A] Done: {len(output.results)} completed, "
        f"detected {n_unsafe} unsafe (ground truth: {n_gt})"
    )

    cache_path = exp_dir / "candidate_cache.json"
    if cache_path.exists():
        return cache_path
    return None


def run_experiment_b(args, output_dir: Path, cache_path: Path):
    """Experiment B: Online preference learning from cache."""
    from evaluation.candidate_cache import CandidateCache
    from evaluation.experiments import (
        ExperimentConfig, run_trial_cached, TrialResult,
    )
    from evaluation.simulated_user import (
        SimulatedUserFactory, ALL_PROFILES,
    )
    from evaluation.baselines import all_strategies
    from evaluation.experiments import _generate_test_pairs_cached
    from evaluation.analysis import aggregate_trials, generate_report
    import numpy as np

    exp_dir = output_dir / "experiment_b"
    exp_dir.mkdir(parents=True, exist_ok=True)

    cache = CandidateCache.load(str(cache_path))
    learnable = cache.get_learnable_scenarios()
    logger.info(f"[B] Cache: {cache.total} scenarios, {len(learnable)} learnable")

    if len(learnable) < 2:
        logger.warning("[B] Not enough learnable scenarios — skipping")
        return

    config = ExperimentConfig(
        n_trials=args.n_trials,
        T_max=30,
        n_test_pairs=50,
        seed=42,
    )

    factory = SimulatedUserFactory(seed=config.seed)
    strategies = all_strategies(casper_config=config.casper_config())
    all_results: list[TrialResult] = []

    for profile in ALL_PROFILES:
        user = factory.create(profile)
        test_pairs = _generate_test_pairs_cached(learnable, user, n_pairs=config.n_test_pairs)

        for strategy in strategies:
            for trial_id in range(config.n_trials):
                rng = np.random.default_rng(config.seed + trial_id)
                result = run_trial_cached(
                    user=user,
                    strategy=strategy,
                    cache=cache,
                    config=config,
                    test_pairs=test_pairs,
                    rng=rng,
                    trial_id=trial_id,
                )
                all_results.append(result)

            logger.info(
                f"[B] {profile.name} × {strategy.name}: "
                f"{config.n_trials} trials done"
            )

    agg = aggregate_trials(all_results)
    report = generate_report(agg)
    (exp_dir / "evaluation_report.md").write_text(report, encoding="utf-8")

    raw = [
        {
            "profile": r.profile_name,
            "strategy": r.strategy_name,
            "trial": r.trial_id,
            "convergence_time": r.convergence_time,
            "final_sigma_trace": r.final_sigma_trace,
            "final_prediction_accuracy": r.tracker.summary().get(
                "final_prediction_accuracy"
            ),
            "cumulative_regret": r.tracker.summary().get("cumulative_regret"),
        }
        for r in all_results
    ]
    (exp_dir / "raw_results.json").write_text(
        json.dumps(raw, indent=2), encoding="utf-8",
    )

    # Strategy-level summary
    from collections import defaultdict
    by_strategy: dict[str, list] = defaultdict(list)
    for r in all_results:
        by_strategy[r.strategy_name].append(r)

    strategy_summary = {}
    for strat_name, trials in by_strategy.items():
        conv_times = [
            t.convergence_time for t in trials
            if t.convergence_time is not None
        ]
        accuracies = [
            t.tracker.summary().get("final_prediction_accuracy")
            for t in trials
        ]
        accuracies = [a for a in accuracies if a is not None]
        regrets = [
            t.tracker.summary().get("cumulative_regret", 0)
            for t in trials
        ]
        strategy_summary[strat_name] = {
            "n_trials": len(trials),
            "convergence_rate": len(conv_times) / len(trials) if trials else 0,
            "avg_convergence_time": (
                sum(conv_times) / len(conv_times) if conv_times else None
            ),
            "avg_prediction_accuracy": (
                float(np.mean(accuracies)) if accuracies else None
            ),
            "avg_cumulative_regret": float(np.mean(regrets)),
        }

    (exp_dir / "strategy_summary.json").write_text(
        json.dumps(strategy_summary, indent=2), encoding="utf-8",
    )

    from evaluation.experiments import save_posteriors
    save_posteriors(
        all_results,
        str(exp_dir / "converged_posteriors.json"),
        strategy_filter="CASPER",
    )

    logger.info(f"[B] Done: {len(all_results)} trials across "
                f"{len(ALL_PROFILES)} profiles × {len(strategies)} strategies")
    for name, s in strategy_summary.items():
        logger.info(
            f"  {name}: acc={s['avg_prediction_accuracy']:.3f}, "
            f"regret={s['avg_cumulative_regret']:.2f}, "
            f"conv={s['convergence_rate']:.0%}"
        )


def run_experiment_b_ablation(args, output_dir: Path, cache_path: Path):
    """Ablation study: CASPER with selectively disabled scoring terms."""
    from evaluation.candidate_cache import CandidateCache
    from evaluation.experiments import (
        ExperimentConfig, run_trial_cached, TrialResult,
        _generate_test_pairs_cached,
    )
    from evaluation.simulated_user import (
        SimulatedUserFactory, ALL_PROFILES,
    )
    from evaluation.baselines import all_ablations
    from evaluation.analysis import aggregate_trials, generate_report
    import numpy as np

    exp_dir = output_dir / "experiment_b_ablation"
    exp_dir.mkdir(parents=True, exist_ok=True)

    cache = CandidateCache.load(str(cache_path))
    learnable = cache.get_learnable_scenarios()
    logger.info(
        f"[B_ablation] Cache: {cache.total} scenarios, "
        f"{len(learnable)} learnable"
    )

    if len(learnable) < 2:
        logger.warning("[B_ablation] Not enough learnable scenarios — skipping")
        return

    config = ExperimentConfig(
        n_trials=args.n_trials,
        T_max=30,
        n_test_pairs=50,
        seed=42,
    )

    factory = SimulatedUserFactory(seed=config.seed)
    strategies = all_ablations(config.casper_config())
    all_results: list[TrialResult] = []

    for profile in ALL_PROFILES:
        user = factory.create(profile)
        test_pairs = _generate_test_pairs_cached(
            learnable, user, n_pairs=config.n_test_pairs,
        )

        for strategy in strategies:
            for trial_id in range(config.n_trials):
                rng = np.random.default_rng(config.seed + trial_id)
                result = run_trial_cached(
                    user=user,
                    strategy=strategy,
                    cache=cache,
                    config=config,
                    test_pairs=test_pairs,
                    rng=rng,
                    trial_id=trial_id,
                )
                all_results.append(result)

            logger.info(
                f"[B_ablation] {profile.name} × {strategy.name}: "
                f"{config.n_trials} trials done"
            )

    raw = [
        {
            "profile": r.profile_name,
            "strategy": r.strategy_name,
            "trial": r.trial_id,
            "convergence_time": r.convergence_time,
            "final_sigma_trace": r.final_sigma_trace,
            "final_prediction_accuracy": r.tracker.summary().get(
                "final_prediction_accuracy"
            ),
            "cumulative_regret": r.tracker.summary().get("cumulative_regret"),
            "final_weight_recovery_error": r.tracker.summary().get(
                "final_weight_recovery_error"
            ),
        }
        for r in all_results
    ]
    (exp_dir / "ablation_results.json").write_text(
        json.dumps(raw, indent=2), encoding="utf-8",
    )

    # Summary: compare across ablations (aggregate + per-profile)
    from collections import defaultdict
    by_strategy: dict[str, list] = defaultdict(list)
    by_strategy_profile: dict[tuple, list] = defaultdict(list)
    for r in all_results:
        by_strategy[r.strategy_name].append(r)
        by_strategy_profile[(r.strategy_name, r.profile_name)].append(r)

    def _summarize_trials(trials):
        conv_times = [
            t.convergence_time for t in trials
            if t.convergence_time is not None
        ]
        accuracies = [
            t.tracker.summary().get("final_prediction_accuracy")
            for t in trials
        ]
        accuracies = [a for a in accuracies if a is not None]
        regrets = [
            t.tracker.summary().get("cumulative_regret", 0)
            for t in trials
        ]
        return {
            "n_trials": len(trials),
            "n_converged": len(conv_times),
            "convergence_rate": len(conv_times) / len(trials) if trials else 0,
            "avg_convergence_time": (
                sum(conv_times) / len(conv_times) if conv_times else None
            ),
            "avg_sigma_trace": float(np.mean(
                [t.final_sigma_trace for t in trials]
            )),
            "avg_prediction_accuracy": (
                float(np.mean(accuracies)) if accuracies else None
            ),
            "avg_cumulative_regret": float(np.mean(regrets)),
        }

    summary = {
        name: _summarize_trials(trials)
        for name, trials in by_strategy.items()
    }

    # Per-profile breakdown
    profile_breakdown = {}
    for (strategy_name, profile_name), trials in sorted(
        by_strategy_profile.items()
    ):
        key = f"{strategy_name} | {profile_name}"
        profile_breakdown[key] = _summarize_trials(trials)

    output = {
        "aggregate": summary,
        "by_profile": profile_breakdown,
    }

    (exp_dir / "ablation_summary.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8",
    )

    logger.info(
        f"[B_ablation] Done: {len(all_results)} trials across "
        f"{len(ALL_PROFILES)} profiles × {len(strategies)} ablations"
    )
    for name, s in summary.items():
        logger.info(
            f"  {name}: conv_rate={s['convergence_rate']:.0%}, "
            f"avg_time={s['avg_convergence_time']}, "
            f"avg_accuracy={s['avg_prediction_accuracy']}, "
            f"avg_regret={s['avg_cumulative_regret']:.2f}"
        )


def run_experiment_c(args, output_dir: Path, cache_path: Path):
    """Experiment C: Cross-hazard transfer."""
    from evaluation.candidate_cache import CandidateCache
    from evaluation.experiments import (
        ExperimentConfig, run_transfer_experiment,
    )

    exp_dir = output_dir / "experiment_c"
    exp_dir.mkdir(parents=True, exist_ok=True)

    cache = CandidateCache.load(str(cache_path))

    config = ExperimentConfig(
        n_trials=args.n_trials,
        T_max=30,
        n_test_pairs=50,
        seed=42,
    )

    results_strategy = run_transfer_experiment(
        cache, config, use_text_features=False,
    )
    results_text = run_transfer_experiment(
        cache, config, use_text_features=True,
    )

    import numpy as np
    from collections import defaultdict

    def _analyze_transfer(train_results, test_results, label):
        """Analyze transfer experiment results."""
        # Aggregate test results by profile
        by_profile = defaultdict(list)
        for r in test_results:
            by_profile[r.profile_name].append(r)

        profile_stats = {}
        for profile_name, trials in sorted(by_profile.items()):
            accuracies = [
                r.tracker.summary().get("final_prediction_accuracy")
                for r in trials
            ]
            accuracies = [a for a in accuracies if a is not None]
            regrets = [
                r.tracker.summary().get("cumulative_regret", 0)
                for r in trials
            ]
            profile_stats[profile_name] = {
                "n_test_trials": len(trials),
                "avg_test_accuracy": (
                    float(np.mean(accuracies)) if accuracies else None
                ),
                "avg_test_regret": float(np.mean(regrets)),
            }

        # Train accuracy for comparison
        train_accuracies = [
            r.tracker.summary().get("final_prediction_accuracy")
            for r in train_results
        ]
        train_accuracies = [a for a in train_accuracies if a is not None]
        train_regrets = [
            r.tracker.summary().get("cumulative_regret", 0)
            for r in train_results
        ]

        all_test_accuracies = [
            r.tracker.summary().get("final_prediction_accuracy")
            for r in test_results
        ]
        all_test_accuracies = [a for a in all_test_accuracies if a is not None]
        all_test_regrets = [
            r.tracker.summary().get("cumulative_regret", 0)
            for r in test_results
        ]

        return {
            "label": label,
            "n_train_trials": len(train_results),
            "n_test_trials": len(test_results),
            "avg_train_accuracy": (
                float(np.mean(train_accuracies)) if train_accuracies else None
            ),
            "avg_train_regret": float(np.mean(train_regrets)),
            "avg_test_accuracy": (
                float(np.mean(all_test_accuracies))
                if all_test_accuracies else None
            ),
            "avg_test_regret": float(np.mean(all_test_regrets)),
            "transfer_gap": (
                float(np.mean(train_accuracies)) -
                float(np.mean(all_test_accuracies))
                if train_accuracies and all_test_accuracies else None
            ),
            "by_profile": profile_stats,
        }

    strategy_analysis = _analyze_transfer(
        results_strategy["train"], results_strategy["test"],
        "strategy_features",
    )
    text_analysis = _analyze_transfer(
        results_text["train"], results_text["test"],
        "text_features",
    )

    output = {
        "strategy_features": strategy_analysis,
        "text_features": text_analysis,
    }

    (exp_dir / "transfer_summary.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8",
    )

    logger.info(
        f"[C] Done: strategy features — "
        f"train_acc={strategy_analysis['avg_train_accuracy']:.3f}, "
        f"test_acc={strategy_analysis['avg_test_accuracy']:.3f}, "
        f"gap={strategy_analysis['transfer_gap']:.3f}"
    )
    logger.info(
        f"[C] Done: text features — "
        f"train_acc={text_analysis['avg_train_accuracy']:.3f}, "
        f"test_acc={text_analysis['avg_test_accuracy']:.3f}, "
        f"gap={text_analysis['transfer_gap']:.3f}"
    )


def main():
    args = build_parser().parse_args()

    if args.quick:
        args.num_tasks = 10
        args.n_trials = 2
        args.experiments = ["A", "B", "C"]

    output_dir = Path(args.output or (
        f"results/full_run_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    ))
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "start_time": datetime.now(timezone.utc).isoformat(),
        "provider": args.provider,
        "model": args.model,
        "experiments": args.experiments,
        "num_tasks": args.num_tasks,
        "n_trials": args.n_trials,
        "K": args.K,
    }

    logger.info(f"Running experiments: {args.experiments}")
    logger.info(f"Output: {output_dir}")

    t0 = time.perf_counter()
    cache_path = Path(args.cache_path) if args.cache_path else None

    # --- Experiment A ---
    if "A" in args.experiments and cache_path is None:
        logger.info("=" * 60)
        logger.info("EXPERIMENT A: Safety Detection Benchmark")
        logger.info("=" * 60)
        cache_path = run_experiment_a(args, output_dir)

    cache_dependent = {"B", "B_ablation", "C"}
    if cache_path is None or not cache_path.exists():
        if cache_dependent & set(args.experiments):
            logger.error(
                "No candidate cache available. Run Experiment A first, "
                "or provide --cache-path."
            )
            args.experiments = [
                e for e in args.experiments if e not in cache_dependent
            ]

    # --- Experiment B ---
    if "B" in args.experiments and cache_path and cache_path.exists():
        logger.info("=" * 60)
        logger.info("EXPERIMENT B: Online Preference Learning")
        logger.info("=" * 60)
        run_experiment_b(args, output_dir, cache_path)

    # --- Experiment B Ablation ---
    if "B_ablation" in args.experiments and cache_path and cache_path.exists():
        logger.info("=" * 60)
        logger.info("EXPERIMENT B ABLATION: Component Analysis")
        logger.info("=" * 60)
        run_experiment_b_ablation(args, output_dir, cache_path)

    # --- Experiment C ---
    if "C" in args.experiments and cache_path and cache_path.exists():
        logger.info("=" * 60)
        logger.info("EXPERIMENT C: Cross-Hazard Transfer")
        logger.info("=" * 60)
        run_experiment_c(args, output_dir, cache_path)

    elapsed = time.perf_counter() - t0
    manifest["end_time"] = datetime.now(timezone.utc).isoformat()
    manifest["elapsed_seconds"] = round(elapsed, 1)
    (output_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8",
    )

    logger.info(f"All experiments complete in {elapsed:.0f}s")
    logger.info(f"Results: {output_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
