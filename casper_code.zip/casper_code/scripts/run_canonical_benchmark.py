#!/usr/bin/env python
"""
Canonical Benchmark Runner — Experiment A.

Single entry point for running the full CASPER pipeline benchmark on
SafeAgentBench tasks. Produces:
  - results.jsonl (per-task results, resumable)
  - adaptation_report.json (scene adaptation diagnostics)
  - traces/ (per-task LLM call traces, if enabled)
  - run_manifest.json (reproducibility metadata)
  - reference_compare.jsonl + summary (optional waterfall diagnostic)

Usage:
    # Quick smoke test (10 tasks)
    python scripts/run_canonical_benchmark.py --quick

    # Full run, 2 splits, default model
    python scripts/run_canonical_benchmark.py --provider openai --model gpt-4o

    # All 4 splits with reference comparison
    python scripts/run_canonical_benchmark.py --all-splits --reference-compare

    # Resume a previous run
    python scripts/run_canonical_benchmark.py --output results/my_run --resume
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("canonical_benchmark")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Run CASPER canonical benchmark (Experiment A)",
    )
    p.add_argument(
        "--provider", default="openai",
        help="LLM provider: openai, anthropic, google (default: openai)",
    )
    p.add_argument(
        "--model", default="gpt-4o",
        help="Model identifier (default: gpt-4o)",
    )
    p.add_argument(
        "--output", default=None,
        help="Output directory (default: results/benchmark_<timestamp>)",
    )
    p.add_argument(
        "--splits", nargs="+",
        default=["unsafe_detailed", "safe_detailed"],
        help="SafeAgentBench splits to evaluate (default: unsafe_detailed safe_detailed)",
    )
    p.add_argument(
        "--all-splits", action="store_true",
        help="Run all 4 splits (overrides --splits)",
    )
    p.add_argument(
        "--num-tasks", type=int, default=0,
        help="Cap total tasks across splits (0 = all, default: 0)",
    )
    p.add_argument(
        "--quick", action="store_true",
        help="Quick smoke test: 10 tasks, 2 splits",
    )
    p.add_argument(
        "--K", type=int, default=7,
        help="Number of repair candidates per unsafe command (default: 7)",
    )
    p.add_argument(
        "--resume", action="store_true", default=True,
        help="Resume from previous checkpoint (default: True)",
    )
    p.add_argument(
        "--no-resume", action="store_true",
        help="Start fresh, ignoring any existing checkpoint",
    )
    p.add_argument(
        "--no-traces", action="store_true",
        help="Disable per-task trace recording",
    )
    p.add_argument(
        "--reference-compare", action="store_true",
        help="Run full-pipeline reference comparison (expensive)",
    )
    p.add_argument(
        "--rerun-failures", action="store_true",
        help="Re-process tasks that previously failed",
    )
    p.add_argument(
        "--max-workers", type=int, default=1,
        help="Parallel worker threads (default: 1 = sequential)",
    )
    p.add_argument(
        "--rate-limit", type=float, default=0.0,
        help="Max LLM calls/sec across all workers (0 = no limit)",
    )
    p.add_argument(
        "--baselines", action="store_true",
        help="Also run SafePlan and RoboGuard baselines for comparison",
    )
    return p


def main():
    args = build_parser().parse_args()

    if args.quick:
        args.num_tasks = 10
        args.splits = ["unsafe_detailed", "safe_detailed"]

    if args.all_splits:
        args.splits = [
            "unsafe_detailed", "safe_detailed", "abstract", "long_horizon",
        ]

    output_dir = args.output or (
        f"results/benchmark_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    )

    from casper.llm_providers import create_llm_backend
    from casper.casper_pipeline import CasperPipeline
    from evaluation.benchmark_runner import BenchmarkRunner, RunConfig
    from evaluation.scene_adapters import BenchmarkSceneAdapter
    from evaluation.safeagentbench_loader import load_dataset

    logger.info(f"Provider: {args.provider}, Model: {args.model}")
    logger.info(f"Splits: {args.splits}, Tasks: {args.num_tasks or 'all'}")
    logger.info(f"Output: {output_dir}")
    if args.max_workers > 1:
        logger.info(f"Workers: {args.max_workers}, Rate limit: {args.rate_limit or 'none'}")

    llm = create_llm_backend(args.provider, model=args.model)
    pipeline = CasperPipeline(llm=llm, K=args.K)
    adapter = BenchmarkSceneAdapter()

    pipeline_factory = None
    if args.max_workers > 1:
        def pipeline_factory():
            worker_llm = create_llm_backend(args.provider, model=args.model)
            return CasperPipeline(llm=worker_llm, K=args.K)

    config = RunConfig(
        output_dir=output_dir,
        splits=args.splits,
        num_tasks=args.num_tasks,
        trace_enabled=not args.no_traces,
        resume=args.resume and not args.no_resume,
        rerun_failures=args.rerun_failures,
        reference_compare=args.reference_compare,
        max_workers=args.max_workers,
    )

    tasks = load_dataset(splits=args.splits, num_tasks=args.num_tasks)
    logger.info(f"Loaded {len(tasks)} tasks")

    runner = BenchmarkRunner(pipeline, adapter, config, pipeline_factory)

    # Write run manifest for reproducibility
    manifest = {
        "start_time": datetime.now(timezone.utc).isoformat(),
        "provider": args.provider,
        "model": args.model,
        "llm_model_name": llm.model_name,
        "splits": args.splits,
        "num_tasks": args.num_tasks,
        "K": args.K,
        "total_loaded": len(tasks),
        "reference_compare": args.reference_compare,
        "trace_enabled": config.trace_enabled,
        "max_workers": args.max_workers,
        "rate_limit": args.rate_limit,
    }
    manifest_path = Path(output_dir) / "run_manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    t0 = time.perf_counter()
    output = runner.run(tasks)
    elapsed = time.perf_counter() - t0

    # Update manifest with results
    manifest["end_time"] = datetime.now(timezone.utc).isoformat()
    manifest["elapsed_seconds"] = round(elapsed, 1)
    manifest["tasks_completed"] = len(output.results)
    manifest["tasks_failed"] = len(output.failed_task_ids)
    if output.adaptation_report:
        manifest["adaptation_passed"] = output.adaptation_report.passed
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    # Summary
    n_unsafe_detected = sum(
        1 for r in output.results if r.pipeline_detected_unsafe
    )
    n_gt_unsafe = sum(
        1 for r in output.results if not r.ground_truth_safe
    )
    logger.info(
        f"Done in {elapsed:.0f}s. "
        f"{len(output.results)} completed, {len(output.failed_task_ids)} failed. "
        f"Detected {n_unsafe_detected}/{len(output.results)} as unsafe "
        f"(ground truth: {n_gt_unsafe} unsafe)."
    )

    if output.failed_task_ids:
        logger.warning(f"Failed tasks: {output.failed_task_ids[:10]}")

    # Run baselines
    if args.baselines:
        from evaluation.safety_baselines import run_baselines

        logger.info("=" * 60)
        logger.info("Running safety baselines (SafePlan, RoboGuard)")
        logger.info("=" * 60)

        baseline_llm = create_llm_backend(args.provider, model=args.model)
        baseline_dir = str(Path(output_dir) / "baselines")
        run_baselines(
            tasks=tasks,
            scene_adapter=adapter,
            llm=baseline_llm,
            output_dir=baseline_dir,
            max_workers=args.max_workers,
        )

    return 0 if not output.failed_task_ids else 1


if __name__ == "__main__":
    sys.exit(main())
