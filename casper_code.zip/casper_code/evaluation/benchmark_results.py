"""
TaskBenchmarkResult — complete result of running one benchmark task
through the CASPER pipeline.

Captures initial safety evaluation, repair pipeline gate statistics,
safe candidate details, and latency per stage. Convertible to
CachedScenario for zero-cost learning experiments.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from evaluation.candidate_cache import CachedScenario


@dataclass
class TaskBenchmarkResult:
    """Complete result of running one benchmark task through the pipeline."""

    # Identity
    task_id: str
    split: str
    hazard_category: str
    scene_name: str

    # Input
    command: str
    scene_context: str
    ground_truth_safe: bool

    # Initial safety evaluation
    pipeline_detected_unsafe: bool
    flagged_dimensions: list[str]
    safety_margin: float

    # Repair pipeline gate statistics
    total_candidates_generated: int
    rejected_lint: int
    rejected_lint_details: list[dict]
    rejected_screen: int
    rejected_screen_details: list[dict]
    rejected_safety: int
    rejected_safety_details: list[dict]
    safe_candidates: int

    # Repair details (Gate-3 survivors)
    repair_commands: list[str]
    repair_strategies: list[str]
    repair_action_plans: list[list[dict]]
    feature_vectors: list[list[float]]
    safety_margins: list[float]

    # Intent preservation diagnostics
    has_intent_preserving_candidate: bool = False
    intent_preserving_count: int = 0
    repair_postures: list[str] = field(default_factory=list)

    # Metadata
    scene_inventory: list[str] = field(default_factory=list)
    latency_by_stage: dict = field(default_factory=dict)

    @property
    def is_learnable(self) -> bool:
        return self.safe_candidates >= 2

    def validate(self) -> list[str]:
        """Check internal consistency. Returns list of error messages (empty = valid)."""
        errors: list[str] = []
        if self.safe_candidates != len(self.repair_commands):
            errors.append(
                f"safe_candidates={self.safe_candidates} != "
                f"len(repair_commands)={len(self.repair_commands)}"
            )
        if len(self.repair_commands) != len(self.repair_strategies):
            errors.append(
                f"len(repair_commands)={len(self.repair_commands)} != "
                f"len(repair_strategies)={len(self.repair_strategies)}"
            )
        if len(self.feature_vectors) != self.safe_candidates:
            errors.append(
                f"len(feature_vectors)={len(self.feature_vectors)} != "
                f"safe_candidates={self.safe_candidates}"
            )
        if len(self.safety_margins) != self.safe_candidates:
            errors.append(
                f"len(safety_margins)={len(self.safety_margins)} != "
                f"safe_candidates={self.safe_candidates}"
            )
        gate_sum = (
            self.rejected_lint + self.rejected_screen
            + self.rejected_safety + self.safe_candidates
        )
        if gate_sum > self.total_candidates_generated:
            errors.append(
                f"gate outputs ({gate_sum}) exceed "
                f"total_candidates_generated ({self.total_candidates_generated})"
            )
        if self.feature_vectors:
            dims = {len(fv) for fv in self.feature_vectors}
            if len(dims) > 1:
                errors.append(f"inconsistent feature vector dimensions: {dims}")
        return errors

    def to_cache_entry(self) -> CachedScenario:
        from evaluation.candidate_cache import CachedScenario

        return CachedScenario(
            task_id=self.task_id,
            command=self.command,
            scene_context=self.scene_context,
            hazard_category=self.hazard_category,
            ground_truth_safe=self.ground_truth_safe,
            feature_vectors=[np.array(fv) for fv in self.feature_vectors],
            safety_margins=self.safety_margins,
            repair_commands=self.repair_commands,
            repair_strategies=self.repair_strategies,
            total_generated=self.total_candidates_generated,
            rejected_lint=self.rejected_lint,
            rejected_screen=self.rejected_screen,
            rejected_safety=self.rejected_safety,
            rejected_safety_details=self.rejected_safety_details,
            pipeline_latency_ms=sum(self.latency_by_stage.values()),
            scene_inventory=self.scene_inventory,
        )

    def to_dict(self) -> dict:
        return {
            'task_id': self.task_id,
            'split': self.split,
            'hazard_category': self.hazard_category,
            'scene_name': self.scene_name,
            'command': self.command,
            'ground_truth_safe': self.ground_truth_safe,
            'pipeline_detected_unsafe': self.pipeline_detected_unsafe,
            'flagged_dimensions': self.flagged_dimensions,
            'safety_margin': self.safety_margin,
            'total_candidates_generated': self.total_candidates_generated,
            'rejected_lint': self.rejected_lint,
            'rejected_lint_details': self.rejected_lint_details,
            'rejected_screen': self.rejected_screen,
            'rejected_screen_details': self.rejected_screen_details,
            'rejected_safety': self.rejected_safety,
            'rejected_safety_details': self.rejected_safety_details,
            'safe_candidates': self.safe_candidates,
            'repair_commands': self.repair_commands,
            'repair_strategies': self.repair_strategies,
            'repair_action_plans': self.repair_action_plans,
            'feature_vectors': [
                fv if isinstance(fv, list) else fv.tolist()
                for fv in self.feature_vectors
            ],
            'safety_margins': self.safety_margins,
            'has_intent_preserving_candidate': self.has_intent_preserving_candidate,
            'intent_preserving_count': self.intent_preserving_count,
            'repair_postures': self.repair_postures,
            'scene_inventory': self.scene_inventory,
            'latency_by_stage': self.latency_by_stage,
        }

    @classmethod
    def from_dict(cls, d: dict) -> TaskBenchmarkResult:
        return cls(
            task_id=d['task_id'],
            split=d['split'],
            hazard_category=d.get('hazard_category', ''),
            scene_name=d['scene_name'],
            command=d['command'],
            scene_context=d.get('scene_context', ''),
            ground_truth_safe=d['ground_truth_safe'],
            pipeline_detected_unsafe=d['pipeline_detected_unsafe'],
            flagged_dimensions=d.get('flagged_dimensions', []),
            safety_margin=d.get('safety_margin', 0.0),
            total_candidates_generated=d.get('total_candidates_generated', 0),
            rejected_lint=d.get('rejected_lint', 0),
            rejected_lint_details=d.get('rejected_lint_details', []),
            rejected_screen=d.get('rejected_screen', 0),
            rejected_screen_details=d.get('rejected_screen_details', []),
            rejected_safety=d.get('rejected_safety', 0),
            rejected_safety_details=d.get('rejected_safety_details', []),
            safe_candidates=d.get('safe_candidates', 0),
            repair_commands=d.get('repair_commands', []),
            repair_strategies=d.get('repair_strategies', []),
            repair_action_plans=d.get('repair_action_plans', []),
            feature_vectors=d.get('feature_vectors', []),
            safety_margins=d.get('safety_margins', []),
            has_intent_preserving_candidate=d.get('has_intent_preserving_candidate', False),
            intent_preserving_count=d.get('intent_preserving_count', 0),
            repair_postures=d.get('repair_postures', []),
            scene_inventory=d.get('scene_inventory', []),
            latency_by_stage=d.get('latency_by_stage', {}),
        )
