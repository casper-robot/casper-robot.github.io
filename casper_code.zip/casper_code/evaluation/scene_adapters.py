"""
Scene adapters — derive CasperSceneContext from different sources.

BenchmarkSceneAdapter: from cached scene metadata (no LLM calls).
VLMCasperAdapter: from VLM-perceived real scenes (images --> pipeline).

All produce the same CasperSceneContext. The pipeline never needs to
know the source.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Optional

from evaluation import scene_cache

if TYPE_CHECKING:
    from casper.scene_provider import Scene

from casper.scene_provider import _OBJECT_PROPERTIES, _categorize_object


@dataclass
class CasperSceneContext:
    """Two levels of detail:
      - entities/properties/relations: type-level for safety prompts
      - object_instances: instance-level for grounding and action export
    """
    scene_id: str
    entities: list[str]
    properties: dict[str, dict]
    relations: list[dict]
    room_type: str
    prompt_context: str
    object_instances: list[dict] = field(default_factory=list)

    @property
    def entity_set(self) -> set[str]:
        return set(self.entities)

    def get_instances_of(self, object_type: str) -> list[dict]:
        return [o for o in self.object_instances
                if o.get('objectType') == object_type]

    def get_instance_ids(self) -> list[str]:
        return [o['objectId'] for o in self.object_instances
                if 'objectId' in o]


class BenchmarkSceneAdapter:
    """Derive CASPER scene context from cached scene metadata.

    No LLM calls. All relations derived deterministically:
    parentReceptacles -> ON/IN, position distance -> NEAR,
    temperature -> HEAT_SOURCE, receptacleObjectIds -> CONTAINS.
    """

    SURFACE_TYPES = {
        'CounterTop', 'DiningTable', 'CoffeeTable', 'SideTable',
        'Desk', 'Dresser', 'Shelf', 'Ottoman', 'Bed', 'StoveBurner',
    }
    CONTAINER_TYPES = {
        'Fridge', 'Cabinet', 'Drawer', 'Microwave', 'Safe',
        'Box', 'LaundryHamper', 'GarbageCan', 'Toaster',
    }
    HEAT_SOURCES = {'StoveBurner', 'Microwave', 'Toaster'}
    SHARP_OBJECTS = {'Knife', 'ButterKnife'}
    CONSUMABLES = {
        'Apple', 'Banana', 'Bread', 'Egg', 'Lettuce',
        'Potato', 'Tomato',
    }
    NEAR_THRESHOLD = 1.5

    def __init__(self, scene_cache_module=None):
        self.cache = scene_cache_module or scene_cache

    def adapt(self, scene_name: str) -> CasperSceneContext:
        metadata = self.cache.get_scene_metadata(scene_name)
        object_types = metadata.get('object_types', [])
        objects = metadata.get('objects', [])

        entities = list(object_types)
        properties: dict[str, dict] = {}
        relations: list[dict] = []

        if objects:
            for obj in objects:
                obj_type = obj['objectType']
                props: dict = {}
                if obj_type in self.SHARP_OBJECTS:
                    props['sharp'] = True
                if obj_type in self.CONSUMABLES:
                    props['consumable'] = True
                if obj_type in self.HEAT_SOURCES:
                    props['heat_source'] = True
                if obj.get('temperature') and obj['temperature'] != 'RoomTemp':
                    props['temperature'] = obj['temperature']
                if obj.get('pickupable'):
                    props['pickupable'] = True
                if obj.get('openable'):
                    props['openable'] = True
                if props:
                    properties[obj_type] = props
        else:
            for obj_type in object_types:
                known = _OBJECT_PROPERTIES.get(obj_type, {})
                if known:
                    properties[obj_type] = dict(known)

        for obj in objects:
            for parent_id in obj.get('parentReceptacles', []):
                parent_type = parent_id.split('|')[0] if '|' in parent_id else parent_id
                rel_type = 'IN' if parent_type in self.CONTAINER_TYPES else 'ON'
                relations.append({
                    'source': obj['objectType'],
                    'target': parent_type,
                    'relation': rel_type,
                })
            if 'position' in obj:
                for other in objects:
                    if other['objectId'] == obj['objectId']:
                        continue
                    if 'position' not in other:
                        continue
                    dist = self._distance(obj['position'], other['position'])
                    if dist < self.NEAR_THRESHOLD:
                        if (obj['objectType'] in self.SHARP_OBJECTS
                                or obj['objectType'] in self.HEAT_SOURCES
                                or other['objectType'] in self.CONSUMABLES):
                            relations.append({
                                'source': obj['objectType'],
                                'target': other['objectType'],
                                'relation': 'NEAR',
                                'distance': round(dist, 2),
                            })

        seen: set[tuple] = set()
        unique_relations = []
        for r in relations:
            key = (r['source'], r['target'], r['relation'])
            if key not in seen:
                seen.add(key)
                unique_relations.append(r)

        prompt_context = self._render_context(
            scene_name, entities, properties, unique_relations
        )
        room_type = self.cache.infer_scene_type(scene_name)

        return CasperSceneContext(
            scene_id=scene_name,
            entities=entities,
            properties=properties,
            relations=unique_relations,
            room_type=room_type,
            prompt_context=prompt_context,
            object_instances=objects,
        )

    def _render_context(self, scene_name, entities, properties, relations):
        lines = [f"Scene: {scene_name}"]
        lines.append(f"Objects present: {', '.join(sorted(entities))}")
        if properties:
            lines.append("Object properties:")
            for obj, props in sorted(properties.items()):
                prop_str = ', '.join(f"{k}={v}" for k, v in props.items())
                lines.append(f"  - {obj}: {prop_str}")
        if relations:
            lines.append("Relationships:")
            for r in relations:
                lines.append(f"  - {r['source']} {r['relation']} {r['target']}")
        return '\n'.join(lines)

    @staticmethod
    def _distance(pos_a, pos_b):
        return math.sqrt(
            (pos_a['x'] - pos_b['x'])**2
            + (pos_a['y'] - pos_b['y'])**2
            + (pos_a['z'] - pos_b['z'])**2
        )


class VLMCasperAdapter:
    """Derive CASPER scene context from a VLM-perceived Scene.

    Bridges casper.vlm_scene perception output into the pipeline by
    extracting entities, properties, and hazard-aware spatial relations
    from the Scene object graph.
    """

    HAZARD_TYPES = {'burn', 'cut', 'choking', 'poisoning', 'drowning', 'fall', 'poke'}

    def adapt(self, scene: Scene) -> CasperSceneContext:
        entities = scene.object_names
        properties: dict[str, dict] = {}

        for obj in scene.objects:
            if obj.properties:
                properties[obj.name] = dict(obj.properties)

        relations = self._extract_relations(scene)

        prompt_context = scene.scene_context

        return CasperSceneContext(
            scene_id=scene.scene_id,
            entities=entities,
            properties=properties,
            relations=relations,
            room_type=scene.room_type,
            prompt_context=prompt_context,
        )

    def _extract_relations(self, scene: Scene) -> list[dict]:
        """Extract relations from VLM edges if available, else infer."""
        relations: list[dict] = []

        # Use VLM-provided edges if available
        vlm_edges = getattr(scene, '_vlm_edges', [])
        if vlm_edges:
            for edge in vlm_edges:
                if not isinstance(edge, dict):
                    continue
                source = edge.get('source', '')
                target = edge.get('target', '')
                relation = edge.get('relation', 'NEAR').upper()
                if source and target:
                    relations.append({
                        'source': source,
                        'target': target,
                        'relation': relation,
                    })

        # Supplement with inferred relations if VLM edges are sparse
        if len(relations) < 3:
            relations.extend(self._infer_relations(scene))

        seen: set[tuple] = set()
        unique = []
        for r in relations:
            key = (r['source'], r['target'], r['relation'])
            if key not in seen:
                seen.add(key)
                unique.append(r)

        return unique

    def _infer_relations(self, scene: Scene) -> list[dict]:
        """Fallback: infer relations from object properties."""
        relations: list[dict] = []
        hazardous = scene.hazardous_objects
        receptacles = [
            o for o in scene.objects if o.properties.get('receptacle')
        ]

        for haz in hazardous:
            for other in scene.objects:
                if other.name == haz.name:
                    continue
                if other.properties.get('pickupable'):
                    relations.append({
                        'source': haz.name,
                        'target': other.name,
                        'relation': 'NEAR',
                    })

        for obj in scene.objects:
            if not obj.properties.get('pickupable'):
                continue
            for recep in receptacles:
                if recep.name == obj.name:
                    continue
                relations.append({
                    'source': obj.name,
                    'target': recep.name,
                    'relation': 'ON',
                })
                break

        return relations
