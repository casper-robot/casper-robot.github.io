"""
Analysis and Reporting
=======================

Automated results aggregation, statistical analysis, and report
for CASPER Experiments A/B/C.

Key functions:
    aggregate_trials              - Median, mean, 95% CI across trials
    convergence_table             - Experiment B: convergence times per profile
    contraction_curves            - Experiment B: posterior tr(Sigma) over time
    regret_curves                 - Experiment B: cumulative regret per strategy
    transfer_accuracy             - Experiment C: cross-category transfer accuracy
    generate_report               - Markdown report with tables and figure refs
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

import numpy as np

from evaluation.experiments import TrialResult
from evaluation.simulated_user import ALL_PROFILES

logger = logging.getLogger(__name__)


# Statistical Aggregation

def _ci95(values: list[float]) -> tuple[float, float]:
    """Compute 95% confidence interval using normal approximation."""
    arr = np.array([v for v in values if v is not None])
    if len(arr) == 0:
        return (0.0, 0.0)
    if len(arr) == 1:
        return (arr[0], arr[0])
    mean = np.mean(arr)
    se = np.std(arr, ddof=1) / np.sqrt(len(arr))
    return (float(mean - 1.96 * se), float(mean + 1.96 * se))


def _median_iqr(values: list) -> dict:
    """Compute median and IQR."""
    arr = np.array([v for v in values if v is not None])
    if len(arr) == 0:
        return {"median": None, "q25": None, "q75": None, "n": 0}
    return {
        "median": float(np.median(arr)),
        "q25": float(np.percentile(arr, 25)),
        "q75": float(np.percentile(arr, 75)),
        "n": len(arr),
    }


def aggregate_trials(results: list[TrialResult]) -> dict:
    """
    Aggregate results across trials, grouped by (profile, strategy).

    Returns dict keyed by (profile_name, strategy_name) with
    summary statistics for each metric.
    """
    groups = {}
    for r in results:
        key = (r.profile_name, r.strategy_name)
        groups.setdefault(key, []).append(r)

    aggregated = {}
    for key, trials in groups.items():
        convergence_times = [
            t.convergence_time for t in trials if t.convergence_time is not None
        ]
        final_errors = [
            t.tracker.steps[-1].weight_recovery_error
            for t in trials if t.tracker.steps
        ]
        final_accuracies = [
            t.tracker.steps[-1].prediction_accuracy
            for t in trials
            if t.tracker.steps and t.tracker.steps[-1].prediction_accuracy is not None
        ]
        cum_regrets = [
            t.tracker.cumulative_regret for t in trials
        ]
        violations = [
            t.tracker.safety_violation_count for t in trials
        ]

        aggregated[key] = {
            "n_trials": len(trials),
            "convergence_time": _median_iqr(convergence_times),
            "convergence_rate": (
                len(convergence_times) / len(trials) if trials else 0.0
            ),
            "final_weight_error": {
                "mean": float(np.mean(final_errors)) if final_errors else None,
                "ci95": _ci95(final_errors),
            },
            "final_prediction_accuracy": {
                "mean": float(np.mean(final_accuracies)) if final_accuracies else None,
                "ci95": _ci95(final_accuracies),
            },
            "cumulative_regret": {
                "mean": float(np.mean(cum_regrets)) if cum_regrets else None,
                "ci95": _ci95(cum_regrets),
            },
            "safety_violations_total": sum(violations),
        }

    return aggregated


# Experiment B: Convergence Table

def convergence_table(results: list[TrialResult]) -> list[dict]:
    """
    Experiment B: Table of median convergence time per profile with CIs.

    Returns list of dicts, one per profile.
    """
    agg = aggregate_trials(results)
    rows = []
    for (profile, strategy), stats in agg.items():
        rows.append({
            "profile": profile,
            "strategy": strategy,
            "median_convergence_time": stats["convergence_time"]["median"],
            "convergence_q25": stats["convergence_time"]["q25"],
            "convergence_q75": stats["convergence_time"]["q75"],
            "convergence_rate": stats["convergence_rate"],
            "n_trials": stats["n_trials"],
        })
    return rows


# Experiment B: Posterior Contraction Curves

def contraction_curves(
    results: dict[str, list[TrialResult]],
    T_max: int = 30,
) -> dict[str, dict]:
    """
    Experiment B: tr(Sigma_t) curves for active vs passive exploration.

    Returns dict with 'active' and 'passive' keys, each containing
    per-profile arrays of mean tr(Sigma) at each time step.
    """
    output = {}
    for label, trials in results.items():
        by_profile = {}
        for trial in trials:
            profile = trial.profile_name
            by_profile.setdefault(profile, []).append(trial)

        profile_curves = {}
        for profile, profile_trials in by_profile.items():
            # Collect sigma_trace at each time step
            traces = []
            for t in profile_trials:
                trajectory = t.tracker.get_metric_trajectory("sigma_trace")
                traces.append(trajectory)

            # Align to same length and compute mean
            max_len = max(len(tr) for tr in traces) if traces else 0
            aligned = np.full((len(traces), max_len), np.nan)
            for i, tr in enumerate(traces):
                aligned[i, :len(tr)] = tr

            profile_curves[profile] = {
                "mean": np.nanmean(aligned, axis=0).tolist(),
                "std": np.nanstd(aligned, axis=0).tolist(),
                "n_trials": len(traces),
            }
        output[label] = profile_curves

    return output


# Experiment B: Regret Curves

def regret_curves(
    results: list[TrialResult],
    T_max: int = 30,
) -> dict[str, dict]:
    """
    Experiment B: Cumulative regret curves per strategy.

    Returns dict keyed by strategy name, each with mean/std arrays.
    """
    by_strategy = {}
    for r in results:
        by_strategy.setdefault(r.strategy_name, []).append(r)

    output = {}
    for strategy, trials in by_strategy.items():
        trajectories = []
        for t in trials:
            traj = t.tracker.get_metric_trajectory("cumulative_regret")
            trajectories.append(traj)

        max_len = max(len(tr) for tr in trajectories) if trajectories else 0
        aligned = np.full((len(trajectories), max_len), np.nan)
        for i, tr in enumerate(trajectories):
            aligned[i, :len(tr)] = tr

        output[strategy] = {
            "mean": np.nanmean(aligned, axis=0).tolist(),
            "std": np.nanstd(aligned, axis=0).tolist(),
            "n_trials": len(trajectories),
        }

    return output


# Experiment C: Transfer Accuracy

def transfer_accuracy(results: dict[str, list[TrialResult]]) -> list[dict]:
    """
    Experiment C: Prediction accuracy on held-out task categories.

    Returns per-profile train accuracy vs test accuracy.
    """
    rows = []
    train_by_profile = {}
    test_by_profile = {}

    for r in results.get("train", []):
        train_by_profile.setdefault(r.profile_name, []).append(r)
    for r in results.get("test", []):
        test_by_profile.setdefault(r.profile_name, []).append(r)

    for profile in set(list(train_by_profile.keys()) + list(test_by_profile.keys())):
        train_accs = []
        for t in train_by_profile.get(profile, []):
            if t.tracker.steps:
                acc = t.tracker.steps[-1].prediction_accuracy
                if acc is not None:
                    train_accs.append(acc)

        test_accs = []
        for t in test_by_profile.get(profile, []):
            if t.tracker.steps:
                acc = t.tracker.steps[-1].prediction_accuracy
                if acc is not None:
                    test_accs.append(acc)

        rows.append({
            "profile": profile,
            "train_accuracy_mean": float(np.mean(train_accs)) if train_accs else None,
            "train_accuracy_ci95": _ci95(train_accs),
            "test_accuracy_mean": float(np.mean(test_accs)) if test_accs else None,
            "test_accuracy_ci95": _ci95(test_accs),
            "transfer_gap": (
                (float(np.mean(train_accs)) - float(np.mean(test_accs)))
                if train_accs and test_accs else None
            ),
        })

    return rows



# Report Generation

def generate_report(
    all_results: dict,
    output_dir: str = "results",
) -> str:

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    lines = [
        "# CASPER Evaluation Report",
        "",
        "## Overview",
        "",
        "Simulated evaluation of the CASPER preference learning and safety pipeline.",
        "",
    ]

    # Experiment B: Convergence
    conv_key = "B_convergence" if "B_convergence" in all_results else None
    if conv_key:
        lines.extend([
            "## Experiment B: Convergence Speed",
            "",
        ])
        table = convergence_table(all_results[conv_key])
        lines.append("| Profile | Median Steps | Q25-Q75 | Conv. Rate |")
        lines.append("|---------|-------------|---------|------------|")
        for row in table:
            med = row["median_convergence_time"]
            med_str = f"{med:.1f}" if med is not None else "N/A"
            q25 = row["convergence_q25"]
            q75 = row["convergence_q75"]
            iqr_str = (
                f"{q25:.1f}-{q75:.1f}"
                if q25 is not None and q75 is not None
                else "N/A"
            )
            lines.append(
                f"| {row['profile']} | {med_str} | {iqr_str} | "
                f"{row['convergence_rate']:.1%} |"
            )
        lines.append("")

    # Experiment B: Regret
    regret_key = "B_regret_curves" if "B_regret_curves" in all_results else None
    if regret_key:
        lines.extend([
            "## Experiment B: Cumulative Regret",
            "",
        ])
        agg = aggregate_trials(all_results[regret_key])
        lines.append("| Strategy | Mean Regret | 95% CI |")
        lines.append("|----------|------------|--------|")
        for (profile, strategy), stats in sorted(agg.items()):
            mean = stats["cumulative_regret"]["mean"]
            ci = stats["cumulative_regret"]["ci95"]
            mean_str = f"{mean:.2f}" if mean is not None else "N/A"
            ci_str = f"[{ci[0]:.2f}, {ci[1]:.2f}]" if ci else "N/A"
            lines.append(f"| {profile} / {strategy} | {mean_str} | {ci_str} |")
        lines.append("")

    # Write report
    report_text = "\n".join(lines)
    report_path = output_path / "evaluation_report.md"
    report_path.write_text(report_text)

    # Save raw results as JSON
    json_path = output_path / "raw_results.json"
    serializable = _make_serializable(all_results)
    json_path.write_text(json.dumps(serializable, indent=2, default=str))

    logger.info(f"Report saved to {report_path}")
    return str(report_path)


def _make_serializable(obj):
    """Convert numpy types and complex objects to JSON-serializable form."""
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if isinstance(obj, dict):
        return {str(k): _make_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_make_serializable(v) for v in obj]
    if isinstance(obj, TrialResult):
        return obj.to_dict()
    return obj



# Plotting (matplotlib)

def generate_plots(
    all_results: dict,
    output_dir: str = "results",
) -> list[str]:

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not installed; skipping plot generation")
        return []

    output_path = Path(output_dir) / "figures"
    output_path.mkdir(parents=True, exist_ok=True)
    saved = []

    if "B_convergence" in all_results:
        fig_path = _plot_convergence(
            all_results["B_convergence"], output_path, plt
        )
        if fig_path:
            saved.append(fig_path)

    if "B_contraction" in all_results:
        fig_path = _plot_contraction(
            all_results["B_contraction"], output_path, plt
        )
        if fig_path:
            saved.append(fig_path)

    if "B_regret_curves" in all_results:
        fig_path = _plot_regret(
            all_results["B_regret_curves"], output_path, plt
        )
        if fig_path:
            saved.append(fig_path)

    logger.info(f"Generated {len(saved)} figures in {output_path}")
    return saved


def _plot_convergence(results: list, output_path: Path, plt) -> Optional[str]:
    """Convergence bar chart (median steps per profile)."""
    table = convergence_table(results)
    if not table:
        return None

    profiles = [r["profile"] for r in table]
    medians = [r["median_convergence_time"] or 0 for r in table]
    q25s = [r["convergence_q25"] or 0 for r in table]
    q75s = [r["convergence_q75"] or 0 for r in table]
    errors = [[m - q for m, q in zip(medians, q25s)],
              [q - m for m, q in zip(medians, q75s)]]

    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(profiles))
    ax.bar(x, medians, yerr=errors, capsize=5, color="#2563eb", alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(profiles, rotation=30, ha="right")
    ax.set_ylabel("Median Convergence Steps")
    ax.set_title("Experiment B: Convergence Speed by User Profile")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()

    path = str(output_path / "fig1_convergence.pdf")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def _plot_contraction(results: dict, output_path: Path, plt) -> Optional[str]:
    """Posterior contraction curves: tr(Sigma) active vs passive."""
    fig, ax = plt.subplots(figsize=(8, 5))
    colors = {"active": "#2563eb", "passive": "#94a3b8"}
    styles = {"active": "-", "passive": "--"}

    for label, profile_curves in results.items():
        color = colors.get(label, "#666")
        style = styles.get(label, "-")
        for profile, data in profile_curves.items():
            mean = np.array(data["mean"])
            std = np.array(data.get("std", np.zeros_like(mean)))
            t = np.arange(len(mean))
            ax.plot(t, mean, style, color=color, alpha=0.7,
                    label=f"{label}/{profile}")
            ax.fill_between(t, mean - std, mean + std,
                           color=color, alpha=0.1)

    ax.set_xlabel("Interaction Step")
    ax.set_ylabel("tr(Sigma)")
    ax.set_title("Experiment B: Posterior Contraction (Active vs Passive)")
    ax.legend(fontsize=7, ncol=2)
    ax.grid(alpha=0.3)
    fig.tight_layout()

    path = str(output_path / "fig2_contraction.pdf")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def _plot_regret(results: list, output_path: Path, plt) -> Optional[str]:
    """Cumulative regret curves per strategy."""
    curves = regret_curves(results)
    if not curves:
        return None

    fig, ax = plt.subplots(figsize=(8, 5))
    strategy_colors = {
        "CASPER": "#2563eb",
        "B2_random": "#f59e0b",
        "B3_greedy": "#10b981",
        "B4_thompson": "#8b5cf6",
    }

    for strategy, data in curves.items():
        mean = np.array(data["mean"])
        std = np.array(data.get("std", np.zeros_like(mean)))
        t = np.arange(len(mean))
        color = strategy_colors.get(strategy, "#666")
        ax.plot(t, mean, color=color, label=strategy, linewidth=2)
        ax.fill_between(t, mean - std, mean + std, color=color, alpha=0.15)

    ax.set_xlabel("Interaction Step")
    ax.set_ylabel("Cumulative Regret")
    ax.set_title("Experiment B: Cumulative Regret (CASPER vs Baselines)")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()

    path = str(output_path / "fig3_regret.pdf")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path
