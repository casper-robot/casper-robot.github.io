"""
Trace recorder for reviewer artifact export.

Captures raw LLM prompts and responses, parsed objects, graph
construction details, validation logs, and scoring breakdowns
into a structured per-task directory.

Files are sanitized on write — API keys, tokens, and local paths
are redacted before they touch disk.

Serialization utilities are inlined to keep the module self-contained.
"""

import dataclasses
import enum
import json
import re
import logging
from pathlib import Path
from typing import Any, Dict

logger = logging.getLogger(__name__)

_SENSITIVE_PATTERNS = [
    (re.compile(r'sk-[a-zA-Z0-9]{20,}'), '[REDACTED_API_KEY]'),
    (re.compile(r'sk-ant-[a-zA-Z0-9\-]{20,}'), '[REDACTED_API_KEY]'),
    (re.compile(r'Bearer [a-zA-Z0-9\-._~+/]+=*'), '[REDACTED_TOKEN]'),
    (re.compile(r'api[_-]?key["\s:=]+["\']?[a-zA-Z0-9\-]{16,}'),
     'api_key: [REDACTED]'),
    (re.compile(r'/home/[a-zA-Z0-9_]+/'), '/home/[USER]/'),
    (re.compile(r'/Users/[a-zA-Z0-9_]+/'), '/Users/[USER]/'),
    (re.compile(r'C:\\\\Users\\\\[a-zA-Z0-9_]+\\\\'),
     'C:\\\\Users\\\\[USER]\\\\'),
    (re.compile(r'C:\\Users\\[a-zA-Z0-9_]+\\'),
     'C:\\Users\\[USER]\\'),
]


def _sanitize(text: str) -> str:
    for pattern, replacement in _SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def _sanitize_with_counts(text: str) -> tuple:
    counts: Dict[str, int] = {}
    for pattern, replacement in _SENSITIVE_PATTERNS:
        matches = len(pattern.findall(text))
        if matches > 0:
            counts[replacement] = counts.get(replacement, 0) + matches
            text = pattern.sub(replacement, text)
    return text, counts


def _serialize_trace_object(obj: Any) -> Any:
    """Convert dataclass/enum objects to clean JSON-ready dicts."""
    if obj is None:
        return None
    if isinstance(obj, enum.Enum):
        return obj.value
    if isinstance(obj, set):
        return sorted(str(x) for x in obj) if obj else None
    if isinstance(obj, float):
        return round(obj, 4)
    if isinstance(obj, (int, str, bool)):
        return obj
    if isinstance(obj, bytes):
        return obj.decode('utf-8', errors='replace')
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        result = {}
        for f in dataclasses.fields(obj):
            val = getattr(obj, f.name)
            serialized = _serialize_trace_object(val)
            if serialized is None:
                continue
            if isinstance(serialized, (list, dict)) and len(serialized) == 0:
                continue
            result[f.name] = serialized
        return result
    if isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            serialized = _serialize_trace_object(v)
            if serialized is not None:
                result[str(k)] = serialized
        return result if result else None
    if isinstance(obj, (list, tuple)):
        items = [_serialize_trace_object(x) for x in obj]
        items = [x for x in items if x is not None]
        return items if items else None
    return str(obj)


def _prune_empty_fields(obj: Any) -> Any:
    """Remove null, empty string, empty list, empty dict fields recursively."""
    if isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            pruned = _prune_empty_fields(v)
            if pruned is None:
                continue
            if isinstance(pruned, str) and pruned == '':
                continue
            if isinstance(pruned, (list, dict)) and len(pruned) == 0:
                continue
            result[k] = pruned
        return result if result else None
    if isinstance(obj, list):
        items = [_prune_empty_fields(x) for x in obj]
        items = [x for x in items if x is not None]
        return items if items else None
    return obj


class TraceRecorder:
    """Records pipeline stages to structured files for reviewer audit."""

    def __init__(self, root_dir: str, task_id: str):
        self.dir = Path(root_dir) / task_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self._step = 0
        self._manifest: list[dict] = []
        self._redaction_counts: Dict[str, int] = {}

    def save(self, label: str, obj: Any, fmt: str = "json"):
        name = f"{self._step:02d}_{label}.{fmt}"
        path = self.dir / name
        self._step += 1
        try:
            if fmt == "json":
                cleaned = _serialize_trace_object(obj)
                if cleaned is None:
                    cleaned = {}
                cleaned = _prune_empty_fields(cleaned)
                if cleaned is None:
                    cleaned = {}
                text = json.dumps(cleaned, indent=2, default=str,
                                  ensure_ascii=False)
            else:
                text = str(obj)
            text, counts = _sanitize_with_counts(text)
            for k, v in counts.items():
                self._redaction_counts[k] = (
                    self._redaction_counts.get(k, 0) + v
                )
            path.write_text(text, encoding="utf-8")
            self._manifest.append({
                'step': self._step - 1, 'label': label,
                'file': name, 'format': fmt,
            })
        except Exception as e:
            logger.warning(f"[TraceRecorder] Failed to write {name}: {e}")

    def save_manifest(self):
        self.save("manifest", self._manifest)
        if self._redaction_counts:
            self.save("sanitization_report", {
                "total_redactions": sum(self._redaction_counts.values()),
                "by_pattern": self._redaction_counts,
            })

    @property
    def active(self):
        return True


class NullRecorder:
    """No-op recorder when artifact export is disabled."""

    def save(self, label, obj, fmt="json"):
        pass

    def save_manifest(self):
        pass

    @property
    def active(self):
        return False
