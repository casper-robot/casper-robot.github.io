"""
Experiment Core Functions
==========================

Core trial loop, posterior update, and experiment functions for the
CASPER evaluation framework.

Experiments:
    A  Safety Detection:         SafeAgentBench confusion matrix (benchmark_runner + benchmark_safety_eval)
    B  Preference Learning:      7 profiles × 5 strategies, T=30, 20 trials (run_trial / run_trial_cached)
    C  Cross-Hazard Transfer:    Leave-2-out, strategy vs text features (run_transfer_experiment)

Key functions:
    run_trial()              - Single trial with live pipeline (Experiment B)
    run_trial_cached()       - Single trial from pre-computed cache, zero LLM cost (Experiment B)
    run_transfer_experiment() - Leave-2-out cross-category transfer (Experiment C)
"""

from __future__ import annotations

import copy
import logging
from dataclasses import dataclass
from typing import Optional

import numpy as np

from evaluation.simulated_user import (
    SimulatedUser,
    SimulatedUserFactory,
    UserProfile,
    ALL_PROFILES,
    FEATURE_DIM,
)
from evaluation.candidate_cache import CandidateCache, CachedScenario
from evaluation.metrics import (
    MetricsTracker,
    generate_test_pairs,
    TestPair,
)
from evaluation.baselines import (
    SelectionStrategy,
    CasperStrategy,
    CasperConfig,
    AblatedCasperStrategy,
)

logger = logging.getLogger(__name__)


# Configuration

@dataclass
class ExperimentConfig:
    """Configuration for running experiments."""
    n_trials: int = 20            # Trials per (profile, strategy) pair
    T_max: int = 30               # Max interactions per trial
    n_test_pairs: int = 50        # Held-out pairs for M1
    sigma_0: float = 0.5          # Prior std dev (σ₀²·I prior covariance)
    beta_casper: float = 0.3      # CASPER safety margin weight
    lam_casper: float = 0.5       # CASPER exploration weight
    epsilon_casper: float = 0.1   # Autonomy threshold
    alpha_auto: float = 0.3       # Soft-accept damping for autonomous updates
    seed: int = 42

    def casper_config(self) -> CasperConfig:
        return CasperConfig(
            beta=self.beta_casper,
            lam=self.lam_casper,
            epsilon=self.epsilon_casper,
        )


# Trial Result

@dataclass
class TrialResult:
    """Result of a single simulation trial."""
    profile_name: str
    strategy_name: str
    trial_id: int
    tracker: MetricsTracker
    final_mu: np.ndarray
    final_sigma: np.ndarray           # Full posterior covariance matrix
    final_sigma_trace: float
    convergence_time: Optional[int]
    autonomy_transition_time: Optional[int]
    config_label: str = ""  # Extra label (e.g., β_temp value)
    drift_at: Optional[int] = None
    drift_to_profile: str = ""

    def to_dict(self) -> dict:
        summary = self.tracker.summary()
        summary.update({
            "profile_name": self.profile_name,
            "strategy_name": self.strategy_name,
            "trial_id": self.trial_id,
            "final_mu": self.final_mu.tolist(),
            "final_sigma": self.final_sigma.tolist(),
            "final_sigma_trace": self.final_sigma_trace,
            "convergence_time": self.convergence_time,
            "autonomy_transition_time": self.autonomy_transition_time,
            "config_label": self.config_label,
            "drift_at": self.drift_at,
            "drift_to_profile": self.drift_to_profile,
        })
        return summary


# Posterior Save / Load

def save_posteriors(
    results: list[TrialResult],
    path: str,
    strategy_filter: str = "CASPER",
) -> dict[str, dict]:
    """Save converged posteriors (μ, Σ) per profile to a JSON file.

    Averages final_mu and final_sigma across trials for each profile,
    filtered to the specified strategy. Returns the saved dict.
    """
    from collections import defaultdict
    by_profile: dict[str, list[TrialResult]] = defaultdict(list)
    for r in results:
        if r.strategy_name == strategy_filter:
            by_profile[r.profile_name].append(r)

    posteriors: dict[str, dict] = {}
    for profile_name, trials in by_profile.items():
        mu_avg = np.mean([t.final_mu for t in trials], axis=0)
        sigma_avg = np.mean([t.final_sigma for t in trials], axis=0)
        posteriors[profile_name] = {
            "mu": mu_avg.tolist(),
            "sigma": sigma_avg.tolist(),
            "n_trials": len(trials),
            "avg_convergence_time": np.mean([
                t.convergence_time for t in trials
                if t.convergence_time is not None
            ]).item() if any(t.convergence_time is not None for t in trials) else None,
        }

    import json
    from pathlib import Path
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(posteriors, indent=2), encoding="utf-8")
    logger.info(
        f"Saved posteriors for {len(posteriors)} profiles to {path}"
    )
    return posteriors


def load_posteriors(path: str) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Load saved posteriors. Returns {profile_name: (mu, sigma)}."""
    import json
    from pathlib import Path
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    result = {}
    for profile_name, entry in data.items():
        mu = np.array(entry["mu"], dtype=np.float64)
        sigma = np.array(entry["sigma"], dtype=np.float64)
        result[profile_name] = (mu, sigma)
    logger.info(f"Loaded posteriors for {len(result)} profiles from {path}")
    return result


# Core Trial Loop

def _initialize_posterior(
    config: ExperimentConfig,
    mu_0: Optional[np.ndarray] = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Initialize prior mean and covariance."""
    if mu_0 is None:
        mu_0 = np.zeros(FEATURE_DIM, dtype=np.float64)
        _default = [-0.3, 0.5, 0.3, 0.8, 0.3, -0.1, -0.2, -0.1, 0.0, -0.1]
        mu_0[:len(_default)] = _default[:FEATURE_DIM]
    else:
        mu_0 = np.array(mu_0, dtype=np.float64)
    sigma_0 = (config.sigma_0 ** 2) * np.eye(FEATURE_DIM, dtype=np.float64)
    return mu_0, sigma_0


def _laplace_update(
    mu: np.ndarray,
    sigma: np.ndarray,
    features_chosen: np.ndarray,
    features_rejected: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:

    JITTER = 1e-8
    delta = features_chosen - features_rejected
    logit = float(mu @ delta)

    # Numerically stable sigmoid
    if logit >= 0:
        z = np.exp(-logit)
        s = 1.0 / (1.0 + z)
    else:
        z = np.exp(logit)
        s = z / (1.0 + z)

    # Mean update
    mu_new = mu + sigma @ delta * (1.0 - s)

    # Covariance update
    sigma_inv = np.linalg.inv(sigma)
    sigma_inv += s * (1.0 - s) * np.outer(delta, delta)
    sigma_inv += JITTER * np.eye(FEATURE_DIM)
    sigma_new = np.linalg.inv(sigma_inv)
    sigma_new = 0.5 * (sigma_new + sigma_new.T)

    return mu_new, sigma_new


def _soft_accept_update(
    mu: np.ndarray,
    sigma: np.ndarray,
    feature_vectors: list[np.ndarray],
    safety_margins: list[float],
    strategy: CasperStrategy,
    alpha: float,
) -> tuple[np.ndarray, np.ndarray]:
    scores = [
        strategy._score(f, sm, mu, sigma)
        for f, sm in zip(feature_vectors, safety_margins)
    ]
    ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
    best, second = ranked[0], ranked[1]
    chosen_scaled = feature_vectors[best] * alpha + feature_vectors[second] * (1 - alpha)
    return _laplace_update(mu, sigma, chosen_scaled, feature_vectors[second])


def _compute_normalized_convergence(
    tracker: MetricsTracker,
    threshold: float = 0.50,
    consecutive: int = 3,
) -> int | None:
    accs = tracker.get_metric_trajectory("prediction_accuracy")
    count = 0
    for t, acc in enumerate(accs):
        if acc is None:
            count = 0
            continue
        ni = tracker.normalized_improvement(acc)
        if ni >= threshold:
            count += 1
            if count >= consecutive:
                return tracker.steps[t - consecutive + 1].t
        else:
            count = 0
    return None


def run_trial(
    user: SimulatedUser,
    strategy: SelectionStrategy,
    bank,
    config: ExperimentConfig,
    test_pairs: list[TestPair],
    rng: np.random.Generator,
    mu_0: Optional[np.ndarray] = None,
    trial_id: int = 0,
    config_label: str = "",
) -> TrialResult:

    mu, sigma = _initialize_posterior(config, mu_0)
    tracker = MetricsTracker(user, test_pairs)
    tracker.compute_prior_baseline(mu)
    casper_strat = isinstance(strategy, (CasperStrategy, AblatedCasperStrategy))

    for t in range(config.T_max):
        # 1. Sample scenario
        scenario = bank.sample(1, rng=rng)[0]
        candidates = scenario.safe_candidates()
        if len(candidates) < 2:
            continue  # Skip scenarios with insufficient candidates

        feature_vectors = [c.features for c in candidates]
        safety_margins = [c.safety_margin for c in candidates]

        # 2. Check autonomy gate (CASPER only)
        autonomous = False
        if casper_strat and isinstance(strategy, CasperStrategy):
            autonomous = strategy.should_be_autonomous(feature_vectors, sigma)

        if autonomous:
            idx = strategy.select(feature_vectors, safety_margins, mu, sigma)
            selected_features = feature_vectors[idx]
            mu, sigma = _soft_accept_update(
                mu, sigma, feature_vectors, safety_margins,
                strategy, config.alpha_auto,
            )
            selection_mode = "autonomous"
        else:
            # Pairwise mode: select pair, user chooses
            idx_i, idx_j = strategy.select_pair(
                feature_vectors, safety_margins, mu, sigma
            )
            choice = user.choose_pairwise(
                feature_vectors[idx_i], feature_vectors[idx_j]
            )
            if choice == 0:
                chosen_idx, rejected_idx = idx_i, idx_j
            else:
                chosen_idx, rejected_idx = idx_j, idx_i

            selected_features = feature_vectors[chosen_idx]

            # Update posterior
            mu, sigma = _laplace_update(
                mu, sigma,
                feature_vectors[chosen_idx],
                feature_vectors[rejected_idx],
            )
            selection_mode = "pairwise"

        # 3. Record metrics
        safety_violation = not candidates[0].is_safe  # All candidates should be safe
        tracker.record_step(
            t=t,
            mu=mu,
            sigma=sigma,
            selected_features=selected_features,
            candidate_features=feature_vectors,
            safety_violation=safety_violation,
            selection_mode=selection_mode,
        )

    return TrialResult(
        profile_name=user.name,
        strategy_name=strategy.name,
        trial_id=trial_id,
        tracker=tracker,
        final_mu=mu.copy(),
        final_sigma=sigma.copy(),
        final_sigma_trace=float(np.trace(sigma)),
        convergence_time=_compute_normalized_convergence(tracker),
        autonomy_transition_time=tracker.autonomy_transition_time(),
        config_label=config_label,
    )


# Experiment B: Preference Learning (cached)

def _generate_test_pairs_cached(
    scenarios: list[CachedScenario],
    user: SimulatedUser,
    n_pairs: int = 50,
    rng: np.random.Generator | None = None,
) -> list[TestPair]:
    """Generate held-out test pairs from cached scenarios."""
    if rng is None:
        rng = np.random.default_rng()
    feature_lists = [s.feature_vectors for s in scenarios if s.is_learnable]
    if not feature_lists:
        return []
    return generate_test_pairs(feature_lists, user, n_pairs=n_pairs, rng=rng)


def run_trial_cached(
    user: SimulatedUser,
    strategy: SelectionStrategy,
    cache: CandidateCache,
    config: ExperimentConfig,
    test_pairs: list[TestPair],
    rng: np.random.Generator,
    mu_0: Optional[np.ndarray] = None,
    trial_id: int = 0,
    config_label: str = "",
    drift_at: int | None = None,
    drift_to_profile: UserProfile | None = None,
) -> TrialResult:
    """Run a single learning trial from pre-computed cache. Zero LLM cost.

    Identical to run_trial() but reads feature vectors and safety margins
    from CachedScenario objects instead of evaluating the pipeline live.
    """
    mu, sigma = _initialize_posterior(config, mu_0)
    tracker = MetricsTracker(user, test_pairs)
    tracker.compute_prior_baseline(mu)
    casper_strat = isinstance(strategy, (CasperStrategy, AblatedCasperStrategy))

    learnable = cache.get_learnable_scenarios()
    if not learnable:
        return TrialResult(
            profile_name=user.name,
            strategy_name=strategy.name,
            trial_id=trial_id,
            tracker=tracker,
            final_mu=mu.copy(),
            final_sigma=sigma.copy(),
            final_sigma_trace=float(np.trace(sigma)),
            convergence_time=None,
            autonomy_transition_time=None,
            config_label=config_label,
        )

    for t in range(config.T_max):
        if (drift_at is not None
                and t == drift_at
                and drift_to_profile is not None):
            user.theta_true = np.array(
                drift_to_profile.theta_true, dtype=np.float64
            )
            tracker.theta_true = user.theta_true.copy()
            new_test_pairs = _generate_test_pairs_cached(
                learnable, user, n_pairs=len(test_pairs) or 50, rng=rng,
            )
            tracker.test_pairs = new_test_pairs

        idx = rng.integers(0, len(learnable))
        scenario = learnable[idx]

        feature_vectors = scenario.feature_vectors
        safety_margins = scenario.safety_margins
        if len(feature_vectors) < 2:
            continue

        autonomous = False
        if casper_strat and isinstance(strategy, CasperStrategy):
            autonomous = strategy.should_be_autonomous(feature_vectors, sigma)

        if autonomous:
            sel = strategy.select(feature_vectors, safety_margins, mu, sigma)
            selected_features = feature_vectors[sel]
            mu, sigma = _soft_accept_update(
                mu, sigma, feature_vectors, safety_margins,
                strategy, config.alpha_auto,
            )
            selection_mode = "autonomous"
        else:
            idx_i, idx_j = strategy.select_pair(
                feature_vectors, safety_margins, mu, sigma,
            )
            choice = user.choose_pairwise(
                feature_vectors[idx_i], feature_vectors[idx_j],
            )
            if choice == 0:
                chosen_idx, rejected_idx = idx_i, idx_j
            else:
                chosen_idx, rejected_idx = idx_j, idx_i

            selected_features = feature_vectors[chosen_idx]
            mu, sigma = _laplace_update(
                mu, sigma,
                feature_vectors[chosen_idx],
                feature_vectors[rejected_idx],
            )
            selection_mode = "pairwise"

        tracker.record_step(
            t=t,
            mu=mu,
            sigma=sigma,
            selected_features=selected_features,
            candidate_features=feature_vectors,
            safety_violation=False,
            selection_mode=selection_mode,
        )

    return TrialResult(
        profile_name=user.name,
        strategy_name=strategy.name,
        trial_id=trial_id,
        tracker=tracker,
        final_mu=mu.copy(),
        final_sigma=sigma.copy(),
        final_sigma_trace=float(np.trace(sigma)),
        convergence_time=_compute_normalized_convergence(tracker),
        autonomy_transition_time=tracker.autonomy_transition_time(),
        config_label=config_label,
        drift_at=drift_at,
        drift_to_profile=drift_to_profile.name if drift_to_profile else "",
    )


def _compute_text_features(command: str, dim: int = 10) -> np.ndarray:
    """TF-IDF-like bag-of-words feature vector for Ablation D."""
    stop_words = {
        'the', 'a', 'an', 'to', 'on', 'in', 'for', 'with', 'and',
        'of', 'is', 'it', 'that', 'this', 'by', 'from', 'or', 'at',
    }
    tokens = [
        t for t in command.lower().split()
        if t not in stop_words and len(t) > 2
    ]
    vec = np.zeros(dim, dtype=np.float64)
    for token in tokens:
        idx = hash(token) % dim
        vec[idx] += 1.0
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec /= norm
    return vec


def run_transfer_experiment(
    cache: CandidateCache,
    config: ExperimentConfig,
    n_trials: int | None = None,
    seed: int | None = None,
    use_text_features: bool = False,
) -> dict[str, list[TrialResult]]:
    """Leave-2-out cross-category transfer experiment from cache.

    For each pair of held-out categories:
      1. Train on all other categories
      2. Evaluate learned mu on the held-out pair (zero additional feedback)

    Returns dict with 'train' and 'test' trial results.
    """
    n = n_trials or config.n_trials
    seed_val = seed or config.seed
    seed_seq = np.random.SeedSequence(seed_val)
    factory = SimulatedUserFactory(seed=seed_val)

    categories = cache.get_categories()
    if len(categories) < 3:
        logger.warning(
            f"Transfer needs >=3 categories, got {len(categories)}. Skipping."
        )
        return {"train": [], "test": []}

    strategy = CasperStrategy(config.casper_config())
    train_results: list[TrialResult] = []
    test_results: list[TrialResult] = []

    for hold_i in range(len(categories)):
        for hold_j in range(hold_i + 1, len(categories)):
            test_cats = [categories[hold_i], categories[hold_j]]
            train_cats = [c for c in categories if c not in test_cats]

            train_cache = CandidateCache()
            for cat in train_cats:
                for s in cache.get_by_category(cat):
                    train_cache.add(
                        copy.deepcopy(s) if use_text_features else s
                    )

            test_cache = CandidateCache()
            for cat in test_cats:
                for s in cache.get_by_category(cat):
                    test_cache.add(
                        copy.deepcopy(s) if use_text_features else s
                    )

            if use_text_features:
                for scenario in train_cache.scenarios:
                    scenario.feature_vectors = [
                        _compute_text_features(cmd)
                        for cmd in scenario.repair_commands
                    ]
                for scenario in test_cache.scenarios:
                    scenario.feature_vectors = [
                        _compute_text_features(cmd)
                        for cmd in scenario.repair_commands
                    ]

            if not train_cache.get_learnable_scenarios():
                continue
            if not test_cache.get_learnable_scenarios():
                continue

            for profile in ALL_PROFILES:
                for trial_id in range(n):
                    rng = np.random.default_rng(seed_seq.spawn(1)[0])
                    user = factory.create(profile)

                    train_pairs = _generate_test_pairs_cached(
                        train_cache.get_learnable_scenarios(), user,
                        n_pairs=config.n_test_pairs, rng=rng,
                    )

                    tr = run_trial_cached(
                        user=user,
                        strategy=strategy,
                        cache=train_cache,
                        config=config,
                        test_pairs=train_pairs,
                        rng=rng,
                        trial_id=trial_id,
                        config_label=f"transfer_train_hold_{test_cats}",
                    )
                    train_results.append(tr)

                    test_scenarios = test_cache.get_learnable_scenarios()
                    test_pairs_transfer = _generate_test_pairs_cached(
                        test_scenarios, user,
                        n_pairs=config.n_test_pairs, rng=rng,
                    )
                    test_tracker = MetricsTracker(user, test_pairs_transfer)
                    test_tracker.compute_prior_baseline(tr.final_mu)

                    frozen_mu = tr.final_mu.copy()
                    frozen_sigma = tr.final_sigma.copy()

                    for t_test in range(config.T_max):
                        if not test_scenarios:
                            break
                        t_idx = rng.integers(0, len(test_scenarios))
                        t_scenario = test_scenarios[t_idx]
                        t_fvs = t_scenario.feature_vectors
                        t_sms = t_scenario.safety_margins
                        if len(t_fvs) < 2:
                            continue

                        sel = strategy.select(
                            t_fvs, t_sms, frozen_mu, frozen_sigma,
                        )
                        test_tracker.record_step(
                            t=t_test,
                            mu=frozen_mu,
                            sigma=frozen_sigma,
                            selected_features=t_fvs[sel],
                            candidate_features=t_fvs,
                        )

                    feat_label = "text" if use_text_features else "strategy"
                    test_results.append(TrialResult(
                        profile_name=user.name,
                        strategy_name=f"transfer_{feat_label}",
                        trial_id=trial_id,
                        tracker=test_tracker,
                        final_mu=frozen_mu,
                        final_sigma=frozen_sigma,
                        final_sigma_trace=float(np.trace(frozen_sigma)),
                        convergence_time=None,
                        autonomy_transition_time=None,
                        config_label=f"transfer_test_hold_{test_cats}"
                            f"{'_text' if use_text_features else ''}",
                    ))

    logger.info(
        f"Transfer experiment: {len(train_results)} train, "
        f"{len(test_results)} test trials"
    )
    return {"train": train_results, "test": test_results}
