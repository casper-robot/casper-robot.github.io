"""
Simulated User Model
=====================

Simulated users for evaluation experiments. 

Seven profiles spanning the preference space:
    Conservative Parent    - high safety margin weight
    Minimal Change         - high object & structural preservation
    Object-Attached        - dominant object preservation
    Pragmatic              - near-uniform low weights
    Safety First           - dominant safety dimension
    Structure Preserving   - high structural preservation
    Anti Prior             - adversarial, opposes the prior mean

Reference: Formulation §Evaluation Framework, Eq. 14 (sim_user)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from casper.feature_extraction import FEATURE_DIM

logger = logging.getLogger(__name__)


# User Profile Definitions

@dataclass(frozen=True)
class UserProfile:
    """
    Defines a simulated user's true preferences.

    Attributes:
        name:        Human-readable profile name.
        theta_true:  10-dimensional true preference weight vector.
                     Components correspond to:
                       [φ₁ modification_degree,
                        φ₂ object_preservation,
                        φ₃ parameter_modification,
                        φ₄ safety_margin,
                        φ₅ structural_preservation,
                        φ₆ interaction_change,
                        φ₇ plan_length,
                        φ₈ navigation_required,
                        φ₉ container_manipulation,
                        φ₁₀ handled_object_set_change]
        description: Brief description of the preference bias.
        default_beta: Default rationality parameter for this profile.
    """
    name: str
    theta_true: tuple  # Stored as tuple for immutability; converted to ndarray on use
    description: str
    default_beta: float = 0.3


# --- Profile definitions ---
# θ_true components: [φ₁_mod, φ₂_obj, φ₃_param, φ₄_safety, φ₅_struct,
#                     φ₆_interact, φ₇_plan_len, φ₈_nav, φ₉_container, φ₁₀_obj_change]
#
# Sign convention:
#   Positive weight = user prefers HIGHER values of that feature
#   Negative weight = user prefers LOWER values of that feature
#
# φ₁ (modification degree): higher = more modification. Negative weight
#     means the user prefers smaller modifications.
# φ₂ (object preservation): higher = object kept. Positive weight means
#     the user prefers keeping the original object.
# φ₃ (parameter modification): higher = parameters changed. Positive
#     weight means user likes parameter tweaks over substitution.
# φ₄ (safety margin): higher = more safety headroom. Positive weight
#     means user favors safer repairs.
# φ₅ (structural preservation): higher = task structure kept. Positive
#     weight means user prefers repairs that don't restructure the task.
# φ₆ (interaction change): higher = more interaction change. Negative
#     weight means user dislikes changes to how recipient interacts.
# φ₇ (plan length): higher = longer plan. Negative weight means
#     user prefers simpler plans with fewer steps.
# φ₈ (navigation required): 1 = plan needs navigation. Negative weight
#     means user dislikes plans that require the robot to move around.
# φ₉ (container manipulation): 1 = plan uses containers. Weight near
#     zero means user is neutral on this.
# φ₁₀ (handled object set change): higher = more different objects.
#     Negative weight means user prefers repairs using the same objects.

CONSERVATIVE_PARENT = UserProfile(
    name="Conservative Parent",
    theta_true=(-0.4, 0.6, 0.4, 1.2, 0.5, -0.3, -0.3, -0.2, 0.1, -0.2),
    description=(
        "High safety margin weight with moderate object preservation. "
        "Wants the safest possible repair while keeping familiar objects. "
        "Slight aversion to large modifications, interaction changes, "
        "and complex plans."
    ),
    default_beta=0.3,
)

MINIMAL_CHANGE = UserProfile(
    name="Minimal Change",
    theta_true=(-0.8, 1.2, 0.6, 0.3, 1.0, -0.5, -0.5, -0.3, -0.1, -0.4),
    description=(
        "Strongly prefers small modifications with high object and structural "
        "preservation. Wants the repair to change as little as possible. "
        "Dislikes longer plans and object set changes."
    ),
    default_beta=0.3,
)

OBJECT_ATTACHED = UserProfile(
    name="Object-Attached",
    theta_true=(-0.2, 1.8, 0.3, 0.2, 0.4, -0.1, -0.1, 0.0, 0.0, -0.3),
    description=(
        "Dominant weight on object preservation. Cares almost exclusively "
        "about keeping the same object. 'My kid likes grapes, give them "
        "grapes, just make it safe.' Dislikes object set changes."
    ),
    default_beta=0.3,
)

PRAGMATIC = UserProfile(
    name="Pragmatic",
    theta_true=(0.1, 0.2, 0.2, 0.3, 0.2, 0.0, 0.0, 0.0, 0.0, 0.0),
    description=(
        "Near-uniform low weights. Does not have strong opinions. "
        "Roughly accepts whatever the system suggests as long as it is safe. "
        "Neutral on plan-derived features."
    ),
    default_beta=0.3,
)

SAFETY_FIRST = UserProfile(
    name="Safety-First",
    theta_true=(-0.3, 0.2, 0.1, 2.0, 0.3, -0.2, -0.1, 0.0, 0.1, 0.0),
    description=(
        "Dominant weight on safety margin. Always wants the safest repair "
        "available regardless of other trade-offs. Slight preference for "
        "container-based containment strategies."
    ),
    default_beta=0.3,
)

STRUCTURE_PRESERVING = UserProfile(
    name="Structure-Preserving",
    theta_true=(-0.5, 0.3, 0.2, 0.3, 1.5, -0.4, -0.4, -0.2, 0.0, -0.2),
    description=(
        "Dominant weight on structural preservation. Prefers repairs that "
        "maintain the original task structure. Dislikes longer plans or "
        "plans that require navigation."
    ),
    default_beta=0.3,
)

ANTI_PRIOR = UserProfile(
    name="Anti-Prior",
    theta_true=(0.5, -0.3, -0.3, -0.2, -0.5, 0.8, 0.3, 0.2, 0.0, 0.2),
    description=(
        "Weights orthogonal to population prior. Tests cold-start recovery. "
        "Prefers large modifications, low object preservation, high "
        "interaction change, and accepts longer plans."
    ),
    default_beta=0.3,
)

ALL_PROFILES = [
    CONSERVATIVE_PARENT,
    MINIMAL_CHANGE,
    OBJECT_ATTACHED,
    PRAGMATIC,
    SAFETY_FIRST,
    STRUCTURE_PRESERVING,
    ANTI_PRIOR,
]

PROFILES_BY_NAME = {p.name: p for p in ALL_PROFILES}


# Simulated User

class SimulatedUser:
    """
    A simulated user that responds to preference queries using the
    noisy-rational Bradley-Terry model.

    Parameters
    ----------
    profile : UserProfile
        The user's preference profile (provides θ_true).
    beta_temp : float, optional
        Rationality parameter. Overrides profile default if provided.
        β→0: perfectly rational (always picks higher-utility option).
        β large: noisy, inconsistent choices.
    rng : np.random.Generator, optional
        Random number generator for reproducibility.
    """

    def __init__(
        self,
        profile: UserProfile,
        beta_temp: Optional[float] = None,
        rng: Optional[np.random.Generator] = None,
    ):
        self.profile = profile
        self.theta_true = np.array(profile.theta_true, dtype=np.float64)
        self.beta_temp = beta_temp if beta_temp is not None else profile.default_beta
        self.rng = rng if rng is not None else np.random.default_rng()

        if len(self.theta_true) != FEATURE_DIM:
            raise ValueError(
                f"theta_true must have {FEATURE_DIM} dimensions, "
                f"got {len(self.theta_true)}"
            )
        if self.beta_temp <= 0:
            raise ValueError(
                f"beta_temp must be positive, got {self.beta_temp}"
            )

    @property
    def name(self) -> str:
        return self.profile.name

    # Utility

    def true_utility(self, features: np.ndarray) -> float:
        features = np.asarray(features, dtype=np.float64)
        if features.shape != (FEATURE_DIM,):
            raise ValueError(
                f"features must have shape ({FEATURE_DIM},), got {features.shape}"
            )
        return float(self.theta_true @ features)

    def oracle_select(
        self,
        feature_vectors: list[np.ndarray],
    ) -> int:
        if not feature_vectors:
            raise ValueError("Cannot select from empty candidate list")
        utilities = [self.true_utility(f) for f in feature_vectors]
        return int(np.argmax(utilities))

    # Noisy-Rational Choice (Bradley-Terry)

    def _choice_probability(
        self,
        features_i: np.ndarray,
        features_j: np.ndarray,
    ) -> float:
        u_i = self.true_utility(features_i)
        u_j = self.true_utility(features_j)
        logit = (u_i - u_j) / self.beta_temp
        return _stable_sigmoid(logit)

    def choose_pairwise(
        self,
        features_i: np.ndarray,
        features_j: np.ndarray,
    ) -> int:
        p_i = self._choice_probability(features_i, features_j)
        return 0 if self.rng.random() < p_i else 1

    def choose_pairwise_deterministic(
        self,
        features_i: np.ndarray,
        features_j: np.ndarray,
    ) -> int:
        u_i = self.true_utility(features_i)
        u_j = self.true_utility(features_j)
        return 0 if u_i >= u_j else 1

    def accept_reject(
        self,
        features: np.ndarray,
        baseline_features: Optional[np.ndarray] = None,
    ) -> bool:
        if baseline_features is None:
            baseline_features = np.zeros(FEATURE_DIM, dtype=np.float64)
        choice = self.choose_pairwise(features, baseline_features)
        return choice == 0  # 0 means chose the candidate over baseline

    # Batch and multi-candidate selection

    def rank_candidates(
        self,
        feature_vectors: list[np.ndarray],
    ) -> list[int]:
        utilities = [self.true_utility(f) for f in feature_vectors]
        return sorted(range(len(utilities)), key=lambda i: utilities[i], reverse=True)

    # Serialization

    def to_dict(self) -> dict:
        """Serialize to dictionary for logging."""
        return {
            "profile_name": self.profile.name,
            "theta_true": self.theta_true.tolist(),
            "beta_temp": self.beta_temp,
            "description": self.profile.description,
        }

    def __repr__(self) -> str:
        return (
            f"SimulatedUser(profile='{self.profile.name}', "
            f"beta_temp={self.beta_temp:.3f})"
        )


# Factory

class SimulatedUserFactory:

    def __init__(self, seed: Optional[int] = None):
        self.seed = seed
        self._seed_seq = np.random.SeedSequence(seed)

    def create(
        self,
        profile: UserProfile,
        beta_temp: Optional[float] = None,
    ) -> SimulatedUser:
        """Create a single simulated user from a profile."""
        child_seed = self._seed_seq.spawn(1)[0]
        rng = np.random.default_rng(child_seed)
        return SimulatedUser(profile=profile, beta_temp=beta_temp, rng=rng)

    def create_all_profiles(
        self,
        beta_temp: Optional[float] = None,
    ) -> list[SimulatedUser]:
        """Create one user per profile."""
        return [self.create(p, beta_temp) for p in ALL_PROFILES]

    def create_noise_sweep(
        self,
        profile: UserProfile,
        beta_values: list[float],
    ) -> list[SimulatedUser]:
        """Create one user per noise level for a single profile."""
        return [self.create(profile, beta) for beta in beta_values]


# Utility functions

def _stable_sigmoid(x: float) -> float:
    """Numerically stable sigmoid function."""
    if x >= 0:
        z = np.exp(-x)
        return 1.0 / (1.0 + z)
    else:
        z = np.exp(x)
        return z / (1.0 + z)


def compute_pairwise_probability(
    theta: np.ndarray,
    features_i: np.ndarray,
    features_j: np.ndarray,
    beta_temp: float = 1.0,
) -> float:
    delta = np.asarray(features_i) - np.asarray(features_j)
    logit = float(np.asarray(theta) @ delta) / beta_temp
    return _stable_sigmoid(logit)
