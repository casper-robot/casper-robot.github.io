"""
CandidateCache — pre-computed candidate sets for zero-cost learning.

Built only from Gate-3-safe candidates. Learning experiments read from
cache at zero LLM cost.

Build once, learn forever.
"""

from __future__ import annotations

import json
import logging
import platform
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from evaluation.benchmark_results import TaskBenchmarkResult

logger = logging.getLogger(__name__)


@dataclass
class CachedScenario:
    """Pre-computed safe candidates for zero-cost learning experiments."""
    task_id: str
    command: str
    scene_context: str
    hazard_category: str
    ground_truth_safe: bool
    feature_vectors: list[np.ndarray]
    safety_margins: list[float]
    repair_commands: list[str]
    repair_strategies: list[str]
    total_generated: int
    rejected_lint: int
    rejected_screen: int
    rejected_safety: int
    rejected_safety_details: list[dict] = field(default_factory=list)
    pipeline_latency_ms: float = 0.0
    scene_inventory: list[str] = field(default_factory=list)

    @property
    def n_safe(self) -> int:
        return len(self.feature_vectors)

    @property
    def is_learnable(self) -> bool:
        return self.n_safe >= 2

    def validate(self) -> list[str]:
        """Check internal consistency. Returns list of error messages (empty = valid)."""
        errors: list[str] = []
        n = self.n_safe
        if len(self.safety_margins) != n:
            errors.append(
                f"len(safety_margins)={len(self.safety_margins)} != n_safe={n}"
            )
        if len(self.repair_commands) != n:
            errors.append(
                f"len(repair_commands)={len(self.repair_commands)} != n_safe={n}"
            )
        if self.feature_vectors:
            dims = {len(fv) for fv in self.feature_vectors}
            if len(dims) > 1:
                errors.append(f"inconsistent feature vector dimensions: {dims}")
        return errors

    def to_dict(self) -> dict:
        return {
            'task_id': self.task_id,
            'command': self.command,
            'scene_context': self.scene_context,
            'hazard_category': self.hazard_category,
            'ground_truth_safe': self.ground_truth_safe,
            'feature_vectors': [fv.tolist() for fv in self.feature_vectors],
            'safety_margins': self.safety_margins,
            'repair_commands': self.repair_commands,
            'repair_strategies': self.repair_strategies,
            'total_generated': self.total_generated,
            'rejected_lint': self.rejected_lint,
            'rejected_screen': self.rejected_screen,
            'rejected_safety': self.rejected_safety,
            'rejected_safety_details': self.rejected_safety_details,
            'pipeline_latency_ms': self.pipeline_latency_ms,
            'scene_inventory': self.scene_inventory,
        }

    @classmethod
    def from_dict(cls, d: dict) -> CachedScenario:
        from casper.feature_extraction import FEATURE_DIM
        raw_fvs = d.get('feature_vectors', [])
        padded_fvs = []
        for fv in raw_fvs:
            arr = np.array(fv, dtype=np.float64)
            if len(arr) < FEATURE_DIM:
                arr = np.concatenate([arr, np.zeros(FEATURE_DIM - len(arr))])
            padded_fvs.append(arr)

        return cls(
            task_id=d['task_id'],
            command=d['command'],
            scene_context=d.get('scene_context', ''),
            hazard_category=d.get('hazard_category', ''),
            ground_truth_safe=d.get('ground_truth_safe', False),
            feature_vectors=padded_fvs,
            safety_margins=d.get('safety_margins', []),
            repair_commands=d.get('repair_commands', []),
            repair_strategies=d.get('repair_strategies', []),
            total_generated=d.get('total_generated', 0),
            rejected_lint=d.get('rejected_lint', 0),
            rejected_screen=d.get('rejected_screen', 0),
            rejected_safety=d.get('rejected_safety', 0),
            rejected_safety_details=d.get('rejected_safety_details', []),
            pipeline_latency_ms=d.get('pipeline_latency_ms', 0.0),
            scene_inventory=d.get('scene_inventory', []),
        )


@dataclass
class CacheProvenance:
    """Provenance metadata for reproducibility."""
    model_name: str
    model_version: str
    prompt_template_hash: str
    safety_config: dict
    benchmark_source: str
    benchmark_version: str
    build_seed: int
    build_timestamp: str
    total_tasks_processed: int
    total_learnable: int
    python_version: str
    casper_version: str

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> CacheProvenance:
        return cls(**d)

    @classmethod
    def create(
        cls,
        model_name: str,
        model_version: str,
        prompt_template_hash: str,
        safety_config: dict,
        benchmark_source: str,
        benchmark_version: str,
        build_seed: int,
        total_tasks_processed: int,
        total_learnable: int,
    ) -> CacheProvenance:
        return cls(
            model_name=model_name,
            model_version=model_version,
            prompt_template_hash=prompt_template_hash,
            safety_config=safety_config,
            benchmark_source=benchmark_source,
            benchmark_version=benchmark_version,
            build_seed=build_seed,
            build_timestamp=datetime.now(timezone.utc).isoformat(),
            total_tasks_processed=total_tasks_processed,
            total_learnable=total_learnable,
            python_version=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            casper_version="0.2.0",
        )


class CandidateCache:
    """Pre-computed candidate sets. Build once, learn forever."""

    def __init__(self):
        self.scenarios: list[CachedScenario] = []
        self.provenance: CacheProvenance | None = None
        self._by_id: dict[str, CachedScenario] = {}
        self._by_category: dict[str, list[CachedScenario]] = {}

    def add(self, scenario: CachedScenario) -> None:
        self.scenarios.append(scenario)
        self._by_id[scenario.task_id] = scenario
        self._by_category.setdefault(
            scenario.hazard_category, []
        ).append(scenario)

    def get(self, task_id: str) -> CachedScenario | None:
        return self._by_id.get(task_id)

    def get_learnable_scenarios(self) -> list[CachedScenario]:
        return [s for s in self.scenarios if s.is_learnable]

    def get_by_category(self, category: str) -> list[CachedScenario]:
        return self._by_category.get(category, [])

    def get_categories(self) -> list[str]:
        return list(self._by_category.keys())

    @property
    def total(self) -> int:
        return len(self.scenarios)

    @property
    def total_learnable(self) -> int:
        return sum(1 for s in self.scenarios if s.is_learnable)

    def summary(self) -> str:
        categories = self.get_categories()
        lines = [
            f"CandidateCache: {self.total} scenarios "
            f"({self.total_learnable} learnable)",
            f"Categories: {len(categories)}",
        ]
        for cat in sorted(categories):
            scenarios = self.get_by_category(cat)
            learnable = sum(1 for s in scenarios if s.is_learnable)
            lines.append(f"  {cat}: {len(scenarios)} ({learnable} learnable)")
        return '\n'.join(lines)

    def save(self, path: str) -> None:
        data = {
            'version': '1.0',
            'provenance': self.provenance.to_dict() if self.provenance else None,
            'scenarios': [s.to_dict() for s in self.scenarios],
        }
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        logger.info(f"[cache] Saved {len(self.scenarios)} scenarios to {path}")

    @classmethod
    def load(cls, path: str, validate: bool = True) -> CandidateCache:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        cache = cls()
        if data.get('provenance'):
            cache.provenance = CacheProvenance.from_dict(data['provenance'])

        invalid_count = 0
        for s in data.get('scenarios', []):
            scenario = CachedScenario.from_dict(s)
            if validate:
                errors = scenario.validate()
                if errors:
                    invalid_count += 1
                    logger.warning(
                        f"[cache] Validation errors for {scenario.task_id}: "
                        f"{errors}"
                    )
            cache.add(scenario)

        if invalid_count:
            logger.warning(
                f"[cache] {invalid_count}/{cache.total} scenarios "
                f"had validation errors"
            )

        logger.info(
            f"[cache] Loaded {cache.total} scenarios "
            f"({cache.total_learnable} learnable) from {path}"
        )
        return cache

    @classmethod
    def from_benchmark_results(
        cls, results: list[TaskBenchmarkResult],
    ) -> CandidateCache:
        cache = cls()
        for r in results:
            if r.ground_truth_safe:
                continue
            cache.add(r.to_cache_entry())
        return cache
