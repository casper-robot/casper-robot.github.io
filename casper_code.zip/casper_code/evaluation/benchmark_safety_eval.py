"""
External Safety Evaluation — detection metrics on benchmark tasks.

Evaluates CASPER's safety pipeline against ground-truth labels from
SafeAgentBench. Computes TP/FN/FP/TN, precision, recall, F1, and
detection rate both globally and per hazard category.

"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class SafetyEvalResult:
    """Result of evaluating one task through the safety pipeline."""
    task_id: str
    ground_truth_safe: bool
    pipeline_safe: bool
    safety_margin: float
    flagged_dimensions: list[str]
    hazard_category: str
    latency_ms: float = 0.0


def run_safety_evaluation(
    tasks: list,
    safety_pipeline,
    scene_adapter=None,
) -> list[SafetyEvalResult]:

    results: list[SafetyEvalResult] = []

    for i, task in enumerate(tasks):
        if scene_adapter is not None:
            ctx = scene_adapter.adapt(task.scene_name)
            scene_context = ctx.prompt_context
        else:
            scene_context = getattr(task, "scene_context", "")

        start = time.perf_counter()
        sr = safety_pipeline.evaluate(task.instruction, scene_context)
        elapsed_ms = (time.perf_counter() - start) * 1000

        results.append(SafetyEvalResult(
            task_id=task.task_id,
            ground_truth_safe=not task.is_hazardous,
            pipeline_safe=sr.is_safe,
            safety_margin=sr.safety_margin,
            flagged_dimensions=[d.name for d in sr.flagged_dimensions],
            hazard_category=getattr(task, "risk_category", ""),
            latency_ms=elapsed_ms,
        ))

        if (i + 1) % 50 == 0:
            logger.info(f"Safety eval: {i + 1}/{len(tasks)} tasks processed")

    logger.info(f"Safety eval complete: {len(results)} tasks")
    return results


def compute_detection_metrics(results: list[SafetyEvalResult]) -> dict:

    tp = sum(1 for r in results if not r.ground_truth_safe and not r.pipeline_safe)
    fn = sum(1 for r in results if not r.ground_truth_safe and r.pipeline_safe)
    fp = sum(1 for r in results if r.ground_truth_safe and not r.pipeline_safe)
    tn = sum(1 for r in results if r.ground_truth_safe and r.pipeline_safe)

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = (
        2 * precision * recall / (precision + recall)
        if (precision + recall) > 0 else 0.0
    )

    return {
        "tp": tp,
        "fn": fn,
        "fp": fp,
        "tn": tn,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "detection_rate": recall,
        "false_positive_rate": fp / (fp + tn) if (fp + tn) > 0 else 0.0,
        "total": len(results),
    }


def compute_per_category_metrics(
    results: list[SafetyEvalResult],
) -> dict[str, dict]:

    by_cat: dict[str, list[SafetyEvalResult]] = {}
    for r in results:
        by_cat.setdefault(r.hazard_category, []).append(r)
    return {cat: compute_detection_metrics(rs) for cat, rs in by_cat.items()}
