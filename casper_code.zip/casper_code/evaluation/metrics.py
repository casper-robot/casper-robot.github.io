"""
Metrics Tracker
================

Records and computes all six evaluation metrics at each interaction step.

Metrics:
    M1: Prediction accuracy on held-out pairwise comparisons
    M2: Weight recovery error ‖μ_t − θ_true‖₂
    M3: Posterior contraction tr(Σ_t)
    M4: Cumulative regret vs oracle-optimal selection
    M5: Safety violation rate (must be exactly 0)
    M6: Safety coverage fraction (detection rate on known hazards)

"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from evaluation.simulated_user import SimulatedUser, compute_pairwise_probability
from casper.feature_extraction import FEATURE_DIM

logger = logging.getLogger(__name__)


# Held-out test pairs

@dataclass
class TestPair:
    """A held-out pairwise comparison for M1 evaluation."""
    features_i: np.ndarray
    features_j: np.ndarray
    true_preference: int  # 0 if i preferred, 1 if j preferred

    def __post_init__(self):
        self.features_i = np.asarray(self.features_i, dtype=np.float64)
        self.features_j = np.asarray(self.features_j, dtype=np.float64)


def generate_test_pairs(
    feature_vectors_list: list[list[np.ndarray]],
    user: SimulatedUser,
    n_pairs: int = 50,
    rng: Optional[np.random.Generator] = None,
) -> list[TestPair]:
    if rng is None:
        rng = np.random.default_rng()

    all_features = []
    for fv_list in feature_vectors_list:
        all_features.extend(fv_list)

    if len(all_features) < 2:
        raise ValueError(
            f"Need at least 2 feature vectors to generate pairs, "
            f"got {len(all_features)}"
        )

    pairs = []
    for _ in range(n_pairs):
        # Sample two distinct feature vectors
        idx = rng.choice(len(all_features), size=2, replace=False)
        fi = all_features[idx[0]]
        fj = all_features[idx[1]]
        # Deterministic ground truth
        true_pref = user.choose_pairwise_deterministic(fi, fj)
        pairs.append(TestPair(
            features_i=fi.copy(),
            features_j=fj.copy(),
            true_preference=true_pref,
        ))

    return pairs


# Step Record

@dataclass
class StepRecord:
    """Record of a single interaction step's metrics."""
    t: int
    mu: np.ndarray
    sigma_trace: float
    weight_recovery_error: float
    step_regret: float
    cumulative_regret: float
    prediction_accuracy: Optional[float]  # None if no test pairs
    safety_violation: bool  # True if an unsafe candidate was presented
    selection_mode: str  # "pairwise" or "autonomous"

    def to_dict(self) -> dict:
        return {
            "t": self.t,
            "mu": self.mu.tolist(),
            "sigma_trace": self.sigma_trace,
            "weight_recovery_error": self.weight_recovery_error,
            "step_regret": self.step_regret,
            "cumulative_regret": self.cumulative_regret,
            "prediction_accuracy": self.prediction_accuracy,
            "safety_violation": self.safety_violation,
            "selection_mode": self.selection_mode,
        }


# Metrics Tracker

class MetricsTracker:

    def __init__(
        self,
        user: SimulatedUser,
        test_pairs: Optional[list[TestPair]] = None,
    ):
        self.user = user
        self.theta_true = user.theta_true.copy()
        self.test_pairs = test_pairs or []
        self.steps: list[StepRecord] = []
        self._cumulative_regret = 0.0
        self._prior_baseline_accuracy: float | None = None

    # M1: Prediction Accuracy

    def prediction_accuracy(self, mu: np.ndarray) -> Optional[float]:
        if not self.test_pairs:
            return None

        correct = 0
        for pair in self.test_pairs:
            # Model predicts i if P(i ≻ j | μ) > 0.5
            p_i = compute_pairwise_probability(
                mu, pair.features_i, pair.features_j, beta_temp=1.0
            )
            predicted = 0 if p_i > 0.5 else 1
            if predicted == pair.true_preference:
                correct += 1

        return correct / len(self.test_pairs)

    # M2: Weight Recovery Error

    def weight_recovery_error(self, mu: np.ndarray) -> float:
        """
        M2: ‖μ_t − θ_true‖₂

        Euclidean distance between posterior mean and true weights.
        """
        return float(np.linalg.norm(mu - self.theta_true))

    # M3: Posterior Contraction

    @staticmethod
    def posterior_contraction(sigma: np.ndarray) -> float:
        """
        M3: tr(Σ_t)

        Trace of the posterior covariance. Decreases as the model
        becomes more certain about user preferences.
        """
        return float(np.trace(sigma))

    # M4: Regret

    def step_regret(
        self,
        selected_features: np.ndarray,
        candidate_features: list[np.ndarray],
    ) -> float:

        oracle_idx = self.user.oracle_select(candidate_features)
        oracle_utility = self.user.true_utility(candidate_features[oracle_idx])
        selected_utility = self.user.true_utility(selected_features)
        return max(0.0, oracle_utility - selected_utility)

    @property
    def cumulative_regret(self) -> float:
        """M4: Cumulative regret across all steps."""
        return self._cumulative_regret

    # Normalized Convergence

    def compute_prior_baseline(self, mu_0: np.ndarray) -> float:
        """Prediction accuracy at the prior mean (t=0 baseline)."""
        acc = self.prediction_accuracy(mu_0)
        self._prior_baseline_accuracy = acc
        return acc

    def normalized_improvement(self, current_accuracy: float) -> float:
        """(accuracy - prior) / (1.0 - prior), clamped to [0, 1]."""
        prior = self._prior_baseline_accuracy or 0.0
        gap = 1.0 - prior
        if gap < 1e-6:
            return 1.0
        return max(0.0, min(1.0, (current_accuracy - prior) / gap))

    # M5: Safety Violation Rate

    @property
    def safety_violation_count(self) -> int:
        """M5: Total number of safety violations. Must be 0."""
        return sum(1 for s in self.steps if s.safety_violation)

    @property
    def safety_violation_rate(self) -> float:
        """M5: Fraction of steps with safety violations."""
        if not self.steps:
            return 0.0
        return self.safety_violation_count / len(self.steps)

    # Recording

    def record_step(
        self,
        t: int,
        mu: np.ndarray,
        sigma: np.ndarray,
        selected_features: np.ndarray,
        candidate_features: list[np.ndarray],
        safety_violation: bool = False,
        selection_mode: str = "pairwise",
    ) -> StepRecord:

        mu = np.asarray(mu, dtype=np.float64)
        sigma = np.asarray(sigma, dtype=np.float64)
        selected_features = np.asarray(selected_features, dtype=np.float64)

        # Compute metrics
        m1 = self.prediction_accuracy(mu)
        m2 = self.weight_recovery_error(mu)
        m3 = self.posterior_contraction(sigma)
        regret = self.step_regret(selected_features, candidate_features)
        self._cumulative_regret += regret

        record = StepRecord(
            t=t,
            mu=mu.copy(),
            sigma_trace=m3,
            weight_recovery_error=m2,
            step_regret=regret,
            cumulative_regret=self._cumulative_regret,
            prediction_accuracy=m1,
            safety_violation=safety_violation,
            selection_mode=selection_mode,
        )
        self.steps.append(record)
        return record

    # Aggregation

    def get_metric_trajectory(self, metric_name: str) -> list:
        return [getattr(s, metric_name) for s in self.steps]

    def convergence_time(
        self,
        threshold: float = 0.9,
        metric: str = "prediction_accuracy",
    ) -> Optional[int]:
        values = self.get_metric_trajectory(metric)
        if not values:
            return None

        for t in range(len(values)):
            if values[t] is None:
                continue
            # Check if all values from t onward exceed threshold
            remaining = values[t:]
            if all(v is not None and v >= threshold for v in remaining):
                return self.steps[t].t
        return None

    def autonomy_transition_time(self) -> Optional[int]:
        """
        Find the first step where selection mode switches to autonomous.

        Returns
        -------
        int or None
            The transition time step, or None if always pairwise.
        """
        for step in self.steps:
            if step.selection_mode == "autonomous":
                return step.t
        return None

    def summary(self) -> dict:
        """
        Compute summary statistics across all recorded steps.

        Returns
        -------
        dict
            Summary with final values and aggregates.
        """
        if not self.steps:
            return {"n_steps": 0}

        final = self.steps[-1]
        return {
            "n_steps": len(self.steps),
            "final_mu": final.mu.tolist(),
            "final_sigma_trace": final.sigma_trace,
            "final_weight_recovery_error": final.weight_recovery_error,
            "final_prediction_accuracy": final.prediction_accuracy,
            "cumulative_regret": self._cumulative_regret,
            "safety_violation_count": self.safety_violation_count,
            "safety_violation_rate": self.safety_violation_rate,
            "convergence_time_90": self.convergence_time(0.9),
            "autonomy_transition_time": self.autonomy_transition_time(),
            "prior_baseline_accuracy": self._prior_baseline_accuracy,
        }

    def to_dict_list(self) -> list[dict]:
        """Export all step records as list of dicts."""
        return [s.to_dict() for s in self.steps]
