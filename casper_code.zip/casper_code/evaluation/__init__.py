"""
CASPER Evaluation Framework
============================

Simulated experiments and analysis tools for validating the CASPER
preference learning and safety pipeline.

Experiments (current design):
    A  Safety Detection      - SafeAgentBench confusion matrix (benchmark_runner)
    B  Preference Learning   - 7 profiles x 5 strategies, T=30, 20 trials (run_trial_cached)
    C  Cross-Hazard Transfer - Leave-2-out, strategy vs text features (run_transfer_experiment)

Modules:
    simulated_user   - Bradley-Terry simulated users with 7 profiles
    metrics          - M1-M6 metric tracking and computation
    baselines        - Selection strategies (CASPER + 4 baselines)
    experiments      - Core trial loop, cached experiments (B, C)
    candidate_cache  - Pre-computed candidate sets for zero-cost learning
    benchmark_runner - SafeAgentBench pipeline runner (Experiment A)
    analysis         - Results aggregation, plotting, reporting

"""
