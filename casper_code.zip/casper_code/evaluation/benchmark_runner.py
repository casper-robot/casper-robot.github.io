"""
BenchmarkRunner — runs the full CASPER pipeline on benchmark tasks.

Resume/rerun support, per-task trace recording, 
and incremental JSONL checkpointing.

"""

from __future__ import annotations

import json
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Callable

import numpy as np

from evaluation.benchmark_results import TaskBenchmarkResult
from evaluation.candidate_cache import CandidateCache, CacheProvenance
from evaluation.safeagentbench_loader import SafeAgentBenchTask
from evaluation.scene_adapters import BenchmarkSceneAdapter, CasperSceneContext
from evaluation.trace_recorder import NullRecorder, TraceRecorder

if TYPE_CHECKING:
    from casper.casper_pipeline import CasperPipeline

logger = logging.getLogger(__name__)


@dataclass
class RunConfig:
    output_dir: str
    splits: list[str] = field(
        default_factory=lambda: ['unsafe_detailed', 'safe_detailed']
    )
    num_tasks: int = 0
    trace_enabled: bool = True
    resume: bool = True
    rerun_failures: bool = False
    reference_compare: bool = False
    max_workers: int = 1


@dataclass
class AdaptationQualityReport:
    """Diagnostic emitted by every benchmark run, not a separate gate."""
    n_sampled: int
    avg_entity_count: float
    avg_relation_count: float
    frac_with_hazard_relations: float
    frac_command_objects_in_scene: float
    frac_scene_type_correct: float

    @property
    def has_hard_failure(self) -> bool:
        return self.avg_entity_count < 1.0

    @property
    def passed(self) -> bool:
        return (
            self.avg_entity_count >= 5.0
            and self.avg_relation_count >= 2.0
            and self.frac_with_hazard_relations >= 0.60
            and self.frac_command_objects_in_scene >= 0.70
            and self.frac_scene_type_correct >= 0.90
        )

    def summary(self) -> str:
        status = "PASSED" if self.passed else "FAILED"
        return (
            f"Adaptation Quality ({status})\n"
            f"  Entities: {self.avg_entity_count:.1f} (>=5)\n"
            f"  Relations: {self.avg_relation_count:.1f} (>=2)\n"
            f"  Hazard relations: {self.frac_with_hazard_relations:.0%} (>=60%)\n"
            f"  Command coverage: {self.frac_command_objects_in_scene:.0%} (>=70%)\n"
            f"  Scene type: {self.frac_scene_type_correct:.0%} (>=90%)"
        )


@dataclass
class BenchmarkRunOutput:
    results: list[TaskBenchmarkResult]
    adaptation_report: AdaptationQualityReport | None
    failed_task_ids: list[str]
    config: RunConfig


class BenchmarkRunner:
    """Runs the full CASPER pipeline on benchmark tasks.

    The benchmark runner always emits AdaptationQualityReport as a
    diagnostic in the run manifest. Small runs and full runs use
    identical logic. Only task count changes.
    """

    def __init__(
        self,
        pipeline: CasperPipeline,
        scene_adapter: BenchmarkSceneAdapter,
        config: RunConfig,
        pipeline_factory: Callable[[], CasperPipeline] | None = None,
    ):
        self.pipeline = pipeline
        self.adapter = scene_adapter
        self.config = config
        self._pipeline_factory = pipeline_factory
        self.output_dir = Path(config.output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._results_file = self.output_dir / 'results.jsonl'
        self._checkpoint_lock = threading.Lock()

    def _load_completed_ids(self) -> set[str]:
        completed: set[str] = set()
        corrupt_lines = 0
        if self._results_file.exists():
            with open(self._results_file, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        corrupt_lines += 1
                        logger.warning(
                            f"Corrupt checkpoint line {line_num} in "
                            f"{self._results_file}"
                        )
                        continue

                    if 'task_id' not in entry:
                        corrupt_lines += 1
                        logger.warning(
                            f"Missing task_id at line {line_num} in "
                            f"{self._results_file}"
                        )
                        continue

                    if entry.get('status') == 'completed':
                        completed.add(entry['task_id'])
                    elif (entry.get('status') == 'failed'
                          and not self.config.rerun_failures):
                        completed.add(entry['task_id'])

            if corrupt_lines:
                logger.warning(
                    f"{corrupt_lines} corrupt lines in checkpoint file"
                )
        return completed

    def _append_checkpoint(
        self,
        task_id: str,
        status: str,
        summary: dict | None = None,
        error: str = "",
    ) -> None:
        entry = {
            'task_id': task_id,
            'status': status,
            'error': error,
            **(summary or {}),
        }
        with self._checkpoint_lock:
            with open(self._results_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(entry) + '\n')

    def run(self, tasks: list[SafeAgentBenchTask]) -> BenchmarkRunOutput:
        completed_ids: set[str] = set()
        if self.config.resume:
            completed_ids = self._load_completed_ids()
            if completed_ids:
                logger.info(
                    f"Resuming: {len(completed_ids)} done, "
                    f"{len(tasks) - len(completed_ids)} remaining"
                )

        pending = [t for t in tasks if t.task_id not in completed_ids]

        if self.config.max_workers > 1 and self._pipeline_factory:
            results, failed_ids = self._run_parallel(pending, len(tasks))
        else:
            results, failed_ids = self._run_sequential(pending, len(tasks))

        adaptation_samples = []
        for task in tasks[:40]:
            ctx = self.adapter.adapt(task.scene_name)
            adaptation_samples.append((task, ctx))

        adaptation_report = None
        if adaptation_samples:
            adaptation_report = self._compute_adaptation_report(
                adaptation_samples
            )
            logger.info(adaptation_report.summary())
            (self.output_dir / 'adaptation_report.json').write_text(
                json.dumps(asdict(adaptation_report), indent=2),
                encoding='utf-8',
            )

        ref_compare_file = self.output_dir / 'reference_compare.jsonl'
        if self.config.reference_compare and ref_compare_file.exists():
            self._write_reference_summary(ref_compare_file)

        if results:
            llm = getattr(self.pipeline, 'llm', None)
            self.build_cache(
                results,
                model_name=getattr(llm, 'model_name', '') if llm else '',
            )

        return BenchmarkRunOutput(
            results=results,
            adaptation_report=adaptation_report,
            failed_task_ids=failed_ids,
            config=self.config,
        )

    def _run_sequential(
        self,
        pending: list[SafeAgentBenchTask],
        total: int,
    ) -> tuple[list[TaskBenchmarkResult], list[str]]:
        results: list[TaskBenchmarkResult] = []
        failed_ids: list[str] = []
        ref_compare_file = self.output_dir / 'reference_compare.jsonl'

        for i, task in enumerate(pending):
            logger.info(f"[{i+1}/{total}] {task.task_id} ({task.split})")

            recorder: TraceRecorder | NullRecorder = NullRecorder()
            if self.config.trace_enabled:
                recorder = TraceRecorder(
                    str(self.output_dir / 'traces'), task.task_id
                )

            try:
                result, pr = self._process_task(task, recorder)
                self._append_checkpoint(task.task_id, 'completed', {
                    'split': result.split,
                    'hazard_category': result.hazard_category,
                    'ground_truth_safe': result.ground_truth_safe,
                    'detected_unsafe': result.pipeline_detected_unsafe,
                    'safe_candidates': result.safe_candidates,
                    'latency_ms': sum(result.latency_by_stage.values()),
                })
                results.append(result)

                if self.config.reference_compare:
                    scene_ctx = self.adapter.adapt(task.scene_name)
                    comparison = self._run_reference_compare(
                        task, pr, scene_ctx.prompt_context,
                    )
                    with self._checkpoint_lock:
                        with open(ref_compare_file, 'a', encoding='utf-8') as f:
                            f.write(json.dumps(comparison) + '\n')

            except Exception as e:
                logger.error(f"Task {task.task_id} failed: {e}")
                self._append_checkpoint(task.task_id, 'failed', error=str(e))
                failed_ids.append(task.task_id)

        return results, failed_ids

    def _run_parallel(
        self,
        pending: list[SafeAgentBenchTask],
        total: int,
    ) -> tuple[list[TaskBenchmarkResult], list[str]]:
        results: list[TaskBenchmarkResult] = []
        failed_ids: list[str] = []
        completed_count = 0

        logger.info(
            f"Parallel mode: {self.config.max_workers} workers, "
            f"{len(pending)} tasks"
        )

        def _worker(task: SafeAgentBenchTask) -> tuple[str, TaskBenchmarkResult | None, str]:
            pipeline = self._pipeline_factory()

            recorder: TraceRecorder | NullRecorder = NullRecorder()
            if self.config.trace_enabled:
                recorder = TraceRecorder(
                    str(self.output_dir / 'traces'), task.task_id
                )

            try:
                scene_ctx = self.adapter.adapt(task.scene_name)
                recorder.save("input", {
                    "task_id": task.task_id,
                    "command": task.instruction,
                    "scene_name": task.scene_name,
                    "is_hazardous": task.is_hazardous,
                })
                pipeline.recorder = recorder

                start = time.perf_counter()
                pr = pipeline.process_command(
                    task.instruction, scene_ctx.prompt_context, scene_ctx
                )
                total_ms = (time.perf_counter() - start) * 1000

                safe_candidates = getattr(pr, 'safe_candidates', [])
                result = TaskBenchmarkResult(
                    task_id=task.task_id,
                    split=task.split,
                    hazard_category=task.risk_category,
                    scene_name=task.scene_name,
                    command=task.instruction,
                    scene_context=scene_ctx.prompt_context,
                    ground_truth_safe=not task.is_hazardous,
                    pipeline_detected_unsafe=not pr.safety_result.is_safe,
                    flagged_dimensions=[
                        d.name for d in pr.safety_result.flagged_dimensions
                    ],
                    safety_margin=pr.safety_result.safety_margin,
                    total_candidates_generated=len(
                        getattr(pr, 'all_generated', [])
                    ),
                    rejected_lint=len(getattr(pr, 'rejected_lint', [])),
                    rejected_lint_details=[
                        {"command": rc.command, "errors": errs}
                        for rc, errs in getattr(pr, 'rejected_lint', [])
                    ],
                    rejected_screen=len(getattr(pr, 'rejected_screen', [])),
                    rejected_screen_details=[
                        {"command": rc.command,
                         "resolved": sr.resolved,
                         "reasoning": sr.resolution_reasoning}
                        for rc, sr in getattr(pr, 'rejected_screen', [])
                    ],
                    rejected_safety=len(getattr(pr, 'rejected_safety', [])),
                    rejected_safety_details=[
                        {"command": rc.command,
                         "flagged": [d.name for d in dims]}
                        for rc, dims in getattr(pr, 'rejected_safety', [])
                    ],
                    safe_candidates=len(safe_candidates),
                    repair_commands=[c.command for c in safe_candidates],
                    repair_strategies=[c.strategy for c in safe_candidates],
                    repair_action_plans=[
                        [{"verb": a.verb, "obj": a.obj, "receptacle": a.receptacle}
                         for a in getattr(c, 'action_plan', [])]
                        for c in safe_candidates
                    ],
                    feature_vectors=[
                        c.features.values.tolist() for c in safe_candidates
                    ],
                    safety_margins=[
                        c.safety_result.safety_margin
                        for c in safe_candidates
                        if c.safety_result
                    ],
                    has_intent_preserving_candidate=getattr(
                        pr, 'has_intent_preserving_candidate', False,
                    ),
                    intent_preserving_count=sum(
                        1 for c in safe_candidates
                        if getattr(c, 'intent_preserving', False)
                    ),
                    repair_postures=[
                        getattr(c, 'repair_posture', '')
                        for c in safe_candidates
                    ],
                    scene_inventory=scene_ctx.entities,
                    latency_by_stage=getattr(
                        pr, 'latency', {'total_ms': total_ms}
                    ),
                )

                validation_errors = result.validate()
                if validation_errors:
                    logger.warning(
                        f"Result validation errors for {task.task_id}: "
                        f"{validation_errors}"
                    )

                recorder.save("result_summary", {
                    "detected_unsafe": result.pipeline_detected_unsafe,
                    "safe_candidates": result.safe_candidates,
                    "total_generated": result.total_candidates_generated,
                    "rejected_lint": result.rejected_lint,
                    "rejected_screen": result.rejected_screen,
                    "rejected_safety": result.rejected_safety,
                    "validation_errors": validation_errors,
                })

                if getattr(pr, 'original_frame', None) is not None:
                    recorder.save("objective_frame", pr.original_frame)
                recorder.save_manifest()

                return task.task_id, result, ""
            except Exception as e:
                return task.task_id, None, str(e)

        with ThreadPoolExecutor(max_workers=self.config.max_workers) as pool:
            futures = {
                pool.submit(_worker, task): task for task in pending
            }
            for future in as_completed(futures):
                task_id, result, error = future.result()
                completed_count += 1

                if result is not None:
                    self._append_checkpoint(task_id, 'completed', {
                        'split': result.split,
                        'hazard_category': result.hazard_category,
                        'ground_truth_safe': result.ground_truth_safe,
                        'detected_unsafe': result.pipeline_detected_unsafe,
                        'safe_candidates': result.safe_candidates,
                        'latency_ms': sum(result.latency_by_stage.values()),
                    })
                    results.append(result)
                    logger.info(
                        f"[{completed_count}/{len(pending)}] "
                        f"{task_id}: "
                        f"{'unsafe' if result.pipeline_detected_unsafe else 'safe'}, "
                        f"{result.safe_candidates} repairs"
                    )
                else:
                    logger.error(
                        f"[{completed_count}/{len(pending)}] "
                        f"{task_id} failed: {error}"
                    )
                    self._append_checkpoint(task_id, 'failed', error=error)
                    failed_ids.append(task_id)

        return results, failed_ids

    def _process_task(
        self,
        task: SafeAgentBenchTask,
        recorder: TraceRecorder | NullRecorder,
    ) -> tuple[TaskBenchmarkResult, object]:
        scene_ctx = self.adapter.adapt(task.scene_name)
        recorder.save("input", {
            "task_id": task.task_id,
            "command": task.instruction,
            "scene_name": task.scene_name,
            "is_hazardous": task.is_hazardous,
        })

        self.pipeline.recorder = recorder

        start = time.perf_counter()
        pr = self.pipeline.process_command(
            task.instruction, scene_ctx.prompt_context, scene_ctx
        )
        total_ms = (time.perf_counter() - start) * 1000

        safe_candidates = getattr(pr, 'safe_candidates', [])

        result = TaskBenchmarkResult(
            task_id=task.task_id,
            split=task.split,
            hazard_category=task.risk_category,
            scene_name=task.scene_name,
            command=task.instruction,
            scene_context=scene_ctx.prompt_context,
            ground_truth_safe=not task.is_hazardous,
            pipeline_detected_unsafe=not pr.safety_result.is_safe,
            flagged_dimensions=[
                d.name for d in pr.safety_result.flagged_dimensions
            ],
            safety_margin=pr.safety_result.safety_margin,
            total_candidates_generated=len(
                getattr(pr, 'all_generated', [])
            ),
            rejected_lint=len(getattr(pr, 'rejected_lint', [])),
            rejected_lint_details=[
                {"command": rc.command, "errors": errs}
                for rc, errs in getattr(pr, 'rejected_lint', [])
            ],
            rejected_screen=len(getattr(pr, 'rejected_screen', [])),
            rejected_screen_details=[
                {"command": rc.command,
                 "resolved": sr.resolved,
                 "reasoning": sr.resolution_reasoning}
                for rc, sr in getattr(pr, 'rejected_screen', [])
            ],
            rejected_safety=len(getattr(pr, 'rejected_safety', [])),
            rejected_safety_details=[
                {"command": rc.command,
                 "flagged": [d.name for d in dims]}
                for rc, dims in getattr(pr, 'rejected_safety', [])
            ],
            safe_candidates=len(safe_candidates),
            repair_commands=[c.command for c in safe_candidates],
            repair_strategies=[c.strategy for c in safe_candidates],
            repair_action_plans=[
                [{"verb": a.verb, "obj": a.obj, "receptacle": a.receptacle}
                 for a in getattr(c, 'action_plan', [])]
                for c in safe_candidates
            ],
            feature_vectors=[
                c.features.values.tolist() for c in safe_candidates
            ],
            safety_margins=[
                c.safety_result.safety_margin
                for c in safe_candidates
                if c.safety_result
            ],
            has_intent_preserving_candidate=getattr(
                pr, 'has_intent_preserving_candidate', False,
            ),
            intent_preserving_count=sum(
                1 for c in safe_candidates
                if getattr(c, 'intent_preserving', False)
            ),
            repair_postures=[
                getattr(c, 'repair_posture', '')
                for c in safe_candidates
            ],
            scene_inventory=scene_ctx.entities,
            latency_by_stage=getattr(pr, 'latency', {'total_ms': total_ms}),
        )

        validation_errors = result.validate()
        if validation_errors:
            logger.warning(
                f"Result validation errors for {task.task_id}: "
                f"{validation_errors}"
            )

        recorder.save("result_summary", {
            "detected_unsafe": result.pipeline_detected_unsafe,
            "safe_candidates": result.safe_candidates,
            "total_generated": result.total_candidates_generated,
            "rejected_lint": result.rejected_lint,
            "rejected_screen": result.rejected_screen,
            "rejected_safety": result.rejected_safety,
            "has_intent_preserving_candidate": result.has_intent_preserving_candidate,
            "intent_preserving_count": result.intent_preserving_count,
            "repair_postures": result.repair_postures,
            "validation_errors": validation_errors,
        })

        if getattr(pr, 'original_frame', None) is not None:
            recorder.save("objective_frame", pr.original_frame)
        recorder.save_manifest()

        return result, pr

    def _compute_adaptation_report(
        self,
        samples: list[tuple[SafeAgentBenchTask, CasperSceneContext]],
    ) -> AdaptationQualityReport:
        hazard_types = {
            'Knife', 'ButterKnife', 'StoveBurner', 'Microwave',
            'Toaster', 'Fridge', 'GarbageCan', 'SprayBottle',
            'SoapBottle', 'Candle',
        }
        entity_counts = []
        relation_counts = []
        hazard_rels = []
        cmd_coverage = []
        type_correct = []

        for task, ctx in samples:
            entity_counts.append(len(ctx.entities))
            relation_counts.append(len(ctx.relations))
            hazard_rels.append(any(
                r['source'] in hazard_types or r['target'] in hazard_types
                for r in ctx.relations
            ))
            cmd_words = set(task.instruction.lower().split())
            entity_lower = {e.lower() for e in ctx.entities}
            found = sum(
                1 for e in entity_lower
                if any(e in w or w in e for w in cmd_words)
            )
            cmd_coverage.append(min(found / max(len(entity_lower), 1), 1.0))
            type_correct.append(ctx.room_type != 'home')

        return AdaptationQualityReport(
            n_sampled=len(samples),
            avg_entity_count=float(np.mean(entity_counts)),
            avg_relation_count=float(np.mean(relation_counts)),
            frac_with_hazard_relations=float(np.mean(hazard_rels)),
            frac_command_objects_in_scene=float(np.mean(cmd_coverage)),
            frac_scene_type_correct=float(np.mean(type_correct)),
        )

    # Cache Builder: convert results to CandidateCache with provenance

    def build_cache(
        self,
        results: list[TaskBenchmarkResult],
        model_name: str = "",
        model_version: str = "",
    ) -> CandidateCache:
        """Build a CandidateCache from benchmark results with provenance.

        Saves to output_dir/candidate_cache.json.
        """
        import hashlib

        cache = CandidateCache.from_benchmark_results(results)

        prompt_hash = hashlib.sha256(
            (model_name + model_version).encode()
        ).hexdigest()[:12]

        cache.provenance = CacheProvenance.create(
            model_name=model_name,
            model_version=model_version,
            prompt_template_hash=prompt_hash,
            safety_config={},
            benchmark_source="SafeAgentBench",
            benchmark_version="1.0",
            build_seed=42,
            total_tasks_processed=len(results),
            total_learnable=cache.total_learnable,
        )

        cache_path = str(self.output_dir / "candidate_cache.json")
        cache.save(cache_path)
        logger.info(
            f"Built cache: {cache.total} scenarios, "
            f"{cache.total_learnable} learnable"
        )
        return cache

    # Reference Compare: full-pipeline vs waterfall diagnostic

    def _run_reference_compare(
        self,
        task: SafeAgentBenchTask,
        pipeline_result,
        scene_context: str,
    ) -> dict:
        """Run all candidates through full eval (no lint/screen) and compare
        against the waterfall result.

        Returns a comparison dict written to reference_compare.jsonl.
        """
        all_candidates = getattr(pipeline_result, 'all_generated', [])
        if not all_candidates or pipeline_result.safety_result.is_safe:
            return {
                "task_id": task.task_id,
                "skipped": True,
                "reason": "safe_or_no_candidates",
            }

        diagnosis = self.pipeline.safety.extract_diagnosis(
            pipeline_result.safety_result,
        )
        original_graph = pipeline_result.safety_result.interaction_graph

        # Reference path: full eval on every candidate
        ref_safe_cmds: list[str] = []
        ref_unsafe_cmds: list[str] = []
        for candidate in all_candidates:
            try:
                ref_result = self.pipeline.safety.evaluate_repair(
                    candidate=candidate,
                    diagnosis=diagnosis,
                    scene_context=scene_context,
                    original_graph=original_graph,
                )
                if ref_result.is_safe:
                    ref_safe_cmds.append(candidate.command)
                else:
                    ref_unsafe_cmds.append(candidate.command)
            except Exception as e:
                logger.warning(
                    f"reference_compare eval failed for "
                    f"{candidate.command}: {e}"
                )
                ref_unsafe_cmds.append(candidate.command)

        # Waterfall path safe set
        safe_candidates = getattr(pipeline_result, 'safe_candidates', [])
        waterfall_safe = {c.command for c in safe_candidates}
        ref_safe = set(ref_safe_cmds)

        # Compute comparison metrics
        agreed_safe = waterfall_safe & ref_safe
        false_reject = ref_safe - waterfall_safe
        false_accept = waterfall_safe - ref_safe

        comparison = {
            "task_id": task.task_id,
            "skipped": False,
            "total_candidates": len(all_candidates),
            "waterfall_safe_count": len(waterfall_safe),
            "reference_safe_count": len(ref_safe),
            "agreed_safe": len(agreed_safe),
            "false_reject": len(false_reject),
            "false_reject_cmds": sorted(false_reject),
            "false_accept": len(false_accept),
            "false_accept_cmds": sorted(false_accept),
            "cardinality_diff": len(ref_safe) - len(waterfall_safe),
            "agreement_rate": (
                len(agreed_safe) / max(len(ref_safe | waterfall_safe), 1)
            ),
        }
        return comparison

    def _write_reference_summary(self, ref_file: Path) -> None:
        """Aggregate reference_compare.jsonl into a summary JSON."""
        comparisons = []
        with open(ref_file, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    comparisons.append(json.loads(line.strip()))
                except json.JSONDecodeError:
                    continue

        evaluated = [c for c in comparisons if not c.get('skipped', True)]
        if not evaluated:
            return

        total_false_reject = sum(c['false_reject'] for c in evaluated)
        total_false_accept = sum(c['false_accept'] for c in evaluated)
        total_candidates = sum(c['total_candidates'] for c in evaluated)
        avg_agreement = float(np.mean(
            [c['agreement_rate'] for c in evaluated]
        ))

        summary = {
            "tasks_evaluated": len(evaluated),
            "tasks_skipped": len(comparisons) - len(evaluated),
            "total_candidates": total_candidates,
            "total_false_reject": total_false_reject,
            "total_false_accept": total_false_accept,
            "avg_agreement_rate": avg_agreement,
            "waterfall_safe_total": sum(
                c['waterfall_safe_count'] for c in evaluated
            ),
            "reference_safe_total": sum(
                c['reference_safe_count'] for c in evaluated
            ),
        }
        summary_file = ref_file.parent / 'reference_compare_summary.json'
        summary_file.write_text(
            json.dumps(summary, indent=2), encoding='utf-8',
        )
        logger.info(
            f"Reference compare: {len(evaluated)} tasks, "
            f"agreement={avg_agreement:.1%}, "
            f"false_reject={total_false_reject}, "
            f"false_accept={total_false_accept}"
        )
