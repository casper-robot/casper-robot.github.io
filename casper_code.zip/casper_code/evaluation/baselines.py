"""
Baseline Selection Strategies
==============================

Five strategies for Experiment B (Preference Learning):

    B0 CASPER:            Three-term scoring (utility + exploration + safety margin)
    B2 Random Bandit:     Uniform random selection from safe candidates
    B3 Greedy Bandit:     (exploitation only, no exploration)
    B4 Thompson Sampling: 
    B5 Safety Max-Margin: Always selects highest safety margin (no learning)

Plus ablation configurations for CASPER.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from casper.feature_extraction import FEATURE_DIM

logger = logging.getLogger(__name__)


# Abstract Base

class SelectionStrategy(ABC):

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable strategy name."""
        ...

    @abstractmethod
    def select(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> int:
        """
        Select a single candidate.

        Parameters
        ----------
        feature_vectors : list of np.ndarray
            Feature vectors for safe candidates.
        safety_margins : list of float
            Safety margins for safe candidates.
        mu : np.ndarray
            Current posterior mean.
        sigma : np.ndarray
            Current posterior covariance.

        Returns
        -------
        int
            Index of the selected candidate.
        """
        ...

    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> tuple[int, int]:
        """
        Select a pair of candidates for pairwise presentation.

        Default implementation: select the best and second-best.
        Strategies can override for more sophisticated pair selection.

        Returns
        -------
        tuple of (int, int)
            Indices of the two candidates to present.
        """
        if len(feature_vectors) < 2:
            raise ValueError("Need at least 2 candidates for pair selection")

        # Score all candidates and pick top-2
        scores = []
        for i in range(len(feature_vectors)):
            s = self._score_for_ranking(
                feature_vectors[i], safety_margins[i], mu, sigma
            )
            scores.append((s, i))
        scores.sort(reverse=True)
        return scores[0][1], scores[1][1]

    def _score_for_ranking(
        self,
        features: np.ndarray,
        safety_margin: float,
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> float:
        """Score used for pair selection ranking. Subclasses can override."""
        return float(mu @ features)



    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> tuple[int, int]:
        if len(feature_vectors) < 2:
            raise ValueError("Need at least 2 candidates")
        return 0, 1


# B2: Random Bandit

class RandomBanditStrategy(SelectionStrategy):
    """
    B2: Uniform random selection from safe candidates.

    No exploitation, no exploration bias. Pure random baseline.
    """

    def __init__(self, rng: Optional[np.random.Generator] = None):
        self.rng = rng if rng is not None else np.random.default_rng()

    @property
    def name(self) -> str:
        return "B2_Random_Bandit"

    def select(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> int:
        return int(self.rng.integers(len(feature_vectors)))

    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> tuple[int, int]:
        if len(feature_vectors) < 2:
            raise ValueError("Need at least 2 candidates")
        indices = self.rng.choice(len(feature_vectors), size=2, replace=False)
        return int(indices[0]), int(indices[1])


# B3: Greedy Bandit

class GreedyBanditStrategy(SelectionStrategy):

    @property
    def name(self) -> str:
        return "B3_Greedy_Bandit"

    def select(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> int:
        scores = [float(mu @ f) for f in feature_vectors]
        return int(np.argmax(scores))

    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> tuple[int, int]:
        if len(feature_vectors) < 2:
            raise ValueError("Need at least 2 candidates")
        scores = [(float(mu @ f), i) for i, f in enumerate(feature_vectors)]
        scores.sort(reverse=True)
        return scores[0][1], scores[1][1]


# B4: Thompson Sampling

class ThompsonSamplingStrategy(SelectionStrategy):
    """
    B4: Thompson Sampling.

    Sample w̃ ~ N(μ_t, Σ_t), then select argmax w̃ · φ_i.
    Provides natural exploration through posterior sampling.
    """

    def __init__(self, rng: Optional[np.random.Generator] = None):
        self.rng = rng if rng is not None else np.random.default_rng()

    @property
    def name(self) -> str:
        return "B4_Thompson_Sampling"

    def _sample_weights(self, mu: np.ndarray, sigma: np.ndarray) -> np.ndarray:
        """Sample weights from posterior."""
        return self.rng.multivariate_normal(mu, sigma)

    def select(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> int:
        w_sample = self._sample_weights(mu, sigma)
        scores = [float(w_sample @ f) for f in feature_vectors]
        return int(np.argmax(scores))

    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> tuple[int, int]:
        if len(feature_vectors) < 2:
            raise ValueError("Need at least 2 candidates")
        w_sample = self._sample_weights(mu, sigma)
        scores = [(float(w_sample @ f), i) for i, f in enumerate(feature_vectors)]
        scores.sort(reverse=True)
        return scores[0][1], scores[1][1]


# B5: Safety Max-Margin

class SafetyMaxMarginStrategy(SelectionStrategy):
    """
    B5: Always selects the candidate with the highest safety margin.

    Ignores user preferences entirely — pure safety maximization.
    Serves as the ceiling for safety and floor for personalization.
    """

    @property
    def name(self) -> str:
        return "B5_Safety_MaxMargin"

    def select(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> int:
        return int(np.argmax(safety_margins))

    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> tuple[int, int]:
        if len(feature_vectors) < 2:
            raise ValueError("Need at least 2 candidates")
        ranked = sorted(range(len(safety_margins)), key=lambda i: safety_margins[i], reverse=True)
        return ranked[0], ranked[1]

    def _score_for_ranking(
        self,
        features: np.ndarray,
        safety_margin: float,
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> float:
        return safety_margin


# CASPER Strategy (wraps the full three-term scoring)

@dataclass
class CasperConfig:
    """Configuration for CASPER strategy scoring terms."""
    beta: float = 0.3   # Conservative bias weight (safety margin)
    lam: float = 0.5    # Exploration bonus weight (information gain)
    epsilon: float = 0.1  # Autonomy threshold


class CasperStrategy(SelectionStrategy):

    def __init__(self, config: Optional[CasperConfig] = None):
        self.config = config or CasperConfig()

    @property
    def name(self) -> str:
        return "CASPER"

    def _score(
        self,
        features: np.ndarray,
        safety_margin: float,
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> float:
        """Three-term scoring function."""
        personalization = float(mu @ features)
        conservative_bias = self.config.beta * safety_margin
        info_gain = self.config.lam * float(features @ sigma @ features)
        return personalization + conservative_bias + info_gain

    def select(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> int:
        scores = [
            self._score(f, sm, mu, sigma)
            for f, sm in zip(feature_vectors, safety_margins)
        ]
        return int(np.argmax(scores))

    def _pair_score(
        self,
        fi: np.ndarray, fj: np.ndarray,
        smi: float, smj: float,
        mu: np.ndarray, sigma: np.ndarray,
    ) -> float:
        """PairScore for selecting informative pairs."""
        delta = fi - fj
        disc_info = float(delta @ sigma @ delta)
        avg_score = 0.5 * (
            self._score(fi, smi, mu, sigma)
            + self._score(fj, smj, mu, sigma)
        )
        return disc_info + avg_score

    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> tuple[int, int]:
        n = len(feature_vectors)
        if n < 2:
            raise ValueError("Need at least 2 candidates")

        best_score = -float("inf")
        best_pair = (0, 1)
        for i in range(n):
            for j in range(i + 1, n):
                ps = self._pair_score(
                    feature_vectors[i], feature_vectors[j],
                    safety_margins[i], safety_margins[j],
                    mu, sigma,
                )
                if ps > best_score:
                    best_score = ps
                    best_pair = (i, j)
        return best_pair

    def max_pair_info_gain(
        self,
        feature_vectors: list[np.ndarray],
        sigma: np.ndarray,
    ) -> float:
        """Check autonomy gate: max Δφᵀ Σ_t Δφ across all pairs."""
        n = len(feature_vectors)
        if n < 2:
            return 0.0
        max_gain = 0.0
        for i in range(n):
            for j in range(i + 1, n):
                delta = feature_vectors[i] - feature_vectors[j]
                gain = float(delta @ sigma @ delta)
                max_gain = max(max_gain, gain)
        return max_gain

    def should_be_autonomous(
        self,
        feature_vectors: list[np.ndarray],
        sigma: np.ndarray,
    ) -> bool:
        """True if max pair IG < epsilon (ready for autonomous mode)."""
        return self.max_pair_info_gain(feature_vectors, sigma) < self.config.epsilon


# Ablated CASPER Strategies

@dataclass
class AblationConfig:
    """Controls which scoring terms are active."""
    use_personalization: bool = True
    use_safety_margin: bool = True
    use_info_gain: bool = True
    label: str = ""

    @property
    def name(self) -> str:
        if self.label:
            return self.label
        parts = []
        if not self.use_personalization:
            parts.append("no_pers")
        if not self.use_safety_margin:
            parts.append("no_SM")
        if not self.use_info_gain:
            parts.append("no_IG")
        return "CASPER_" + "_".join(parts) if parts else "CASPER_full"


# Standard ablation configurations for E3
ABLATION_NO_PERSONALIZATION = AblationConfig(
    use_personalization=False, label="No Personalization"
)
ABLATION_NO_SAFETY_MARGIN = AblationConfig(
    use_safety_margin=False, label="No Safety Margin"
)
ABLATION_NO_INFO_GAIN = AblationConfig(
    use_info_gain=False, label="No Info Gain"
)
ABLATION_NO_IG_NO_SM = AblationConfig(
    use_safety_margin=False, use_info_gain=False, label="No IG + No SM"
)


class AblatedCasperStrategy(SelectionStrategy):
    """
    CASPER with selectively disabled scoring terms for ablation study.

    Score = [pers?] μᵀφ + [SM?] β·SM + [IG?] λ·IG

    When use_personalization=False, the feature score μᵀφ still applies
    but uses the fixed prior μ₀ instead of the learned posterior — isolating
    the value of adaptation rather than removing the preference signal entirely.
    """

    def __init__(
        self,
        ablation: AblationConfig,
        casper_config: Optional[CasperConfig] = None,
    ):
        self.ablation = ablation
        self.config = casper_config or CasperConfig()
        _default = [-0.3, 0.5, 0.3, 0.8, 0.3, -0.1, -0.2, -0.1, 0.0, -0.1]
        self._prior_mu = np.zeros(FEATURE_DIM, dtype=np.float64)
        self._prior_mu[:len(_default)] = _default[:FEATURE_DIM]

    @property
    def name(self) -> str:
        return f"CASPER_ablated({self.ablation.name})"

    def _score(
        self,
        features: np.ndarray,
        safety_margin: float,
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> float:
        score = 0.0
        effective_mu = mu if self.ablation.use_personalization else self._prior_mu
        score += float(effective_mu @ features)
        if self.ablation.use_safety_margin:
            score += self.config.beta * safety_margin
        if self.ablation.use_info_gain:
            score += self.config.lam * float(features @ sigma @ features)
        return score

    def select(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> int:
        scores = [
            self._score(f, sm, mu, sigma)
            for f, sm in zip(feature_vectors, safety_margins)
        ]
        return int(np.argmax(scores))

    def select_pair(
        self,
        feature_vectors: list[np.ndarray],
        safety_margins: list[float],
        mu: np.ndarray,
        sigma: np.ndarray,
    ) -> tuple[int, int]:
        n = len(feature_vectors)
        if n < 2:
            raise ValueError("Need at least 2 candidates")
        # Use score-based ranking for top-2
        scores = [(self._score(f, sm, mu, sigma), i)
                   for i, (f, sm) in enumerate(zip(feature_vectors, safety_margins))]
        scores.sort(reverse=True)
        return scores[0][1], scores[1][1]


# Factory

def all_strategies(
    rng: Optional[np.random.Generator] = None,
    casper_config: Optional[CasperConfig] = None,
) -> list[SelectionStrategy]:
    """Create one instance of each strategy (CASPER + all baselines)."""
    if rng is None:
        rng = np.random.default_rng()
    return [
        CasperStrategy(casper_config),
        RandomBanditStrategy(rng=rng),
        GreedyBanditStrategy(),
        ThompsonSamplingStrategy(rng=rng),
        SafetyMaxMarginStrategy(),
    ]


def all_ablations(
    casper_config: Optional[CasperConfig] = None,
) -> list[SelectionStrategy]:
    """Create CASPER + all ablated variants for E3."""
    return [
        CasperStrategy(casper_config),
        AblatedCasperStrategy(ABLATION_NO_PERSONALIZATION, casper_config),
        AblatedCasperStrategy(ABLATION_NO_SAFETY_MARGIN, casper_config),
        AblatedCasperStrategy(ABLATION_NO_INFO_GAIN, casper_config),
        AblatedCasperStrategy(ABLATION_NO_IG_NO_SM, casper_config),
    ]
