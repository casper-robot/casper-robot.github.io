# CASPER: Task Command Repair with Constrained Preference Learning

CASPER is a pre-execution safety and repair framework for robot task commands. Given a natural-language command and a grounded scene context, CASPER:

1. builds a task-conditioned **interaction graph**,
2. evaluates the command across **six structured safety dimensions**,
3. generates multiple **safe repair candidates** for unsafe or defective commands,
4. filters them through a **three-gate validation pipeline**, and
5. selects among the validated safe repairs using **constrained Bayesian preference learning**.

CASPER aims to recover underspecified, infeasible, or capability-mismatched commands into grounded, executable alternatives that maintain fidelity to the original task objective.

For the full technical details, please refer to the accompanying paper.

**Project website:** [casper-robot.github.io](https://casper-robot.github.io)

---

## Architecture

CASPER comprises four modules:

1. **Hazard/Defect Diagnosis** — Constructs a task-conditioned interaction graph from the command and scene context, then evaluates safety across six STAMP/STPA-inspired dimensions. Any flagged dimension routes the command into repair.

2. **Repair Generation** — Generates diverse repair candidates using Haddon-inspired countermeasure strategies (substitution, relocation, separation, barrier, recipient change, constraint tightening). Each candidate is a structured objective-realization pair containing a repaired command, bundled action plan, expected end state, and strategy label.

3. **Repair Validation and Safe-Set Construction** — Filters candidates through a three-gate waterfall: deterministic plan linting (Gate 1), lightweight LLM safety screen (Gate 2), and full six-dimension structured safety evaluation (Gate 3). Only candidates passing all three gates enter the validated safe set.

4. **Constrained Preference Learning** — Scores safe candidates using a four-term objective combining learned preference (posterior mean), safety margin, exploration (information gain), and objective-drift penalty. Maintains a Gaussian posterior over user preference weights updated online via Bradley-Terry pairwise comparisons.

---

## Setup

### Requirements

- Python 3.10+
- At least one LLM API key (OpenAI, Anthropic, or Google)

### Installation

```bash
# Clone and install
git clone <repository-url>
cd casper
pip install -e .
```

### API Keys

Copy the example environment file and add your API key(s):

```bash
cp .env.example .env
```

Edit `.env` with at least one of:

```
OPENAI_API_KEY=your-key-here
GOOGLE_API_KEY=your-key-here
GEMINI_API_KEY=your-key-here
```

The system auto-detects available providers. OpenAI (`gpt-4o`) is the default.

---

## Quick Start

### Interactive Interface

The fastest way to explore CASPER is through the web interface:

```bash
python casper/run_server.py
```

This opens a browser at `http://localhost:5000` with three pages:

- **Pipeline Explorer** — Type any command, select a scene, and watch the full pipeline execute: interaction graph construction, six-dimension safety evaluation, repair generation, three-gate validation, feature extraction, and profile-conditioned selection. Generated FR3 robot code is shown for executable repairs.

- **Results Dashboard** — Visualize benchmark results including safety detection metrics and per-category breakdowns.

- **Experiment B** — Run simulated preference learning trials with the five selection strategies (CASPER, Greedy, Thompson Sampling, Random, Safety Max-Margin) and seven oracle profiles.

Server options:

```bash
python casper/run_server.py --model gpt-4o          # Specify model
python casper/run_server.py --port 8080              # Change port
python casper/run_server.py --no-browser              # Don't auto-open browser
```

### Smoke Test

Run a quick 10-task end-to-end test to verify the installation:

```bash
python scripts/run_canonical_benchmark.py --quick --provider openai --model gpt-4o
```

This processes 10 SafeAgentBench tasks through the full pipeline (detection + repair + validation) and writes results to `results/benchmark_<timestamp>/`.

---

## Running Experiments

### Experiment A: Safety Detection Benchmark

Runs CASPER on the SafeAgentBench benchmark (300 tasks: 150 safe, 150 unsafe) and compares against SafePlan and RoboGuard baselines.

```bash
# Full benchmark (300 tasks, ~2-3 hours with 1 worker)
python scripts/run_canonical_benchmark.py \
    --provider openai --model gpt-4o

# With parallel workers (faster, requires rate limit headroom)
python scripts/run_canonical_benchmark.py \
    --provider openai --model gpt-4o \
    --max-workers 4

# With baseline comparison
python scripts/run_canonical_benchmark.py \
    --provider openai --model gpt-4o \
    --run-baselines
```

Outputs: `results.jsonl` (per-task results), `candidate_cache.json` (validated safe sets for downstream experiments), `adaptation_report.json`, `run_manifest.json`, and per-task traces in `traces/`.

### Experiment B: Online Preference Learning

Runs preference learning trials using cached safe candidate sets from Experiment A. Zero additional LLM cost.

```bash
# Requires a completed benchmark run with candidate_cache.json
python scripts/run_all_experiments.py \
    --provider openai --model gpt-4o \
    --experiments B B_ablation \
    --cache-path results/<benchmark_run>/candidate_cache.json
```

Runs 7 oracle profiles × 5 strategies × 20 trials at T=30 interactions each, plus four ablation variants (No Personalization, No Safety Margin, No Info Gain, No IG+SM).

### Experiment C: Cross-Hazard Transfer

Evaluates whether learned repair preferences transfer to held-out hazard categories.

```bash
python scripts/run_all_experiments.py \
    --provider openai --model gpt-4o \
    --experiments C \
    --cache-path results/<benchmark_run>/candidate_cache.json
```

Uses a leave-two-categories-out protocol and compares strategy-level features against text-level (TF-IDF) features.

### EARBench External Validation

Runs CASPER on the EARBench home split (531 tasks) for external generalization evaluation.

```bash
python scripts/run_earbench.py \
    --provider openai --model gpt-4o \
    --run-baselines
```

### Running All Experiments End-to-End

```bash
# Full pipeline: benchmark → cache → learning → transfer → ablation
python scripts/run_all_experiments.py \
    --provider openai --model gpt-4o \
    --experiments A B B_ablation C

# Quick smoke test (10 tasks, 2 trials)
python scripts/run_all_experiments.py \
    --provider openai --model gpt-4o \
    --quick
```

---

## Running Tests

```bash
# Run all tests
python -m pytest tests/ -v

# Run specific test modules
python -m pytest tests/test_safety.py -v        # Safety pipeline tests
python -m pytest tests/test_preference.py -v     # Preference learning tests
python -m pytest tests/test_evaluation.py -v     # Evaluation framework tests
```

Tests use mocked LLM calls and do not require API keys.

---

## Project Structure

```
casper/                          # Core CASPER pipeline
├── casper_pipeline.py           # Main pipeline: diagnosis → repair → validate → select
├── safety_kernel.py             # Six-dimension safety evaluation engine
├── safety_pipeline.py           # Full safety pipeline with consensus
├── prompt_templates.py          # All LLM prompt templates
├── preference_model.py          # Bayesian preference model (posterior, scoring, update)
├── feature_extraction.py        # 10-dimensional repair feature computation
├── objective_frame.py           # Task objective representation for drift penalty
├── plan_lint.py                 # Gate 1: deterministic plan validation
├── repair_operators.py          # Haddon-strategy-conditioned repair generation
├── repair_critic.py             # Internal repair quality filtering
├── repair_grounding.py          # Scene-grounded repair binding
├── task_frame.py                # Structured task decomposition for repair
├── action_ir.py                 # Canonical action representation and FR3 export
├── vlm_scene.py                 # VLM-based real-scene perception
├── scene_provider.py            # Scene data loading and caching
├── object_normalizer.py         # Object name normalization and alias resolution
├── llm_interface.py             # LLM call abstraction
├── llm_providers.py             # Provider-specific backends (OpenAI, Anthropic, Google)
├── run_server.py                # Web interface entry point
├── interface/                   # Flask web interface
│   ├── app.py                   # Routes and API endpoints
│   ├── templates/               # HTML templates
│   └── static/                  # CSS and JavaScript
└── data/
    └── scene_cache.json         # Cached scene metadata

evaluation/                      # Experiment infrastructure
├── simulated_user.py            # 7 oracle preference profiles (Bradley-Terry)
├── baselines.py                 # Selection strategies: CASPER + 4 baselines + ablations
├── experiments.py               # Trial loops: run_trial_cached, run_transfer_experiment
├── candidate_cache.py           # Pre-computed safe candidate sets
├── metrics.py                   # Tracking: regret, accuracy, contraction, convergence
├── benchmark_runner.py          # SafeAgentBench pipeline runner (Experiment A)
├── benchmark_results.py         # Result dataclasses
├── benchmark_safety_eval.py     # Safety evaluation utilities
├── safety_baselines.py          # SafePlan and RoboGuard baseline implementations
├── safeagentbench_loader.py     # SafeAgentBench data loader
├── earbench_loader.py           # EARBench data loader
├── scene_adapters.py            # Scene adapters
├── scene_cache.py               # Scene metadata caching
├── analysis.py                  # Results aggregation and reporting
└── trace_recorder.py            # Pipeline trace recording

scripts/                         # Top-level experiment scripts
├── run_canonical_benchmark.py   # Experiment A: SafeAgentBench evaluation
├── run_all_experiments.py       # Orchestrator: A → B → C with dependency management
└── run_earbench.py              # EARBench external validation

data/benchmarks/                 # Benchmark datasets
├── safeagentbench/              # SafeAgentBench splits (safe, unsafe, abstract, long-horizon)
└── earbench/                    # EARBench home split

tests/                           # Unit and integration tests
```

---

## Oracle Preference Profiles

CASPER is evaluated against seven fixed oracle profiles, each defined by a ground-truth weight vector over the 10-dimensional repair feature space:

| Profile | What it tests |
|---------|--------------|
| Conservative Parent | Risk-averse preferences favoring high safety margins |
| Minimal Change | Preference for the least disruptive safe repair |
| Object-Attached | Strong single-dimension preference (object preservation) |
| Pragmatic | Near-indifferent preferences (stress-tests learning under weak signal) |
| Safety-First | Dominant safety margin preference, tolerates stronger interventions |
| Structure-Preserving | Sensitivity to task-form preservation |
| Anti-Prior | Preferences intentionally misaligned with the population prior |

Profile weight vectors and the population prior are defined in `evaluation/simulated_user.py`.

---

## Key Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--provider` | `openai` | LLM provider (openai, anthropic, google) |
| `--model` | `gpt-4o` | Model identifier |
| `--K` | `7` | Repair candidates per unsafe command |
| `--num-tasks` | `0` (all) | Cap on total benchmark tasks |
| `--n-trials` | `20` | Trials per profile-strategy pair |
| `--quick` | off | Smoke test mode (10 tasks, 2 trials) |
| `--max-workers` | `1` | Parallel task workers for benchmark |
| `--resume` | on | Resume from checkpoint if available |

---

## Citation

```bibtex
@inproceedings{casper2026,
  title={CASPER: Task Command Repair with Constrained Preference Learning},
  author={Anonymous},
  booktitle={Under Review at Conference on Robot Learning (CoRL)},
  year={2026}
}
```

---

## License

See the accompanying paper for terms of use.
