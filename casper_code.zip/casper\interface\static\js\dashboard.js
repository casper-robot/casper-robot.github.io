(function () {
    "use strict";

    var categoryChart = null;
    var transferChart = null;
    var featureCompChart = null;
    var allTasks = [];

    document.addEventListener("DOMContentLoaded", init);

    function init() {
        initTabs();
        loadExperimentA();
        loadExperimentC();
        document.getElementById("taskCategoryFilter").addEventListener("change", filterTasks);
        document.getElementById("taskResultFilter").addEventListener("change", filterTasks);
    }

    function initTabs() {
        document.querySelectorAll(".tab").forEach(function (tab) {
            tab.addEventListener("click", function () {
                var target = this.dataset.tab;
                document.querySelectorAll(".tab").forEach(function (t) { t.classList.remove("active"); });
                document.querySelectorAll(".tab-content").forEach(function (c) { c.classList.remove("active"); });
                this.classList.add("active");
                document.getElementById(target).classList.add("active");
            });
        });
    }

    function loadExperimentA() {
        fetch("/api/dashboard/experiment-a")
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.error) {
                    document.getElementById("noDataCard").style.display = "block";
                    return;
                }
                renderExperimentA(data);
            })
            .catch(function () {
                document.getElementById("noDataCard").style.display = "block";
            });
    }

    function renderExperimentA(data) {
        var cm = data.confusion_matrix || {};
        document.getElementById("aTotal").textContent = data.total_tasks || 0;
        document.getElementById("aAccuracy").textContent = pct(cm.accuracy);
        document.getElementById("aDetection").textContent = pct(cm.detection_rate);

        document.getElementById("cmTP").textContent = cm.tp || 0;
        document.getElementById("cmFP").textContent = cm.fp || 0;
        document.getElementById("cmTN").textContent = cm.tn || 0;
        document.getElementById("cmFN").textContent = cm.fn || 0;
        document.getElementById("aFPR").textContent = pct(cm.false_positive_rate);
        document.getElementById("aFNR").textContent = pct(cm.false_negative_rate);

        var byCat = data.by_category || {};
        var cats = Object.keys(byCat).sort();

        var select = document.getElementById("taskCategoryFilter");
        cats.forEach(function (cat) {
            var opt = document.createElement("option");
            opt.value = cat;
            opt.textContent = cat;
            select.appendChild(opt);
        });

        document.getElementById("categoryTable").innerHTML = cats.map(function (cat) {
            var c = byCat[cat];
            return '<tr><td>' + cat + '</td>' +
                '<td>' + (c.n_tasks || 0) + '</td>' +
                '<td>' + (c.tp || 0) + '</td>' +
                '<td>' + (c.fp || 0) + '</td>' +
                '<td>' + (c.tn || 0) + '</td>' +
                '<td>' + (c.fn || 0) + '</td>' +
                '<td>' + pct(c.detection_rate) + '</td>' +
                '<td>' + pct(c.accuracy) + '</td></tr>';
        }).join("");

        if (categoryChart) categoryChart.destroy();
        var ctx = document.getElementById("categoryChart").getContext("2d");
        categoryChart = new Chart(ctx, {
            type: "bar",
            data: {
                labels: cats,
                datasets: [
                    {
                        label: "Detection Rate",
                        data: cats.map(function (c) { return (byCat[c].detection_rate || 0) * 100; }),
                        backgroundColor: "rgba(39,174,96,0.7)"
                    },
                    {
                        label: "False Positive Rate",
                        data: cats.map(function (c) { return (byCat[c].false_positive_rate || 0) * 100; }),
                        backgroundColor: "rgba(231,76,60,0.7)"
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true, max: 100, title: { display: true, text: "%" } },
                    x: { ticks: { maxRotation: 45 } }
                }
            }
        });

        allTasks = data.tasks || [];
        renderTasks(allTasks);
    }

    function filterTasks() {
        var cat = document.getElementById("taskCategoryFilter").value;
        var result = document.getElementById("taskResultFilter").value;
        var filtered = allTasks.filter(function (t) {
            if (cat !== "all" && t.hazard_category !== cat) return false;
            if (result === "all") return true;
            var gtUnsafe = !t.ground_truth_safe;
            var detected = t.pipeline_detected_unsafe || t.detected_unsafe || false;
            if (result === "tp") return gtUnsafe && detected;
            if (result === "fn") return gtUnsafe && !detected;
            if (result === "fp") return !gtUnsafe && detected;
            if (result === "tn") return !gtUnsafe && !detected;
            return true;
        });
        renderTasks(filtered);
    }

    function renderTasks(tasks) {
        document.getElementById("taskTable").innerHTML = tasks.slice(0, 100).map(function (t) {
            var gtUnsafe = !t.ground_truth_safe;
            var detected = t.pipeline_detected_unsafe || t.detected_unsafe || false;
            var resultType, resultCls;
            if (gtUnsafe && detected) { resultType = "TP"; resultCls = "badge-success"; }
            else if (gtUnsafe && !detected) { resultType = "FN"; resultCls = "badge-failure"; }
            else if (!gtUnsafe && detected) { resultType = "FP"; resultCls = "badge-abort"; }
            else { resultType = "TN"; resultCls = "badge-info"; }

            return '<tr>' +
                '<td><a href="#" onclick="loadTaskDetail(\'' + t.task_id + '\'); return false;">' + (t.task_id || "") + '</a></td>' +
                '<td>' + (t.hazard_category || "") + '</td>' +
                '<td>' + (gtUnsafe ? "Unsafe" : "Safe") + '</td>' +
                '<td>' + (detected ? "Yes" : "No") + '</td>' +
                '<td><span class="badge ' + resultCls + '">' + resultType + '</span></td></tr>';
        }).join("");
    }

    window.loadTaskDetail = function (taskId) {
        fetch("/api/dashboard/experiment-a/task/" + taskId)
            .then(function (r) { return r.json(); })
            .then(function (data) {
                var detail = document.createElement("div");
                detail.style.cssText = "position:fixed;inset:0;z-index:200;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;";
                detail.onclick = function (e) { if (e.target === detail) detail.remove(); };
                var content = '<div style="background:white;border-radius:8px;padding:1.5rem;max-width:700px;width:90%;max-height:80vh;overflow:auto;">' +
                    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">' +
                    '<h2 style="font-size:1.1rem;">Task: ' + taskId + '</h2>' +
                    '<button class="btn btn-sm btn-outline" onclick="this.closest(\'div[style]\').parentElement.remove()">Close</button></div>';
                if (data.checkpoint) {
                    var cp = data.checkpoint;
                    content += '<div class="stage ' + (cp.ground_truth_safe === false ? 'stage-unsafe' : 'stage-safe') + '">' +
                        '<div class="stage-header">Checkpoint</div>' +
                        '<div style="font-size:0.85rem;">Category: ' + (cp.hazard_category || '--') + '<br>' +
                        'Ground truth: ' + (cp.ground_truth_safe === false ? 'Unsafe' : 'Safe') + '<br>' +
                        'Detected: ' + (cp.pipeline_detected_unsafe || cp.detected_unsafe ? 'Yes' : 'No') + '</div></div>';
                }
                content += '<div class="code-block" style="margin-top:1rem;font-size:0.75rem;">' +
                    JSON.stringify(data, null, 2).replace(/</g, '&lt;') + '</div></div>';
                detail.innerHTML = content;
                document.body.appendChild(detail);
            })
            .catch(function (e) { console.error("Failed to load task:", e); });
    };

    function loadExperimentC() {
        fetch("/api/dashboard/experiment-c")
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.error) return;
                renderExperimentC(data);
            })
            .catch(function () {});
    }

    function renderExperimentC(data) {
        var matrix = data.transfer_matrix || data.matrix;
        var categories = data.categories || data.labels || [];
        var strategyAcc = data.strategy_accuracy || [];
        var textAcc = data.text_accuracy || [];

        if (matrix && categories.length > 0) {
            renderTransferHeatmap(matrix, categories);
        }

        if (strategyAcc.length > 0 || textAcc.length > 0) {
            renderFeatureComparison(categories, strategyAcc, textAcc);
        }

        if (matrix) {
            var tableEl = document.getElementById("transferTable");
            tableEl.style.display = "block";
            var html = '<table><thead><tr><th></th>' +
                categories.map(function (c) { return '<th>' + c + '</th>'; }).join("") +
                '</tr></thead><tbody>';
            for (var i = 0; i < categories.length; i++) {
                html += '<tr><th>' + categories[i] + '</th>';
                for (var j = 0; j < categories.length; j++) {
                    var val = matrix[i] ? matrix[i][j] : 0;
                    var bg = val > 0.7 ? "#d5f5e3" : val > 0.5 ? "#fdebd0" : "#fadbd8";
                    html += '<td style="background:' + bg + '; text-align:center;">' + (val * 100).toFixed(0) + '%</td>';
                }
                html += '</tr>';
            }
            html += '</tbody></table>';
            document.getElementById("transferTableContent").innerHTML = html;
        }
    }

    function renderTransferHeatmap(matrix, categories) {
        var datasets = [];
        for (var i = 0; i < categories.length; i++) {
            for (var j = 0; j < categories.length; j++) {
                var val = matrix[i] ? matrix[i][j] : 0;
                datasets.push({ x: categories[j], y: categories[i], v: val });
            }
        }

        if (transferChart) transferChart.destroy();
        var ctx = document.getElementById("transferChart").getContext("2d");
        transferChart = new Chart(ctx, {
            type: "scatter",
            data: {
                datasets: [{
                    label: "Transfer Accuracy",
                    data: datasets.map(function (d) {
                        return { x: categories.indexOf(d.x), y: categories.indexOf(d.y) };
                    }),
                    backgroundColor: datasets.map(function (d) {
                        var r = Math.round(255 * (1 - d.v));
                        var g = Math.round(255 * d.v);
                        return "rgba(" + r + "," + g + ",100,0.7)";
                    }),
                    pointRadius: 15
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: "linear",
                        ticks: {
                            callback: function (v) { return categories[v] || ""; },
                            stepSize: 1
                        },
                        min: -0.5,
                        max: categories.length - 0.5
                    },
                    y: {
                        type: "linear",
                        ticks: {
                            callback: function (v) { return categories[v] || ""; },
                            stepSize: 1
                        },
                        min: -0.5,
                        max: categories.length - 0.5,
                        reverse: true
                    }
                },
                plugins: { legend: { display: false } }
            }
        });
    }

    function renderFeatureComparison(categories, strategyAcc, textAcc) {
        if (featureCompChart) featureCompChart.destroy();
        var ctx = document.getElementById("featureCompChart").getContext("2d");
        var datasets = [];
        if (strategyAcc.length > 0) {
            datasets.push({
                label: "Strategy Features (10D)",
                data: strategyAcc.map(function (v) { return v * 100; }),
                backgroundColor: "rgba(26,82,118,0.7)"
            });
        }
        if (textAcc.length > 0) {
            datasets.push({
                label: "Text/Embedding Features",
                data: textAcc.map(function (v) { return v * 100; }),
                backgroundColor: "rgba(243,156,18,0.7)"
            });
        }
        featureCompChart = new Chart(ctx, {
            type: "bar",
            data: { labels: categories, datasets: datasets },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true, max: 100, title: { display: true, text: "Accuracy %" } },
                    x: { ticks: { maxRotation: 45 } }
                }
            }
        });
    }

    function pct(v) {
        if (v == null) return "--";
        return (v * 100).toFixed(1) + "%";
    }
})();
